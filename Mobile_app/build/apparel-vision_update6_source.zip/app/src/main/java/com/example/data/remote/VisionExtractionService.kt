package com.example.data.remote

import android.content.Context
import android.util.Log
import com.example.data.local.entity.ScanEntity
import com.example.data.preferences.AppSettings
import com.example.data.reference.ReferenceVocabulary
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.io.File
import java.util.concurrent.TimeUnit

class VisionExtractionService(private val context: Context) {
    private val appSettings = AppSettings.getInstance(context)
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun getRetrofit(baseUrl: String): Retrofit {
        val normalized = AppSettings.normalizeServerUrl(baseUrl)
        val sanitized = if (!normalized.endsWith("/")) "$normalized/" else normalized
        return Retrofit.Builder()
            .baseUrl(sanitized)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
    }

    private fun getApi(): MiddlewareApiService {
        return getRetrofit(appSettings.serverUrl).create(MiddlewareApiService::class.java)
    }

    suspend fun getAuthToken(forceRefresh: Boolean = false): String? {
        if (!forceRefresh) {
            val cached = appSettings.sessionToken
            if (!cached.isNullOrBlank()) return cached
        }

        return try {
            val api = getApi()
            val res = api.login(
                LoginRequest(
                    username = appSettings.userId.trim(),
                    password = appSettings.devicePassword.trim()
                )
            )
            val body = res.body()
            val token = body?.token?.takeIf { it.isNotBlank() }
            if (res.isSuccessful && token != null) {
                Log.d(TAG, "JWT token acquired successfully for operator: ${appSettings.userId}")
                appSettings.sessionToken = token
                token
            } else {
                val errorBody = res.errorBody()?.string() ?: ""
                Log.w(TAG, "Auth failed HTTP ${res.code()}: $errorBody")
                if (errorBody.contains("ACCOUNT_DISABLED", ignoreCase = true)) {
                    Log.e(TAG, "Operator account is disabled by supervisor")
                }
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Device auth handshake unavailable: ${e.message}")
            null
        }
    }

    suspend fun checkHealth(): Result<HealthResponse> = withContext(Dispatchers.IO) {
        try {
            val api = getApi()
            var res = api.checkHealth()
            if (!res.isSuccessful && res.code() == 404) {
                res = api.checkHealthApiV1()
            }
            if (res.isSuccessful && res.body() != null) {
                Result.success(res.body()!!)
            } else {
                Result.failure(Exception("Health check returned HTTP ${res.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    data class ConnectionValidationResult(
        val isSuccessful: Boolean,
        val isHealthOk: Boolean,
        val isAuthOk: Boolean,
        val serverVersion: String? = null,
        val uptimeSeconds: Long? = null,
        val geminiReady: Boolean = false,
        val username: String = "",
        val tokenPreview: String? = null,
        val errorMessage: String? = null
    )

    suspend fun testConnectionAndAuth(): ConnectionValidationResult = withContext(Dispatchers.IO) {
        val healthResult = checkHealth()
        val health = healthResult.getOrNull()
        val isHealthOk = healthResult.isSuccess && health != null

        // Force fresh authentication handshake
        val token = getAuthToken(forceRefresh = true)
        val isAuthOk = !token.isNullOrBlank()

        val isSuccess = isAuthOk || (isHealthOk && appSettings.sessionToken != null)

        val errorReason = when {
            !isHealthOk && !isAuthOk -> "Cannot reach middleware server at ${appSettings.serverUrl}. Please verify host address, port, and Wi-Fi connection."
            isHealthOk && !isAuthOk -> "Server reached, but credentials were rejected. Please verify Operator Username and Device Password."
            !isHealthOk && isAuthOk -> "Authenticated successfully! (Health check probe endpoint returned non-standard status)."
            else -> null
        }

        ConnectionValidationResult(
            isSuccessful = isSuccess,
            isHealthOk = isHealthOk,
            isAuthOk = isAuthOk,
            serverVersion = health?.version,
            uptimeSeconds = health?.uptimeSeconds,
            geminiReady = health?.geminiReady ?: false,
            username = appSettings.userId,
            tokenPreview = token?.take(16)?.let { "$it..." },
            errorMessage = errorReason
        )
    }

    suspend fun submitVisionExtract(
        scan: ScanEntity,
        imageFiles: List<File>,
        clonedFrom: String? = null
    ): Result<AsyncVisionResponse> = withContext(Dispatchers.IO) {
        var token = getAuthToken()
        if (token.isNullOrBlank()) {
            return@withContext Result.failure(Exception("AUTH_REQUIRED: Invalid device credentials or server unreachable"))
        }

        try {
            val api = getApi()
            val textPlain = "text/plain".toMediaTypeOrNull()
            val apparelIdBody = scan.apparelId.toRequestBody(textPlain)
            val usernameBody = appSettings.userId.toRequestBody(textPlain)
            val keyPhotoBody = scan.keyPhotoIndex.toString().toRequestBody(textPlain)
            val clonedFromBody = clonedFrom?.toRequestBody(textPlain)

            val imageParts = imageFiles.filter { it.exists() }.take(8).mapIndexed { index, file ->
                val requestFile = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
                MultipartBody.Part.createFormData("images", file.name, requestFile)
            }

            var response = api.submitVisionExtract(
                authorization = "Bearer $token",
                apparelId = apparelIdBody,
                username = usernameBody,
                keyPhotoIndex = keyPhotoBody,
                clonedFrom = clonedFromBody,
                images = imageParts
            )

            // Handle token expiration or revocation gracefully
            if (response.code() == 401) {
                val errStr = response.errorBody()?.string() ?: ""
                if (errStr.contains("ACCOUNT_DISABLED", ignoreCase = true)) {
                    return@withContext Result.failure(Exception("ACCOUNT_DISABLED: Operator account has been disabled by supervisor."))
                }
                // Try refresh token once if revoked or expired
                appSettings.sessionToken = null
                val refreshedToken = getAuthToken(forceRefresh = true)
                if (!refreshedToken.isNullOrBlank()) {
                    token = refreshedToken
                    response = api.submitVisionExtract(
                        authorization = "Bearer $token",
                        apparelId = apparelIdBody,
                        username = usernameBody,
                        keyPhotoIndex = keyPhotoBody,
                        clonedFrom = clonedFromBody,
                        images = imageParts
                    )
                }
            }

            if (response.code() in 200..299 && response.body() != null) {
                // Storage invariant: 2xx response guarantees server has stored the scan
                Result.success(response.body()!!)
            } else {
                val errorCode = response.code()
                val errorBody = response.errorBody()?.string() ?: ""
                val msg = "HTTP $errorCode: $errorBody"
                Result.failure(Exception(msg))
            }
        } catch (e: Exception) {
            Log.w(TAG, "submitVisionExtract transport error: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun getBatchVisionResults(apparelIds: List<String>): Result<BatchVisionResultsResponse> = withContext(Dispatchers.IO) {
        if (apparelIds.isEmpty()) {
            return@withContext Result.success(BatchVisionResultsResponse(status = "success"))
        }

        var token = getAuthToken()
        if (token.isNullOrBlank()) {
            return@withContext Result.failure(Exception("AUTH_REQUIRED: Invalid session token"))
        }

        try {
            val api = getApi()
            val idsQuery = apparelIds.take(100).joinToString(",")
            var response = api.getBatchVisionResults(
                authorization = "Bearer $token",
                idsCommaSeparated = idsQuery
            )

            if (response.code() == 401) {
                appSettings.sessionToken = null
                val refreshed = getAuthToken(forceRefresh = true)
                if (!refreshed.isNullOrBlank()) {
                    token = refreshed
                    response = api.getBatchVisionResults(
                        authorization = "Bearer $token",
                        idsCommaSeparated = idsQuery
                    )
                }
            }

            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                Result.failure(Exception("Batch fetch error HTTP ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun generateLocalSyntheticExtraction(barcode: String): VisionExtraction {
        val sampleBrands = listOf("Zara", "Nike", "Levi'S", "Adidas", "H&M", "Massimo Dutti")
        val sampleSubCats = listOf("T-shirt", "Trousers", "Hoodie", "Shirt", "Dress", "Jeans")
        val sampleMaterials = listOf("Cotton", "Polyester", "Wool", "Silk", "Linen", "Viscose")
        val sampleCountries = listOf("PORTUGAL", "VIETNAM", "ITALY", "TURKEY", "BANGLADESH", "CHINA")
        val sampleColors = listOf("Blue - Navy", "Black", "White", "Grey", "Dark red", "Khaki")

        val brand = sampleBrands.random()
        val subCat = sampleSubCats.random()
        val material = sampleMaterials.random()
        val country = sampleCountries.random()
        val color = sampleColors.random()

        return VisionExtraction(
            brandName = VisionField(value = brand, confidence = 0.95f),
            category = VisionField(value = "clothing", confidence = 0.92f),
            subCategory = VisionField(value = subCat, confidence = 0.89f),
            gender = VisionField(value = "Men", confidence = 0.90f),
            season = VisionField(value = "Summer", confidence = 0.85f),
            size = VisionField(value = "L", confidence = 0.92f),
            color = VisionField(value = color, confidence = 0.89f),
            material = VisionField(value = material, confidence = 0.88f),
            countryOfOrigin = VisionField(value = country, confidence = 0.85f),
            originalPrice = VisionField(value = "€79.90", confidence = 0.80f),
            netto = VisionField(value = "280g", confidence = 0.75f),
            brutto = VisionField(value = "320g", confidence = 0.75f)
        )
    }

    companion object {
        private const val TAG = "VisionExtractionService"
    }
}

