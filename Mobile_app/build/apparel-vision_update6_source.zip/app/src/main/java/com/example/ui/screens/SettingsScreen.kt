package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import com.example.data.remote.VisionExtractionService
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.LsBeige100
import com.example.ui.theme.LsBeige300
import com.example.ui.theme.LsCocoa500
import com.example.ui.theme.LsCocoa600
import com.example.ui.theme.LsCocoa900
import com.example.ui.theme.LsCreme
import com.example.ui.theme.LsGold200
import com.example.ui.theme.LsGold500
import com.example.ui.theme.LsGold800
import com.example.ui.theme.LsLinen
import com.example.ui.theme.LsRust200
import com.example.ui.theme.LsRust50
import com.example.ui.theme.LsRust500
import com.example.ui.theme.LsRust700
import com.example.ui.viewmodel.ApparelViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: ApparelViewModel) {
    val appSettings = viewModel.appSettings

    var userId by remember { mutableStateOf(appSettings.userId) }
    var devicePassword by remember { mutableStateOf(appSettings.devicePassword) }
    var serverUrl by remember { mutableStateOf(appSettings.serverUrl) }
    var autoSyncAi by remember { mutableStateOf(appSettings.autoSyncAiVision) }
    var demoMode by remember { mutableStateOf(appSettings.demoModeEnabled) }
    var defaultScreen by remember { mutableStateOf(appSettings.defaultStartDestination) }

    val orphanCount by viewModel.orphanedPhotoCount.collectAsStateWithLifecycle()
    val orphanBytes by viewModel.orphanedPhotoBytes.collectAsStateWithLifecycle()

    var showCleanPhotosDialog by remember { mutableStateOf(false) }
    var showPurgeDangerDialog by remember { mutableStateOf(false) }
    var purgeConfirmedCheckbox by remember { mutableStateOf(false) }

    var expandedStartScreenDropdown by remember { mutableStateOf(false) }

    val startScreenOptions = listOf(
        "review" to "Review Workspace (Default)",
        "capture" to "Camera Intake (Capture)",
        "ledger" to "Daily Production Ledger"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(LsCreme)
            .testTag("settings_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar
            Surface(
                color = LsGold800,
                modifier = Modifier.fillMaxWidth(),
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PREFERENCES & STORAGE",
                            color = LsGold200,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Enterprise Device Settings",
                            color = LsLinen,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Section 1: Default Startup Destination
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = LsLinen),
                    border = BorderStroke(1.dp, LsBeige300)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Home, contentDescription = null, tint = LsGold800, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Default Launch Screen", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LsCocoa900)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Choose which tab opens automatically when launching the application:",
                            fontSize = 12.sp,
                            color = LsCocoa600
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        ExposedDropdownMenuBox(
                            expanded = expandedStartScreenDropdown,
                            onExpandedChange = { expandedStartScreenDropdown = !expandedStartScreenDropdown }
                        ) {
                            OutlinedTextField(
                                value = startScreenOptions.firstOrNull { it.first == defaultScreen }?.second ?: "Review Workspace (Default)",
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedStartScreenDropdown) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = LsGold500,
                                    unfocusedBorderColor = LsBeige300,
                                    focusedContainerColor = LsLinen,
                                    unfocusedContainerColor = LsLinen,
                                    focusedTextColor = LsCocoa900,
                                    unfocusedTextColor = LsCocoa900
                                )
                            )

                            ExposedDropdownMenu(
                                expanded = expandedStartScreenDropdown,
                                onDismissRequest = { expandedStartScreenDropdown = false },
                                modifier = Modifier.background(LsLinen)
                            ) {
                                startScreenOptions.forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text(option.second, color = LsCocoa900) },
                                        onClick = {
                                            defaultScreen = option.first
                                            appSettings.defaultStartDestination = option.first
                                            expandedStartScreenDropdown = false
                                            viewModel.toastMessage = "Default screen set to ${option.second}"
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Section 2: Middleware & Connectivity
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = LsLinen),
                    border = BorderStroke(1.dp, LsBeige300)
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Tune, contentDescription = null, tint = LsGold800, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Middleware API & Credentials", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LsCocoa900)
                        }

                        OutlinedTextField(
                            value = serverUrl,
                            onValueChange = {
                                serverUrl = it
                                appSettings.serverUrl = it
                                appSettings.clearAuth()
                                viewModel.connectionTestResult = null
                            },
                            label = { Text("Server Base URL (e.g. http://10.0.2.2:3000)", color = LsCocoa600) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = LsGold500,
                                unfocusedBorderColor = LsBeige300,
                                focusedTextColor = LsCocoa900,
                                unfocusedTextColor = LsCocoa900
                            )
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(modifier = Modifier.weight(1f)) {
                                OutlinedTextField(
                                    value = userId,
                                    onValueChange = {
                                        userId = it
                                        appSettings.userId = it
                                        appSettings.clearAuth()
                                        viewModel.connectionTestResult = null
                                    },
                                    label = { Text("Operator Username", color = LsCocoa600) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = LsGold500,
                                        unfocusedBorderColor = LsBeige300,
                                        focusedTextColor = LsCocoa900,
                                        unfocusedTextColor = LsCocoa900
                                    )
                                )
                            }

                            Box(modifier = Modifier.weight(1f)) {
                                OutlinedTextField(
                                    value = devicePassword,
                                    onValueChange = {
                                        devicePassword = it
                                        appSettings.devicePassword = it
                                        appSettings.clearAuth()
                                        viewModel.connectionTestResult = null
                                    },
                                    label = { Text("Device Password", color = LsCocoa600) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = LsGold500,
                                        unfocusedBorderColor = LsBeige300,
                                        focusedTextColor = LsCocoa900,
                                        unfocusedTextColor = LsCocoa900
                                    )
                                )
                            }
                        }

                        // Test & Validate Connection Button
                        Button(
                            onClick = { viewModel.testServerConnection() },
                            enabled = !viewModel.isTestingConnection,
                            colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().testTag("button_test_server_connection")
                        ) {
                            if (viewModel.isTestingConnection) {
                                CircularProgressIndicator(color = LsLinen, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Connecting & Authenticating...", color = LsLinen, fontSize = 13.sp)
                            } else {
                                Icon(Icons.Default.Sync, contentDescription = null, tint = LsLinen, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Test & Validate Connection", color = LsLinen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }

                        // Validation Result Badge / Summary Card
                        viewModel.connectionTestResult?.let { res ->
                            Surface(
                                color = if (res.isSuccessful) Color(0xFFDCFCE7) else LsRust50,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, if (res.isSuccessful) Color(0xFF86EFAC) else LsRust200),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (res.isSuccessful) Icons.Default.CheckCircle else Icons.Default.Warning,
                                            contentDescription = null,
                                            tint = if (res.isSuccessful) Color(0xFF166534) else LsRust700,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (res.isSuccessful) "Server Connected & Authenticated" else "Validation Error",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (res.isSuccessful) Color(0xFF166534) else LsRust700
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    if (res.isSuccessful) {
                                        Text("• Auth: Active JWT issued for ${res.username}", fontSize = 11.sp, color = Color(0xFF166534))
                                        if (res.serverVersion != null) {
                                            Text("• Server: v${res.serverVersion} (Uptime: ${(res.uptimeSeconds ?: 0) / 3600}h)", fontSize = 11.sp, color = Color(0xFF166534))
                                        }
                                        Text("• Gemini AI Engine: ${if (res.geminiReady) "Ready" else "Standby"}", fontSize = 11.sp, color = Color(0xFF166534))
                                    } else {
                                        Text(res.errorMessage ?: "Unknown validation error", fontSize = 11.sp, color = LsRust700)
                                    }
                                }
                            }
                        }

                        // Auto-Sync Switch
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Auto-Sync Vision AI", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = LsCocoa900)
                                Text("Automatically send finished scans to vision backend", fontSize = 11.sp, color = LsCocoa500)
                            }
                            Switch(
                                checked = autoSyncAi,
                                onCheckedChange = {
                                    autoSyncAi = it
                                    appSettings.autoSyncAiVision = it
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = LsLinen,
                                    checkedTrackColor = LsGold800
                                )
                            )
                        }

                        // Demo Mode Switch
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Demo Simulation Mode", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = LsCocoa900)
                                Text("Use offline heuristic mock extractions without network", fontSize = 11.sp, color = LsCocoa500)
                            }
                            Switch(
                                checked = demoMode,
                                onCheckedChange = {
                                    demoMode = it
                                    appSettings.demoModeEnabled = it
                                    appSettings.isDemoModeConfigured = it
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = LsLinen,
                                    checkedTrackColor = LsGold800
                                )
                            )
                        }
                    }
                }

                // Section 3: Storage & Unused Photos Cleanup
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = LsLinen),
                    border = BorderStroke(1.dp, LsBeige300)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CleaningServices, contentDescription = null, tint = LsGold800, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Storage & Unused Photos", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LsCocoa900)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        val kbSize = (orphanBytes / 1024.0).toInt()
                        Text(
                            text = "Unreferenced scratch photos detected: $orphanCount ($kbSize KB). These are cancelled or abandoned photo sessions older than 1 hour.",
                            fontSize = 12.sp,
                            color = LsCocoa600
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = { showCleanPhotosDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = LsBeige100),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.CleaningServices, contentDescription = null, tint = LsCocoa900, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Delete Unused Photos Cache", color = LsCocoa900, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    }
                }

                // Section 4: DANGER ZONE (Delete All Data & Photos)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = LsRust50),
                    border = BorderStroke(1.5.dp, LsRust200)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = LsRust500, modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("DANGER ZONE", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LsRust700)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Warning: Backup all your data. This action cannot be undone.",
                            color = LsRust700,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "If SQLite becomes oversized from extensive usage, this will permanently wipe all local database tables (scans, verified daily ledger, history logs) and delete all stored photos from the device storage.",
                            color = LsCocoa600,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                purgeConfirmedCheckbox = false
                                showPurgeDangerDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = LsRust500),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.DeleteForever, contentDescription = null, tint = LsLinen, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Delete All Data & Photos", color = LsLinen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }

        // Clean Orphaned Photos Dialog
        if (showCleanPhotosDialog) {
            AlertDialog(
                onDismissRequest = { showCleanPhotosDialog = false },
                title = { Text("Clean Unused Photos", fontWeight = FontWeight.Bold, color = LsCocoa900) },
                text = {
                    Text(
                        "Delete $orphanCount unreferenced scratch photos from storage? Active ledger photos and queued scans will remain untouched.",
                        color = LsCocoa600,
                        fontSize = 13.sp
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.cleanOrphanedPhotos()
                            showCleanPhotosDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Clean Cache", color = LsLinen, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    Button(
                        onClick = { showCleanPhotosDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = LsBeige100),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Cancel", color = LsCocoa900)
                    }
                },
                containerColor = LsLinen,
                shape = RoundedCornerShape(14.dp)
            )
        }

        // Danger Zone Full Purge Dialog
        if (showPurgeDangerDialog) {
            AlertDialog(
                onDismissRequest = { showPurgeDangerDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = LsRust500, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Confirm Total Wipe", fontWeight = FontWeight.Bold, color = LsRust700)
                    }
                },
                text = {
                    Column {
                        Text(
                            "This will immediately clear all SQLite records (scans, ledger, history) and delete all photo files on disk.",
                            color = LsCocoa900,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Checkbox(
                                checked = purgeConfirmedCheckbox,
                                onCheckedChange = { purgeConfirmedCheckbox = it },
                                colors = CheckboxDefaults.colors(checkedColor = LsRust500)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "I understand all data will be permanently destroyed.",
                                fontSize = 12.sp,
                                color = LsRust700,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (purgeConfirmedCheckbox) {
                                viewModel.purgeAllDataAndPhotos()
                                showPurgeDangerDialog = false
                            }
                        },
                        enabled = purgeConfirmedCheckbox,
                        colors = ButtonDefaults.buttonColors(containerColor = LsRust500),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Confirm Permanent Delete", color = LsLinen, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    Button(
                        onClick = { showPurgeDangerDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = LsBeige100),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Cancel", color = LsCocoa900)
                    }
                },
                containerColor = LsLinen,
                shape = RoundedCornerShape(14.dp)
            )
        }
    }
}
