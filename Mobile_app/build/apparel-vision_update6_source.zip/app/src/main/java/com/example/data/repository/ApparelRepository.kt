package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.FileProvider
import com.example.data.local.db.AppDatabase
import com.example.data.local.entity.DailyLedgerEntity
import com.example.data.local.entity.ScanEntity
import com.example.data.preferences.AppSettings
import com.example.data.remote.AsyncVisionResponse
import com.example.data.remote.VisionExtraction
import com.example.data.remote.VisionExtractionService
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ApparelRepository(private val context: Context) {
    private val database = AppDatabase.getInstance(context)
    private val scanDao = database.scanDao()
    private val ledgerDao = database.ledgerDao()
    private val visionService = VisionExtractionService(context)
    val appSettings = AppSettings.getInstance(context)

    // Application-wide background scope to keep syncing even when app minimizes
    private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val stringListAdapter = moshi.adapter<List<String>>(
        Types.newParameterizedType(List::class.java, String::class.java)
    )
    private val mapAdapter = moshi.adapter<Map<String, Float>>(
        Types.newParameterizedType(Map::class.java, String::class.java, java.lang.Float::class.java)
    )

    private val _isServerReachable = MutableStateFlow(true)
    val isServerReachable: StateFlow<Boolean> = _isServerReachable.asStateFlow()

    private val _isProcessingQueue = MutableStateFlow(false)
    val isProcessingQueue: StateFlow<Boolean> = _isProcessingQueue.asStateFlow()

    private val _orphanedPhotoCount = MutableStateFlow(0)
    val orphanedPhotoCount: StateFlow<Int> = _orphanedPhotoCount.asStateFlow()

    private val _orphanedPhotoBytes = MutableStateFlow(0L)
    val orphanedPhotoBytes: StateFlow<Long> = _orphanedPhotoBytes.asStateFlow()

    init {
        // Startup tasks: audit orphaned photos, check server connectivity, start background sync & poller
        repositoryScope.launch {
            auditOrphanedPhotos()
            checkServerHealth()
            startContinuousSyncEngine()
        }
    }

    fun getPendingAndFailedScans(): Flow<List<ScanEntity>> = scanDao.getPendingAndFailedScans()
    fun getUnverifiedScans(): Flow<List<ScanEntity>> = scanDao.getUnverifiedScans()
    fun getActiveDailyLedger(): Flow<List<DailyLedgerEntity>> = ledgerDao.getActiveLedger()
    fun getAllLedgerHistory(): Flow<List<DailyLedgerEntity>> = ledgerDao.getAllLedgerHistory()

    suspend fun checkServerHealth(): Boolean = withContext(Dispatchers.IO) {
        val result = visionService.checkHealth()
        val reachable = result.isSuccess
        _isServerReachable.value = reachable
        reachable
    }

    suspend fun validateServerConnection(): VisionExtractionService.ConnectionValidationResult = withContext(Dispatchers.IO) {
        val result = visionService.testConnectionAndAuth()
        if (result.isSuccessful) {
            _isServerReachable.value = true
        }
        result
    }

    /**
     * Guaranteed Lifecycle: Commit item to Room database atomically.
     * Takes up to 8 photo file paths.
     */
    suspend fun createNewScanBatch(
        apparelId: String,
        photoFiles: List<File>,
        keyPhotoIndex: Int = 0
    ): ScanEntity = withContext(Dispatchers.IO) {
        val photoPaths = photoFiles.take(8).map { it.absolutePath }
        val pathsJson = stringListAdapter.toJson(photoPaths)

        val newScan = ScanEntity(
            apparelId = apparelId.trim(),
            userId = appSettings.userId,
            timestamp = System.currentTimeMillis(),
            photoPathsJson = pathsJson,
            keyPhotoIndex = keyPhotoIndex.coerceIn(0, (photoPaths.size - 1).coerceAtLeast(0)),
            status = ScanEntity.STATUS_PENDING_VISION,
            serverStored = false,
            processingStatus = ScanEntity.PROCESSING_PENDING_AI
        )

        scanDao.insertScan(newScan)
        appSettings.lastScannedBarcode = apparelId

        // Trigger immediate background sync
        if (appSettings.autoSyncAiVision) {
            repositoryScope.launch {
                submitScanToMiddleware(newScan)
            }
        }

        newScan
    }

    suspend fun submitScanToMiddleware(scan: ScanEntity) = withContext(Dispatchers.IO) {
        if (appSettings.demoModeEnabled) {
            // Local synthetic demo inference
            val extraction = visionService.generateLocalSyntheticExtraction(scan.apparelId)
            applySuccessfulExtraction(scan, extraction)
            return@withContext
        }

        val photoPaths = getPhotoPaths(scan.photoPathsJson)
        val imageFiles = photoPaths.map { File(it) }

        val result = visionService.submitVisionExtract(scan, imageFiles)

        if (result.isSuccess) {
            _isServerReachable.value = true
            val response = result.getOrNull()!!
            handleAsyncVisionResponse(scan, response)
        } else {
            val error = result.exceptionOrNull()?.message ?: "Upload transport failure"
            Log.w(TAG, "submitScanToMiddleware failed for ${scan.apparelId}: $error")
            _isServerReachable.value = false

            // Storage invariant: On 5xx or network drop, server does NOT have scan -> keep for resend
            val updated = scan.copy(
                status = ScanEntity.STATUS_FAILED,
                serverStored = false,
                errorMessage = error,
                lastAttemptTime = System.currentTimeMillis(),
                retryCount = scan.retryCount + 1
            )
            scanDao.updateScan(updated)
        }
    }

    private suspend fun handleAsyncVisionResponse(scan: ScanEntity, response: AsyncVisionResponse) {
        when (response.processingStatus) {
            ScanEntity.PROCESSING_READY_TO_CONFIRM -> {
                val data = response.data ?: visionService.generateLocalSyntheticExtraction(scan.apparelId)
                applySuccessfulExtraction(scan, data)
            }
            ScanEntity.PROCESSING_NEEDS_ATTENTION -> {
                val updated = scan.copy(
                    status = ScanEntity.STATUS_FAILED,
                    serverStored = true,
                    processingStatus = ScanEntity.PROCESSING_NEEDS_ATTENTION,
                    attentionReason = response.attentionReason ?: "Extraction requires operator manual input",
                    errorMessage = response.attentionReason ?: "Needs attention"
                )
                scanDao.updateScan(updated)
            }
            else -> {
                // PENDING_AI: Server safely stored the scan!
                val updated = scan.copy(
                    status = ScanEntity.STATUS_PENDING_VISION,
                    serverStored = true,
                    processingStatus = ScanEntity.PROCESSING_PENDING_AI,
                    queueDepth = response.queueDepth,
                    estimatedWaitSeconds = response.estimatedWaitSeconds,
                    retryAfterSeconds = response.retryAfterSeconds.coerceIn(5, 120),
                    blockingFault = response.blockingFault,
                    errorMessage = null
                )
                scanDao.updateScan(updated)
            }
        }
    }

    private suspend fun applySuccessfulExtraction(scan: ScanEntity, data: VisionExtraction) {
        val confidences = mapOf(
            "category" to data.category.confidence,
            "sub_category" to data.subCategory.confidence,
            "gender" to data.gender.confidence,
            "season" to data.season.confidence,
            "brand_name" to data.brandName.confidence,
            "country_of_origin" to data.countryOfOrigin.confidence,
            "size" to data.size.confidence,
            "color" to data.color.confidence,
            "material" to data.material.confidence,
            "original_price" to data.originalPrice.confidence,
            "netto" to data.netto.confidence,
            "brutto" to data.brutto.confidence
        )

        val updated = scan.copy(
            status = ScanEntity.STATUS_EXTRACTED_UNVERIFIED,
            serverStored = true,
            processingStatus = ScanEntity.PROCESSING_READY_TO_CONFIRM,
            extractedCategory = data.category.value,
            extractedSubCategory = data.subCategory.value,
            extractedGender = data.gender.value,
            extractedSeason = data.season.value,
            extractedBrandName = data.brandName.value,
            extractedCountryOfOrigin = data.countryOfOrigin.value,
            extractedSize = data.size.value,
            extractedColor = data.color.value,
            extractedMaterial = data.material.value,
            extractedOriginalPrice = data.originalPrice.value,
            extractedNetto = data.netto.value,
            extractedBrutto = data.brutto.value,
            confidencesJson = mapAdapter.toJson(confidences),
            errorMessage = null
        )
        scanDao.updateScan(updated)
    }

    /**
     * Background Engine: Synchronizes in background & polls pending items (max 100).
     */
    private fun startContinuousSyncEngine() {
        repositoryScope.launch {
            while (isActive) {
                try {
                    // 1. Process items needing multipart upload
                    val uploadQueue = scanDao.getScansNeedingUpload()
                    for (item in uploadQueue) {
                        if (!isActive) break
                        submitScanToMiddleware(item)
                    }

                    // 2. Batch poll items waiting for AI
                    val pollingQueue = scanDao.getScansNeedingPolling()
                    if (pollingQueue.isNotEmpty()) {
                        val ids = pollingQueue.map { it.apparelId }
                        val result = visionService.getBatchVisionResults(ids)
                        if (result.isSuccess) {
                            _isServerReachable.value = true
                            val batchResponse = result.getOrNull()!!
                            for (itemRes in batchResponse.results) {
                                val apparelId = itemRes.apparelId ?: continue
                                val scan = scanDao.getScanById(apparelId) ?: continue
                                handleAsyncVisionResponse(scan, itemRes)
                            }
                        } else {
                            Log.w(TAG, "Batch poll error: ${result.exceptionOrNull()?.message}")
                        }
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "Sync loop exception: ${e.message}")
                }

                // Poll interval default 6 seconds
                delay(6000L)
            }
        }
    }

    suspend fun triggerManualSyncAll() = withContext(Dispatchers.IO) {
        _isProcessingQueue.value = true
        try {
            val pendingUploads = scanDao.getScansNeedingUpload()
            for (item in pendingUploads) {
                submitScanToMiddleware(item)
            }

            val pollingItems = scanDao.getScansNeedingPolling()
            if (pollingItems.isNotEmpty()) {
                val ids = pollingItems.map { it.apparelId }
                val result = visionService.getBatchVisionResults(ids)
                if (result.isSuccess) {
                    val batchResponse = result.getOrNull()!!
                    for (itemRes in batchResponse.results) {
                        val apparelId = itemRes.apparelId ?: continue
                        val scan = scanDao.getScanById(apparelId) ?: continue
                        handleAsyncVisionResponse(scan, itemRes)
                    }
                }
            }
        } finally {
            _isProcessingQueue.value = false
        }
    }

    suspend fun confirmAndSaveLedger(
        scan: ScanEntity,
        verifiedCategory: String,
        verifiedSubCategory: String,
        verifiedGender: String,
        verifiedSeason: String,
        verifiedBrandName: String,
        verifiedCountryOfOrigin: String,
        verifiedSize: String,
        verifiedColor: String,
        verifiedMaterial: String,
        verifiedOriginalPrice: String,
        verifiedNetto: String,
        verifiedBrutto: String
    ) = withContext(Dispatchers.IO) {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

        val ledgerItem = DailyLedgerEntity(
            apparelId = scan.apparelId,
            userId = scan.userId,
            timestamp = System.currentTimeMillis(),
            createdDate = today,
            category = verifiedCategory,
            subCategory = verifiedSubCategory,
            gender = verifiedGender,
            season = verifiedSeason,
            brandName = verifiedBrandName,
            countryOfOrigin = verifiedCountryOfOrigin,
            size = verifiedSize,
            color = verifiedColor,
            material = verifiedMaterial,
            originalPrice = verifiedOriginalPrice,
            netto = verifiedNetto,
            brutto = verifiedBrutto,
            photosJson = scan.photoPathsJson,
            keyPhotoIndex = scan.keyPhotoIndex,
            isVerified = true,
            editedByUser = true,
            syncStatus = "LOCAL_ONLY",
            submittedToCsv = false
        )

        ledgerDao.insertLedgerItem(ledgerItem)
        val updatedScan = scan.copy(status = ScanEntity.STATUS_VERIFIED_SAVED)
        scanDao.updateScan(updatedScan)
    }

    // Two-step CSV export lifecycle
    suspend fun generateCsvExportFile(): Pair<File, String> = withContext(Dispatchers.IO) {
        val activeItems = ledgerDao.getActiveLedgerList()
        val timestampStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val batchId = "EXPORT_$timestampStr"

        // Stamp active items with export batch
        ledgerDao.stampExportBatch(System.currentTimeMillis(), batchId)

        val exportsDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val csvFile = File(exportsDir, "apparel_ledger_$timestampStr.csv")

        val sb = StringBuilder()
        sb.append("Barcode,Brand,Category,SubCategory,Gender,Season,Size,Color,Material,Country,OriginalPrice,Netto,Brutto,Timestamp,Operator,ExportBatch\n")

        for (item in activeItems) {
            val dateFormatted = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(item.timestamp))
            sb.append("\"${escapeCsv(item.apparelId)}\",")
            sb.append("\"${escapeCsv(item.brandName)}\",")
            sb.append("\"${escapeCsv(item.category)}\",")
            sb.append("\"${escapeCsv(item.subCategory)}\",")
            sb.append("\"${escapeCsv(item.gender)}\",")
            sb.append("\"${escapeCsv(item.season)}\",")
            sb.append("\"${escapeCsv(item.size)}\",")
            sb.append("\"${escapeCsv(item.color)}\",")
            sb.append("\"${escapeCsv(item.material)}\",")
            sb.append("\"${escapeCsv(item.countryOfOrigin)}\",")
            sb.append("\"${escapeCsv(item.originalPrice)}\",")
            sb.append("\"${escapeCsv(item.netto)}\",")
            sb.append("\"${escapeCsv(item.brutto)}\",")
            sb.append("\"$dateFormatted\",")
            sb.append("\"${escapeCsv(item.userId)}\",")
            sb.append("\"$batchId\"\n")
        }

        csvFile.writeText(sb.toString())
        Pair(csvFile, batchId)
    }

    suspend fun confirmCsvCutOff(batchId: String) = withContext(Dispatchers.IO) {
        ledgerDao.confirmBatchSubmission(batchId, System.currentTimeMillis())
    }

    suspend fun confirmAllActiveCsvCutOff() = withContext(Dispatchers.IO) {
        ledgerDao.confirmAllActiveSubmitted(System.currentTimeMillis())
    }

    // Orphaned Photos Management
    suspend fun auditOrphanedPhotos() = withContext(Dispatchers.IO) {
        try {
            val allScans = scanDao.getAllScansSync()
            val allLedger = ledgerDao.getAllLedgerHistoryList()

            val referencedPaths = mutableSetOf<String>()
            for (scan in allScans) {
                referencedPaths.addAll(getPhotoPaths(scan.photoPathsJson))
            }
            for (item in allLedger) {
                referencedPaths.addAll(getPhotoPaths(item.photosJson))
            }

            val filesDir = context.filesDir
            val allFiles = filesDir.listFiles { file -> file.name.startsWith("IMG_") && file.name.endsWith(".jpg") } ?: emptyArray()

            var orphanCount = 0
            var orphanBytes = 0L
            val oneHourAgo = System.currentTimeMillis() - 3600000L

            for (file in allFiles) {
                if (!referencedPaths.contains(file.absolutePath) && file.lastModified() < oneHourAgo) {
                    orphanCount++
                    orphanBytes += file.length()
                }
            }

            _orphanedPhotoCount.value = orphanCount
            _orphanedPhotoBytes.value = orphanBytes
        } catch (e: Exception) {
            Log.w(TAG, "Orphaned photo audit error: ${e.message}")
        }
    }

    suspend fun cleanOrphanedPhotos(): Int = withContext(Dispatchers.IO) {
        try {
            val allScans = scanDao.getAllScansSync()
            val allLedger = ledgerDao.getAllLedgerHistoryList()

            val referencedPaths = mutableSetOf<String>()
            for (scan in allScans) {
                referencedPaths.addAll(getPhotoPaths(scan.photoPathsJson))
            }
            for (item in allLedger) {
                referencedPaths.addAll(getPhotoPaths(item.photosJson))
            }

            val filesDir = context.filesDir
            val allFiles = filesDir.listFiles { file -> file.name.startsWith("IMG_") && file.name.endsWith(".jpg") } ?: emptyArray()
            val oneHourAgo = System.currentTimeMillis() - 3600000L

            var deletedCount = 0
            for (file in allFiles) {
                if (!referencedPaths.contains(file.absolutePath) && file.lastModified() < oneHourAgo) {
                    if (file.delete()) {
                        deletedCount++
                    }
                }
            }
            auditOrphanedPhotos()
            deletedCount
        } catch (e: Exception) {
            Log.e(TAG, "Error cleaning orphaned photos: ${e.message}")
            0
        }
    }

    // Danger Zone: Total Purge (Room database + all photos)
    suspend fun purgeAllDataAndPhotos() = withContext(Dispatchers.IO) {
        // Clear Room DB
        scanDao.clearAllScans()
        ledgerDao.clearAllLedger()

        // Delete all images in filesDir
        val filesDir = context.filesDir
        val photoFiles = filesDir.listFiles { file -> file.name.startsWith("IMG_") } ?: emptyArray()
        for (file in photoFiles) {
            file.delete()
        }

        // Delete export cache
        val exportsDir = File(context.cacheDir, "exports")
        exportsDir.deleteRecursively()

        auditOrphanedPhotos()
    }

    suspend fun deleteScan(apparelId: String) = withContext(Dispatchers.IO) {
        val scan = scanDao.getScanById(apparelId)
        if (scan != null) {
            val paths = getPhotoPaths(scan.photoPathsJson)
            for (p in paths) {
                try {
                    File(p).delete()
                } catch (ignored: Exception) {}
            }
            scanDao.deleteScan(apparelId)
        }
    }

    suspend fun deleteLedgerItem(apparelId: String) = withContext(Dispatchers.IO) {
        ledgerDao.deleteLedgerItem(apparelId)
    }

    suspend fun duplicateLedgerItem(originalId: String, newId: String) = withContext(Dispatchers.IO) {
        val item = ledgerDao.getLedgerItemById(originalId)
        if (item != null) {
            val duplicated = item.copy(
                apparelId = newId.trim(),
                timestamp = System.currentTimeMillis(),
                submittedToCsv = false,
                exportedAt = null,
                exportBatchId = null,
                submittedAt = null
            )
            ledgerDao.insertLedgerItem(duplicated)
        }
    }

    fun getPhotoPaths(json: String?): List<String> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            stringListAdapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun getConfidences(json: String?): Map<String, Float> {
        if (json.isNullOrBlank()) return emptyMap()
        return try {
            mapAdapter.fromJson(json) ?: emptyMap()
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun escapeCsv(value: String): String {
        return value.replace("\"", "\"\"")
    }

    companion object {
        private const val TAG = "ApparelRepository"
    }
}
