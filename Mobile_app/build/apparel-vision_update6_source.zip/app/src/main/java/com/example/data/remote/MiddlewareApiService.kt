package com.example.data.remote

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query

interface MiddlewareApiService {
    @POST("api/v1/auth/login")
    suspend fun login(
        @Body request: LoginRequest
    ): Response<LoginResponse>

    @GET("health")
    suspend fun checkHealth(): Response<HealthResponse>

    @GET("api/v1/health")
    suspend fun checkHealthApiV1(): Response<HealthResponse>

    // v1.1 Async submission (returns 202 Accepted)
    @Multipart
    @POST("api/v1/vision/extract")
    suspend fun submitVisionExtract(
        @Header("Authorization") authorization: String,
        @Part("apparel_id") apparelId: RequestBody,
        @Part("username") username: RequestBody,
        @Part("key_photo_index") keyPhotoIndex: RequestBody,
        @Part("cloned_from") clonedFrom: RequestBody?,
        @Part images: List<MultipartBody.Part>
    ): Response<AsyncVisionResponse>

    // v1.1 Single result fetch
    @GET("api/v1/vision/result/{apparel_id}")
    suspend fun getVisionResult(
        @Header("Authorization") authorization: String,
        @Path("apparel_id") apparelId: String
    ): Response<AsyncVisionResponse>

    // v1.1 Batch results fetch (max 100 ids)
    @GET("api/v1/vision/results")
    suspend fun getBatchVisionResults(
        @Header("Authorization") authorization: String,
        @Query("ids") idsCommaSeparated: String
    ): Response<BatchVisionResultsResponse>
}
