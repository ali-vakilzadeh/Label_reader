package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class AppSettings(context: Context) {
    private val prefs: SharedPreferences = try {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            PREFS_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (t: Throwable) {
        Log.w("AppSettings", "EncryptedSharedPreferences init fallback: ${t.message}")
        context.getSharedPreferences(FALLBACK_PREFS_NAME, Context.MODE_PRIVATE)
    }

    var userId: String
        get() = prefs.getString(KEY_USER_ID, "operator_01") ?: "operator_01"
        set(value) = prefs.edit().putString(KEY_USER_ID, value.trim()).apply()

    var devicePassword: String
        get() = prefs.getString(KEY_DEVICE_PASSWORD, "enterprise2026") ?: "enterprise2026"
        set(value) = prefs.edit().putString(KEY_DEVICE_PASSWORD, value.trim()).apply()

    var serverUrl: String
        get() = prefs.getString(KEY_SERVER_URL, "http://10.0.2.2:3000") ?: "http://10.0.2.2:3000"
        set(value) {
            val formatted = normalizeServerUrl(value)
            prefs.edit().putString(KEY_SERVER_URL, formatted).apply()
        }

    var sessionToken: String?
        get() = prefs.getString(KEY_SESSION_TOKEN, null)?.takeIf { it.isNotBlank() }
        set(value) {
            if (value.isNullOrBlank()) {
                prefs.edit().remove(KEY_SESSION_TOKEN).apply()
            } else {
                prefs.edit().putString(KEY_SESSION_TOKEN, value.trim()).apply()
            }
        }

    var defaultStartDestination: String
        get() = prefs.getString(KEY_DEFAULT_START_DESTINATION, "review") ?: "review"
        set(value) = prefs.edit().putString(KEY_DEFAULT_START_DESTINATION, value).apply()

    var autoSyncAiVision: Boolean
        get() = prefs.getBoolean(KEY_AUTO_SYNC_AI, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_SYNC_AI, value).apply()

    var demoModeEnabled: Boolean
        get() = prefs.getBoolean(KEY_DEMO_MODE_ENABLED, false) // Default is OFF
        set(value) = prefs.edit().putBoolean(KEY_DEMO_MODE_ENABLED, value).apply()

    var isDemoModeConfigured: Boolean
        get() = prefs.getBoolean(KEY_DEMO_MODE_CONFIGURED, false)
        set(value) = prefs.edit().putBoolean(KEY_DEMO_MODE_CONFIGURED, value).apply()

    var lastScannedBarcode: String?
        get() = prefs.getString(KEY_LAST_BARCODE, null)
        set(value) = prefs.edit().putString(KEY_LAST_BARCODE, value).apply()

    @Synchronized
    fun getNextDemoId(): String {
        val nextNum = prefs.getInt(KEY_DEMO_COUNTER, 1)
        prefs.edit().putInt(KEY_DEMO_COUNTER, nextNum + 1).apply()
        return String.format(java.util.Locale.US, "demo_%04d", nextNum)
    }

    fun clearAuth() {
        prefs.edit().remove(KEY_SESSION_TOKEN).apply()
    }

    companion object {
        private const val PREFS_NAME = "apparel_vision_secure_prefs"
        private const val FALLBACK_PREFS_NAME = "apparel_vision_settings"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_DEVICE_PASSWORD = "device_password"
        private const val KEY_SERVER_URL = "server_url"
        private const val KEY_SESSION_TOKEN = "session_token"
        private const val KEY_DEFAULT_START_DESTINATION = "default_start_destination"
        private const val KEY_AUTO_SYNC_AI = "auto_sync_ai"
        private const val KEY_DEMO_MODE_ENABLED = "demo_mode_enabled"
        private const val KEY_DEMO_MODE_CONFIGURED = "demo_mode_configured"
        private const val KEY_DEMO_COUNTER = "demo_counter_seq"
        private const val KEY_LAST_BARCODE = "last_scanned_barcode"

        @Volatile
        private var INSTANCE: AppSettings? = null

        fun normalizeServerUrl(input: String): String {
            var url = input.trim()
            if (url.isBlank()) return "http://10.0.2.2:3000"
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "http://$url"
            }
            url = url.trimEnd('/')
            if (url.endsWith("/api/v1", ignoreCase = true)) {
                url = url.substring(0, url.length - "/api/v1".length).trimEnd('/')
            }
            return url
        }

        fun getInstance(context: Context): AppSettings {
            return INSTANCE ?: synchronized(this) {
                val instance = AppSettings(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
