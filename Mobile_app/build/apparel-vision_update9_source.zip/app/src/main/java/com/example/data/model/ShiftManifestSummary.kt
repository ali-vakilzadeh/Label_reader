package com.example.data.model

data class ShiftManifestSummary(
    val batchId: String,
    val operatorId: String,
    val totalItems: Int,
    val cutOffTimestamp: Long,
    val categoryCounts: Map<String, Int>,
    val subCategoryCounts: Map<String, Int>,
    val genderCounts: Map<String, Int>,
    val seasonCounts: Map<String, Int>,
    val brandCounts: Map<String, Int>,
    val totalEstimatedValue: Double,
    val syncStatus: String,
    val careInfoCoverageCount: Int,
    val packageCodes: List<String>,
    val generatedAt: Long = System.currentTimeMillis()
)
