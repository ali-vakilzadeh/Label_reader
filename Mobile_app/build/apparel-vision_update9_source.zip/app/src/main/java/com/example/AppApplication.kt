package com.example

import android.app.Application
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AppApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "AppApplication onCreate initialized")

        // Safely initialize ML Kit Context
        try {
            com.google.mlkit.common.sdkinternal.MlKitContext.initializeIfNeeded(this)
        } catch (t: Throwable) {
            Log.w(TAG, "MlKitContext initialization: ${t.message}")
        }

        // Install uncaught exception handler to capture and persist any startup/runtime crashes
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val timeStamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
                val crashReport = buildString {
                    appendLine("================ FATAL APPLICATION CRASH ================")
                    appendLine("Timestamp: $timeStamp")
                    appendLine("Thread: ${thread.name} (id: ${thread.id})")
                    appendLine("Exception: ${throwable.javaClass.name}")
                    appendLine("Message: ${throwable.message}")
                    appendLine("----------------- Full Stack Trace -----------------")
                    appendLine(Log.getStackTraceString(throwable))
                    appendLine("==========================================================")
                }

                Log.e(TAG, crashReport)

                // Save to app files dir so it can be extracted via adb or user inspection
                val crashFile = File(filesDir, "last_crash.txt")
                crashFile.writeText(crashReport)
            } catch (e: Exception) {
                Log.e(TAG, "Error writing crash report: ${e.message}")
            } finally {
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
    }

    companion object {
        private const val TAG = "ApparelVisionCrash"
    }
}
