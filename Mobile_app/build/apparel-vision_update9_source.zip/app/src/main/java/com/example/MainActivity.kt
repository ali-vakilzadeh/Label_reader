package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.RateReview
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.ListAlt
import androidx.compose.material.icons.outlined.RateReview
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.CaptureScreen
import com.example.ui.screens.DailyLedgerScreen
import com.example.ui.screens.ReviewScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.LsBeige100
import com.example.ui.theme.LsBeige300
import com.example.ui.theme.LsCocoa400
import com.example.ui.theme.LsCocoa600
import com.example.ui.theme.LsCocoa900
import com.example.ui.theme.LsCream50
import com.example.ui.theme.LsCreme
import com.example.ui.theme.LsGold200
import com.example.ui.theme.LsGold500
import com.example.ui.theme.LsGold800
import com.example.ui.theme.LsGoldWash
import com.example.ui.theme.LsLinen
import com.example.ui.theme.LsNavy800
import com.example.ui.theme.LsNavy900
import com.example.ui.theme.LsRust50
import com.example.ui.theme.LsRust500
import com.example.ui.theme.LsRust700
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ApparelViewModel

sealed class AppDestination(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    object Capture : AppDestination(
        route = "capture",
        title = "Scan",
        selectedIcon = Icons.Filled.CameraAlt,
        unselectedIcon = Icons.Outlined.CameraAlt
    )
    object Review : AppDestination(
        route = "review",
        title = "Review",
        selectedIcon = Icons.Filled.RateReview,
        unselectedIcon = Icons.Outlined.RateReview
    )
    object DailyLedger : AppDestination(
        route = "ledger",
        title = "Ledger",
        selectedIcon = Icons.Filled.ListAlt,
        unselectedIcon = Icons.Outlined.ListAlt
    )
    object Settings : AppDestination(
        route = "settings",
        title = "Settings",
        selectedIcon = Icons.Filled.Settings,
        unselectedIcon = Icons.Outlined.Settings
    )
}

class MainActivity : ComponentActivity() {
    private val viewModel: ApparelViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                ApparelVisionApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun ApparelVisionApp(viewModel: ApparelViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()

    val currentRoute = navBackStackEntry?.destination?.route ?: AppDestination.Review.route

    val pendingScans by viewModel.pendingScans.collectAsStateWithLifecycle()
    val unverifiedScans by viewModel.unverifiedScans.collectAsStateWithLifecycle()
    val totalPending = pendingScans.size + unverifiedScans.size

    val context = LocalContext.current

    LaunchedEffect(Unit) {
        try {
            val hasCredentials = viewModel.appSettings.userId.isNotBlank() && viewModel.appSettings.devicePassword.isNotBlank()
            val rawTarget = if (!hasCredentials) {
                AppDestination.Settings.route
            } else {
                val preferred = viewModel.appSettings.defaultStartDestination
                if (preferred.isNotBlank()) preferred else AppDestination.Capture.route
            }
            val targetRoute = when (rawTarget) {
                "intake", "capture" -> AppDestination.Capture.route
                "review" -> AppDestination.Review.route
                "ledger" -> AppDestination.DailyLedger.route
                "settings" -> AppDestination.Settings.route
                else -> AppDestination.Capture.route
            }
            if (targetRoute != AppDestination.Capture.route) {
                navController.navigate(targetRoute) {
                    popUpTo(navController.graph.findStartDestination().id) {
                        saveState = true
                    }
                    launchSingleTop = true
                }
            }
        } catch (e: Exception) {
            android.util.Log.e("MainActivity", "Startup navigation safety handled: ${e.message}", e)
        }
    }

    LaunchedEffect(viewModel.toastMessage) {
        viewModel.toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            viewModel.toastMessage = null
        }
    }

    val destinations = listOf(
        AppDestination.Capture,
        AppDestination.Review,
        AppDestination.DailyLedger,
        AppDestination.Settings
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = LsNavy900,
                tonalElevation = 6.dp,
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("bottom_nav_bar")
            ) {
                destinations.forEach { dest ->
                    val isSelected = currentRoute == dest.route

                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            if (currentRoute != dest.route) {
                                navController.navigate(dest.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = {
                            if (dest == AppDestination.Review && totalPending > 0) {
                                BadgedBox(
                                    badge = {
                                        Badge(
                                            containerColor = LsGold500,
                                            contentColor = LsNavy900
                                        ) {
                                            Text(
                                                text = if (totalPending > 99) "99+" else "$totalPending",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (isSelected) dest.selectedIcon else dest.unselectedIcon,
                                        contentDescription = dest.title
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = if (isSelected) dest.selectedIcon else dest.unselectedIcon,
                                    contentDescription = dest.title
                                )
                            }
                        },
                        label = {
                            Text(
                                text = dest.title,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = LsCream50,
                            selectedTextColor = LsCream50,
                            unselectedIconColor = LsCocoa400,
                            unselectedTextColor = LsCocoa400,
                            indicatorColor = LsNavy800
                        ),
                        modifier = Modifier.testTag("nav_item_${dest.route}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            NavHost(
                navController = navController,
                startDestination = AppDestination.Capture.route,
                modifier = Modifier.fillMaxSize()
            ) {
                composable(AppDestination.Capture.route) {
                    CaptureScreen(
                        viewModel = viewModel,
                        onNavigateToReview = {
                            navController.navigate(AppDestination.Review.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }

                // Compatibility alias for legacy "intake" route
                composable("intake") {
                    CaptureScreen(
                        viewModel = viewModel,
                        onNavigateToReview = {
                            navController.navigate(AppDestination.Review.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }

                composable(AppDestination.Review.route) {
                    ReviewScreen(
                        viewModel = viewModel,
                        onNavigateToCapture = {
                            navController.navigate(AppDestination.Capture.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }

                composable(AppDestination.DailyLedger.route) {
                    DailyLedgerScreen(viewModel = viewModel)
                }

                composable(AppDestination.Settings.route) {
                    SettingsScreen(viewModel = viewModel)
                }
            }

            // Connection Alert Banner
            if (viewModel.showConnectionAlertBanner) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .align(Alignment.TopCenter)
                        .testTag("banner_server_connection_alert"),
                    shape = RoundedCornerShape(12.dp),
                    color = LsRust50,
                    shadowElevation = 8.dp,
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, LsRust500)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = null,
                                tint = LsRust500,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Server Connection Offline",
                                color = LsRust700,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.dismissConnectionAlert() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Dismiss",
                                    tint = LsRust500,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Cannot reach middleware server. Scans are preserved safely in local SQLite and will automatically sync when connection returns.",
                            color = LsNavy900,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = {
                                    viewModel.dismissConnectionAlert()
                                    navController.navigate(AppDestination.Settings.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = LsNavy800)
                            ) {
                                Text("Configure Server Settings", fontSize = 12.sp, color = LsCream50)
                            }
                        }
                    }
                }
            }
        }
    }
}
