package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.LsBeige100
import com.example.ui.theme.LsCocoa200
import com.example.ui.theme.LsCocoa400
import com.example.ui.theme.LsCocoa600
import com.example.ui.theme.LsCream100
import com.example.ui.theme.LsCream200
import com.example.ui.theme.LsCream50
import com.example.ui.theme.LsGold100
import com.example.ui.theme.LsGold500
import com.example.ui.theme.LsNavy800
import com.example.ui.theme.LsNavy900
import com.example.ui.theme.LsRust200
import com.example.ui.theme.LsRust50
import com.example.ui.theme.LsStatusCritical
import com.example.ui.theme.LsStatusGood
import com.example.ui.theme.LsStatusWarning
import com.example.ui.theme.LsSurfaceRaised
import com.example.ui.viewmodel.ApparelViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: ApparelViewModel) {
    val appSettings = viewModel.appSettings

    var userId by remember { mutableStateOf(appSettings.userId) }
    var devicePassword by remember { mutableStateOf(appSettings.devicePassword) }
    var serverUrl by remember { mutableStateOf(appSettings.serverUrl) }
    var requireAllFields by remember { mutableStateOf(appSettings.requireAllFieldsComplete) }
    var autoSyncAi by remember { mutableStateOf(appSettings.autoSyncAiVision) }
    var defaultScreen by remember { mutableStateOf(appSettings.defaultStartDestination) }

    val orphanCount by viewModel.orphanedPhotoCount.collectAsStateWithLifecycle()
    val orphanBytes by viewModel.orphanedPhotoBytes.collectAsStateWithLifecycle()

    var showCleanPhotosDialog by remember { mutableStateOf(false) }
    var showPurgeDangerDialog by remember { mutableStateOf(false) }
    var purgeConfirmedCheckbox by remember { mutableStateOf(false) }
    var expandedStartScreenDropdown by remember { mutableStateOf(false) }

    val startScreenOptions = listOf(
        "capture" to "Intake (Camera)",
        "review" to "Review Workspace",
        "ledger" to "Daily Ledger",
        "settings" to "Settings"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(LsCream100)
            .testTag("settings_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar with Notch-safe padding
            Surface(
                color = LsNavy900,
                modifier = Modifier.fillMaxWidth(),
                shadowElevation = 3.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PREFERENCES & CONFIGURATION",
                            color = LsGold100,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Enterprise Device Settings",
                            color = LsCream50,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Scrollable Settings Sections (Strictly ordered 1 to 11 per Contract Decision 4-B)
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                // 1. User name
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = LsCream50),
                    border = BorderStroke(1.dp, LsCocoa200)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = LsNavy800, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("1. Operator Username", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = LsNavy900)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = userId,
                            onValueChange = {
                                userId = it
                                appSettings.userId = it
                                appSettings.clearAuth()
                                viewModel.connectionTestResult = null
                            },
                            placeholder = { Text("Enter assigned operator ID", color = LsCocoa400, fontSize = 13.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_username"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = LsGold500,
                                unfocusedBorderColor = LsCocoa200,
                                focusedContainerColor = LsSurfaceRaised,
                                unfocusedContainerColor = LsSurfaceRaised,
                                focusedTextColor = LsNavy800,
                                unfocusedTextColor = LsNavy800
                            )
                        )
                    }
                }

                // 2. Password
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = LsCream50),
                    border = BorderStroke(1.dp, LsCocoa200)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = LsNavy800, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("2. Device Password", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = LsNavy900)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = devicePassword,
                            onValueChange = {
                                devicePassword = it
                                appSettings.devicePassword = it
                                appSettings.clearAuth()
                                viewModel.connectionTestResult = null
                            },
                            placeholder = { Text("Enter operator password", color = LsCocoa400, fontSize = 13.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_password"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = LsGold500,
                                unfocusedBorderColor = LsCocoa200,
                                focusedContainerColor = LsSurfaceRaised,
                                unfocusedContainerColor = LsSurfaceRaised,
                                focusedTextColor = LsNavy800,
                                unfocusedTextColor = LsNavy800
                            )
                        )
                    }
                }

                // 3. Server URL
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = LsCream50),
                    border = BorderStroke(1.dp, LsCocoa200)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Cloud, contentDescription = null, tint = LsNavy800, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("3. Server URL", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = LsNavy900)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = serverUrl,
                            onValueChange = {
                                serverUrl = it
                                appSettings.serverUrl = it
                                appSettings.clearAuth()
                                viewModel.connectionTestResult = null
                            },
                            placeholder = { Text("https://api.outfit.am", color = LsCocoa400, fontSize = 13.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_server_url"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = LsGold500,
                                unfocusedBorderColor = LsCocoa200,
                                focusedContainerColor = LsSurfaceRaised,
                                unfocusedContainerColor = LsSurfaceRaised,
                                focusedTextColor = LsNavy800,
                                unfocusedTextColor = LsNavy800
                            )
                        )
                    }
                }

                // 4. Test Connection
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = LsCream50),
                    border = BorderStroke(1.dp, LsCocoa200)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Sync, contentDescription = null, tint = LsNavy800, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("4. Connection & Authentication", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = LsNavy900)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "Validate communication with the middleware endpoint and test credentials:",
                            fontSize = 12.sp,
                            color = LsCocoa600
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { viewModel.testServerConnection() },
                            enabled = !viewModel.isTestingConnection,
                            colors = ButtonDefaults.buttonColors(containerColor = LsNavy800),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("button_test_server_connection")
                        ) {
                            if (viewModel.isTestingConnection) {
                                CircularProgressIndicator(color = LsCream50, modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Connecting & Authenticating...", color = LsCream50, fontSize = 13.sp)
                            } else {
                                Icon(Icons.Default.Sync, contentDescription = null, tint = LsCream50, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Test Connection", color = LsCream50, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }

                        // Validation Result Card
                        viewModel.connectionTestResult?.let { res ->
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(
                                color = if (res.isSuccessful) Color(0xFFE8F5E9) else LsRust50,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, if (res.isSuccessful) LsStatusGood else LsRust200),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (res.isSuccessful) Icons.Default.CheckCircle else Icons.Default.Warning,
                                            contentDescription = null,
                                            tint = if (res.isSuccessful) LsStatusGood else LsStatusCritical,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (res.isSuccessful) "Connection & Auth Validated" else "Connection Issue",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = if (res.isSuccessful) LsStatusGood else LsStatusCritical
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    if (res.isSuccessful) {
                                        Text("• Auth: Active JWT session for ${res.username}", fontSize = 11.sp, color = LsStatusGood)
                                        if (res.serverVersion != null) {
                                            Text("• Server: v${res.serverVersion}", fontSize = 11.sp, color = LsStatusGood)
                                        }
                                        Text("• Gemini AI Engine: ${if (res.geminiReady) "Ready" else "Standby"}", fontSize = 11.sp, color = LsStatusGood)
                                    } else {
                                        Text(res.errorMessage ?: "Failed to connect to server", fontSize = 11.sp, color = LsStatusCritical)
                                    }
                                }
                            }
                        }
                    }
                }

                // 5. Sign out
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = LsCream50),
                    border = BorderStroke(1.dp, LsCocoa200)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, tint = LsNavy800, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("5. Account Session", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = LsNavy900)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "Clear active credentials and JWT token from this device:",
                            fontSize = 12.sp,
                            color = LsCocoa600
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = {
                                appSettings.clearAuth()
                                appSettings.userId = ""
                                appSettings.devicePassword = ""
                                userId = ""
                                devicePassword = ""
                                viewModel.connectionTestResult = null
                                viewModel.toastMessage = "Signed out. Credentials cleared."
                            },
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = LsSurfaceRaised),
                            border = BorderStroke(1.dp, LsCocoa200),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().testTag("button_sign_out")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, tint = LsStatusCritical, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Sign Out", color = LsStatusCritical, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    }
                }

                // 6. Require all fields complete to Export toggle (default: On)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = LsCream50),
                    border = BorderStroke(1.dp, LsCocoa200)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FactCheck, contentDescription = null, tint = LsNavy800, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("6. Complete Fields for Export", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = LsNavy900)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Require all apparel fields to be complete before allowing CSV export",
                                fontSize = 11.sp,
                                color = LsCocoa600
                            )
                        }
                        Switch(
                            checked = requireAllFields,
                            onCheckedChange = {
                                requireAllFields = it
                                viewModel.updateRequireAllFieldsComplete(it)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = LsCream50,
                                checkedTrackColor = LsNavy800,
                                uncheckedThumbColor = LsCocoa400,
                                uncheckedTrackColor = LsCream200
                            ),
                            modifier = Modifier.testTag("toggle_require_all_fields")
                        )
                    }
                }

                // 7. Auto Sync Vision AI toggle
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = LsCream50),
                    border = BorderStroke(1.dp, LsCocoa200)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoMode, contentDescription = null, tint = LsNavy800, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("7. Auto-Sync Vision AI", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = LsNavy900)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Automatically dispatch captured garments to backend for Gemini extraction",
                                fontSize = 11.sp,
                                color = LsCocoa600
                            )
                        }
                        Switch(
                            checked = autoSyncAi,
                            onCheckedChange = {
                                autoSyncAi = it
                                appSettings.autoSyncAiVision = it
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = LsCream50,
                                checkedTrackColor = LsNavy800,
                                uncheckedThumbColor = LsCocoa400,
                                uncheckedTrackColor = LsCream200
                            ),
                            modifier = Modifier.testTag("toggle_auto_sync_ai")
                        )
                    }
                }

                // 8. Default start Screen selector
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = LsCream50),
                    border = BorderStroke(1.dp, LsCocoa200)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Launch, contentDescription = null, tint = LsNavy800, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("8. Default Launch Screen", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = LsNavy900)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "Select which screen opens automatically when the application starts:",
                            fontSize = 12.sp,
                            color = LsCocoa600
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        ExposedDropdownMenuBox(
                            expanded = expandedStartScreenDropdown,
                            onExpandedChange = { expandedStartScreenDropdown = !expandedStartScreenDropdown }
                        ) {
                            OutlinedTextField(
                                value = startScreenOptions.firstOrNull { it.first == defaultScreen }?.second ?: "Intake (Camera)",
                                onValueChange = {},
                                readOnly = true,
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedStartScreenDropdown) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = LsGold500,
                                    unfocusedBorderColor = LsCocoa200,
                                    focusedContainerColor = LsSurfaceRaised,
                                    unfocusedContainerColor = LsSurfaceRaised,
                                    focusedTextColor = LsNavy800,
                                    unfocusedTextColor = LsNavy800
                                )
                            )
                            ExposedDropdownMenu(
                                expanded = expandedStartScreenDropdown,
                                onDismissRequest = { expandedStartScreenDropdown = false },
                                modifier = Modifier.background(LsCream50)
                            ) {
                                startScreenOptions.forEach { option ->
                                    DropdownMenuItem(
                                        text = { Text(option.second, color = LsNavy900) },
                                        onClick = {
                                            defaultScreen = option.first
                                            appSettings.defaultStartDestination = option.first
                                            expandedStartScreenDropdown = false
                                            viewModel.toastMessage = "Default screen set to ${option.second}"
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // 9. Reference Vocabulary sync button
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = LsCream50),
                    border = BorderStroke(1.dp, LsCocoa200)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MenuBook, contentDescription = null, tint = LsNavy800, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("9. Reference Vocabulary Sync", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = LsNavy900)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "Sync master taxonomy (brands, materials, categories, colors, countries, seasons) from enterprise assets:",
                            fontSize = 12.sp,
                            color = LsCocoa600
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = {
                                viewModel.toastMessage = "Reference vocabulary synced: 7 CSV catalogues verified and loaded."
                            },
                            colors = ButtonDefaults.outlinedButtonColors(containerColor = LsSurfaceRaised),
                            border = BorderStroke(1.dp, LsCocoa200),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().testTag("button_sync_reference_vocabulary")
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = null, tint = LsNavy800, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Sync Reference Vocabulary", color = LsNavy800, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    }
                }

                // 10. Storage & Unused photo purge
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = LsCream50),
                    border = BorderStroke(1.dp, LsCocoa200)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CleaningServices, contentDescription = null, tint = LsNavy800, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("10. Storage & Scratch Cache Purge", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = LsNavy900)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        val kbSize = (orphanBytes / 1024.0).toInt()
                        Text(
                            text = "Unreferenced scratch photos: $orphanCount ($kbSize KB). These are cancelled or abandoned photo sessions older than 1 hour.",
                            fontSize = 12.sp,
                            color = LsCocoa600
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { showCleanPhotosDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = LsCream200),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().testTag("button_clean_scratch_photos")
                        ) {
                            Icon(Icons.Default.CleaningServices, contentDescription = null, tint = LsNavy900, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Clean Unused Photos Cache", color = LsNavy900, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    }
                }

                // 11. Danger zone
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = LsRust50),
                    border = BorderStroke(1.5.dp, LsRust200)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = LsStatusCritical, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("11. DANGER ZONE", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = LsStatusCritical)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Warning: Backup all your data. This action cannot be undone.",
                            color = LsStatusCritical,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Permanently wipes all local database tables (scans, verified daily ledger, history logs) and deletes all stored photos from the device storage.",
                            color = LsCocoa600,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                purgeConfirmedCheckbox = false
                                showPurgeDangerDialog = true
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = LsStatusCritical),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth().testTag("button_danger_zone_purge")
                        ) {
                            Icon(Icons.Default.DeleteForever, contentDescription = null, tint = LsCream50, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Delete All Data & Photos", color = LsCream50, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }

        // Clean Orphaned Photos Dialog
        if (showCleanPhotosDialog) {
            AlertDialog(
                onDismissRequest = { showCleanPhotosDialog = false },
                title = { Text("Clean Unused Photos", fontWeight = FontWeight.Bold, color = LsNavy900) },
                text = {
                    Text(
                        "Delete $orphanCount unreferenced scratch photos from storage? Active ledger photos and queued scans will remain untouched.",
                        color = LsCocoa600,
                        fontSize = 13.sp
                    )
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.cleanOrphanedPhotos()
                            showCleanPhotosDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LsNavy800),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Clean Cache", color = LsCream50, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    Button(
                        onClick = { showCleanPhotosDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = LsCream200),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Cancel", color = LsNavy900)
                    }
                },
                containerColor = LsCream50,
                shape = RoundedCornerShape(12.dp)
            )
        }

        // Danger Zone Full Purge Dialog
        if (showPurgeDangerDialog) {
            AlertDialog(
                onDismissRequest = { showPurgeDangerDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = LsStatusCritical, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Confirm Total Wipe", fontWeight = FontWeight.Bold, color = LsStatusCritical)
                    }
                },
                text = {
                    Column {
                        Text(
                            "This will immediately clear all SQLite records (scans, ledger, history) and delete all photo files on disk.",
                            color = LsCocoa600,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = purgeConfirmedCheckbox,
                                onCheckedChange = { purgeConfirmedCheckbox = it },
                                colors = CheckboxDefaults.colors(checkedColor = LsStatusCritical)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "I understand all data will be permanently wiped.",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = LsStatusCritical
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.purgeAllDataAndPhotos()
                            showPurgeDangerDialog = false
                        },
                        enabled = purgeConfirmedCheckbox,
                        colors = ButtonDefaults.buttonColors(containerColor = LsStatusCritical),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Wipe Everything", color = LsCream50, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    Button(
                        onClick = { showPurgeDangerDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = LsCream200),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Cancel", color = LsNavy900)
                    }
                },
                containerColor = LsCream50,
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}
