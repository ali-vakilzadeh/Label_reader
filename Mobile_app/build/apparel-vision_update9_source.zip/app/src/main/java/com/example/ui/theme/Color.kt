package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// =============================================================================
// OutFit Design System Tokens (per label_reader_design_basis.html)
// =============================================================================

// Surfaces
val LsCream100 = Color(0xFFFBF7EE)         // Page background (cream-100)
val LsCream50 = Color(0xFFFEFCF7)          // Card, chrome, tab bar (cream-50)
val LsSurfaceRaised = Color(0xFFFFFFFF)    // Input fill (surface-raised)
val LsCream200 = Color(0xFFF6F0E2)         // Sunken strip, payload block (cream-200)
val LsCream300 = Color(0xFFEFE6D3)         // Locked row (cream-300)
val LsGold100 = Color(0xFFFBF3DD)          // Review block, active tab (gold-100)
val LsNavy900 = Color(0xFF0F2439)          // Brand bar, status bar, titles (navy-900)
val LsCameraScrim = Color(0x5908182C)      // Camera scrim: navy-950 @ 35% (#08182c59)

// Ink and rules
val LsNavy800 = Color(0xFF163150)          // Body, input text, primary rest (navy-800)
val LsCocoa600 = Color(0xFF6B503A)         // Labels, muted meta (cocoa-600)
val LsCocoa400 = Color(0xFFAB8C6D)         // Hints, placeholder, disabled (cocoa-400)
val LsCocoa100 = Color(0xFFEBE0CD)         // Hairline (cocoa-100)
val LsCocoa200 = Color(0xFFDDCCB2)         // Default border (cocoa-200)
val LsGold500 = Color(0xFFC69426)          // Accent border, brackets, active indicator (gold-500)

// Action states
val LsNavy700 = Color(0xFF1D4068)          // Primary hover
val LsNavy950 = Color(0xFF08182C)          // Primary press
val LsPrimaryDisabled = Color(0x80163150)  // Primary disabled (50% alpha)
val LsPrimaryDisabledInk = Color(0x80FEFCF7)

// Status hues (OutFit standard)
val LsStatusCritical = Color(0xFF9E2B1E)    // critical
val LsStatusWarning = Color(0xFF96650F)     // warning
val LsStatusGood = Color(0xFF1F6B4A)        // good
val LsStatusInfo = Color(0xFF1D4F8F)        // info
val LsStatusNeutral = Color(0xFF7B6A58)     // neutral

// Focus & Shutter
val LsFocusOutline = Color(0xFFA8791A)
val LsFocusRing = Color(0xFFF5E5BD)
val LsShutterFill = Color(0xFF163150)
val LsShutterInk = Color(0xFF08182C)
val LsShutterBorder = Color(0xFFFEFCF7)

// Tab bar & Chrome tokens
val LsBarFill = Color(0xFFFEFCF7)          // Tab bar fill
val LsBarTopRule = Color(0xFFDDCCB2)       // Bar top rule, 1px
val LsActiveTabFill = Color(0xFFFBF3DD)    // Active tab fill
val LsActiveTabIndicator = Color(0xFFC69426) // Active tab 2px top indicator
val LsActiveTabLabel = Color(0xFF0F2439)   // Active tab label
val LsInactiveTabLabel = Color(0xFF6B503A) // Inactive tab label & glyph
val LsInactiveTabPressed = Color(0xFFF6F0E2) // Inactive tab pressed fill
val LsBrandBarFill = Color(0xFF0F2439)     // Brand bar fill
val LsBrandBarBottomRule = Color(0xFF1D4068) // Brand bar bottom rule
val LsProductWordmark = Color(0xFFDCB055)  // Product name beside wordmark
val LsStatusMetaOnNavy = Color(0xFFEFE6D3) // Status meta on navy

// =============================================================================
// Compatibility Aliases (Seamless integration with existing codebase)
// =============================================================================
val LsCreme = LsCream100                   // Canvas page (#fbf7ee)
val LsLinen = LsCream50                    // Surface card / chrome (#fefcf7)
val LsBeige100 = LsCream200                // Inset fill (#f6f0e2)
val LsBeige300 = LsCocoa200                // Default border (#ddccb2)

val LsCocoa900 = LsNavy900                 // Primary text / titles (#0f2439)
val LsCocoa500 = LsCocoa400                // Muted hints / placeholder (#ab8c6d)

val LsGold800 = LsNavy900                  // Header / Brand surface (#0f2439)
val LsGold600 = Color(0xFFA87C2E)
val LsGold200 = LsGold100                  // Active highlight (#fbf3dd)
val LsGoldWash = Color(198, 148, 38, (255 * 0.14).toInt())
val LsOchre600 = Color(0xFFC8860F)

// Warnings
val LsRust700 = LsStatusCritical           // #9e2b1e
val LsRust500 = LsStatusCritical           // #9e2b1e
val LsRust200 = Color(0xFFF5C6CB)
val LsRust50 = Color(0xFFFDF2F2)

val GoldTitleGradient = Brush.horizontalGradient(
    listOf(LsGold500, Color(0xFFA87C2E))
)

val GoldStatusBand = LsGold800
val GoldTitleStart = LsGold500
val GoldTitleEnd = Color(0xFFA87C2E)
val GoldTextWash = LsGoldWash
val GoldAccent = LsGold500
val GoldDark = LsGold800
val GoldLightWash = LsGoldWash
val GoldCreme = LsCreme
val BrandScreenBackground = LsCreme

val NavyPrimary = LsNavy900
val NavySecondary = LsNavy800
val BlueAccent = LsNavy800
val CyanAccent = LsGold500

val SlateSurface = LsCreme
val SlateCard = LsLinen
val SlateBorder = LsBeige300
val SlateTextPrimary = LsNavy900
val SlateTextSecondary = LsCocoa600
val SlateDarkText = LsNavy900
val SlateMediumText = LsCocoa600
val SlateMutedText = LsCocoa500
val SlateFieldBg = LsBeige100

val ConfidenceLowYellow = LsGold100
val ConfidenceLowBorder = LsGold500
val ConfidenceLowText = LsStatusWarning

val ConfidenceHighGreen = Color(0xFFE8F5E9)
val ConfidenceHighBorder = LsStatusGood
val ConfidenceHighText = LsStatusGood

val StatusPending = LsCream200
val StatusPendingText = LsNavy800
val StatusSuccess = Color(0xFFE8F5E9)
val StatusSuccessText = LsStatusGood
val StatusError = LsRust50
val StatusErrorText = LsStatusCritical
