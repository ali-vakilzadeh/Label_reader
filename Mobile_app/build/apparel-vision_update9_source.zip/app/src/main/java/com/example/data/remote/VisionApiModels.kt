package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class VisionField(
    @Json(name = "value")
    val value: String = "",
    @Json(name = "confidence")
    val confidence: Float = 0.0f
)

@JsonClass(generateAdapter = true)
data class VisionExtraction(
    @Json(name = "category")
    val category: VisionField = VisionField(),
    @Json(name = "sub_category")
    val subCategory: VisionField = VisionField(),
    @Json(name = "gender")
    val gender: VisionField = VisionField(),
    @Json(name = "season")
    val season: VisionField = VisionField(),
    @Json(name = "brand_name")
    val brandName: VisionField = VisionField(),
    @Json(name = "country_of_origin")
    val countryOfOrigin: VisionField = VisionField(),
    @Json(name = "size")
    val size: VisionField = VisionField(),
    @Json(name = "color")
    val color: VisionField = VisionField(),
    @Json(name = "material")
    val material: VisionField = VisionField(),
    @Json(name = "original_price")
    val originalPrice: VisionField = VisionField(),
    @Json(name = "netto")
    val netto: VisionField = VisionField(),
    @Json(name = "brutto")
    val brutto: VisionField = VisionField(),
    @Json(name = "care_info")
    val careInfo: VisionField = VisionField()
)

// API v1.4 Async Response for POST /api/v1/vision/extract & GET /api/v1/vision/result/:id
@JsonClass(generateAdapter = true)
data class AsyncVisionResponse(
    @Json(name = "status")
    val status: String = "", // "success" or "error"
    @Json(name = "apparel_id")
    val apparelId: String? = null,
    @Json(name = "cloned_from")
    val clonedFrom: String? = null,
    @Json(name = "timestamp")
    val timestamp: String? = null,
    @Json(name = "catalog_image_url")
    val catalogImageUrl: String? = null,
    @Json(name = "processing_status")
    val processingStatus: String? = null, // "PENDING_AI", "READY_TO_CONFIRM", "NEEDS_ATTENTION"
    @Json(name = "queue_depth")
    val queueDepth: Int = 0,
    @Json(name = "estimated_wait_seconds")
    val estimatedWaitSeconds: Int? = null,
    @Json(name = "retry_after_seconds")
    val retryAfterSeconds: Int = 5,
    @Json(name = "blocking_fault")
    val blockingFault: String? = null,
    @Json(name = "attention_reason")
    val attentionReason: String? = null,
    @Json(name = "suggested_key_photo_index")
    val suggestedKeyPhotoIndex: Int? = null,
    @Json(name = "data")
    val data: VisionExtraction? = null,
    @Json(name = "data_hy")
    val dataHy: Map<String, String?>? = null,
    @Json(name = "error_code")
    val errorCode: String? = null,
    @Json(name = "message")
    val message: String? = null
)

// API v1.1 Batch Results Response: GET /api/v1/vision/results?ids=...
@JsonClass(generateAdapter = true)
data class BatchVisionResultsResponse(
    @Json(name = "status")
    val status: String = "",
    @Json(name = "results")
    val results: List<AsyncVisionResponse> = emptyList(),
    @Json(name = "not_found")
    val notFound: List<String> = emptyList(),
    @Json(name = "queue_depth")
    val queueDepth: Int = 0,
    @Json(name = "retry_after_seconds")
    val retryAfterSeconds: Int = 5,
    @Json(name = "error_code")
    val errorCode: String? = null,
    @Json(name = "message")
    val message: String? = null
)

@JsonClass(generateAdapter = true)
data class LoginRequest(
    @Json(name = "username")
    val username: String,
    @Json(name = "password")
    val password: String
)

@JsonClass(generateAdapter = true)
data class LoginResponse(
    @Json(name = "status")
    val status: String = "",
    @Json(name = "token")
    val token: String? = null,
    @Json(name = "expires_in")
    val expiresIn: String? = null,
    @Json(name = "message")
    val message: String? = null,
    @Json(name = "error_code")
    val errorCode: String? = null
)

@JsonClass(generateAdapter = true)
data class HealthResponse(
    @Json(name = "status")
    val status: String = "",
    @Json(name = "uptime_seconds")
    val uptimeSeconds: Long = 0L,
    @Json(name = "version")
    val version: String = "",
    @Json(name = "gemini_ready")
    val geminiReady: Boolean = false
)
