package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.ImageCapture
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FlashAuto
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.ui.components.CameraPreviewView
import com.example.ui.components.ScannerReticleMode
import com.example.ui.components.takePhoto
import com.example.ui.theme.LsCocoa200
import com.example.ui.theme.LsCocoa400
import com.example.ui.theme.LsCocoa600
import com.example.ui.theme.LsCream50
import com.example.ui.theme.LsGold100
import com.example.ui.theme.LsGold500
import com.example.ui.theme.LsNavy800
import com.example.ui.theme.LsNavy900
import com.example.ui.theme.LsStatusCritical
import com.example.ui.theme.LsSurfaceRaised
import com.example.ui.viewmodel.ApparelViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class FlashOption {
    OFF,
    ON,
    AUTO
}

@Composable
fun CaptureScreen(
    viewModel: ApparelViewModel,
    onNavigateToReview: () -> Unit
) {
    val context = LocalContext.current

    // 4-1 & 4-2 Scanner states (mutually exclusive)
    var isBarcodeScannerActive by remember { mutableStateOf(false) }
    var isQrScannerActive by remember { mutableStateOf(false) }

    // 4-6 Flash state (3 states: OFF, ON, AUTO)
    var flashOption by remember { mutableStateOf(FlashOption.OFF) }

    // 4-7 Package Code dialog state
    var showPackageCodeDialog by remember { mutableStateOf(false) }

    // 4-8 Set Size state (1 to 12, default = 1)
    var setSize by remember {
        mutableIntStateOf(viewModel.activeSetSize.toIntOrNull()?.coerceIn(1, 12) ?: 1)
    }

    // 4-9 B Large preview state
    var previewPhotoIndex by remember { mutableStateOf<Int?>(null) }

    // Optional manual barcode entry dialog
    var showBarcodeManualDialog by remember { mutableStateOf(false) }

    val imageCapture = remember {
        ImageCapture.Builder()
            .setFlashMode(ImageCapture.FLASH_MODE_AUTO)
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build()
    }

    // Flash/Torch control based on 4-6 FlashOption
    LaunchedEffect(flashOption) {
        try {
            when (flashOption) {
                FlashOption.OFF -> {
                    viewModel.isTorchEnabled = false
                    imageCapture.flashMode = ImageCapture.FLASH_MODE_OFF
                }
                FlashOption.ON -> {
                    viewModel.isTorchEnabled = true
                    imageCapture.flashMode = ImageCapture.FLASH_MODE_ON
                }
                FlashOption.AUTO -> {
                    viewModel.isTorchEnabled = false
                    imageCapture.flashMode = ImageCapture.FLASH_MODE_AUTO
                }
            }
        } catch (ignored: Exception) {}
    }

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    val activeScannerReticleMode = when {
        isBarcodeScannerActive -> ScannerReticleMode.BARCODE
        isQrScannerActive -> ScannerReticleMode.QR
        else -> ScannerReticleMode.NONE
    }

    // 2- Make the screen "non-scroll"
    // 3- The camera preview must fill the whole screen (not a small view in the middle)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("scan_screen_root")
    ) {
        // 3- Camera preview filling 100% of the screen
        CameraPreviewView(
            modifier = Modifier.fillMaxSize(),
            isTorchEnabled = viewModel.isTorchEnabled,
            imageCapture = imageCapture,
            isBarcodeMode = isBarcodeScannerActive,
            scannerReticleMode = activeScannerReticleMode,
            onBarcodeDetected = { detectedCode ->
                if (isQrScannerActive) {
                    val trimmed = detectedCode.trim()
                    val isUrl = trimmed.startsWith("http://", ignoreCase = true) ||
                            trimmed.startsWith("https://", ignoreCase = true) ||
                            android.util.Patterns.WEB_URL.matcher(trimmed).matches()

                    isQrScannerActive = false
                    if (isUrl) {
                        viewModel.activeCareInfo = trimmed
                        viewModel.toastMessage = "URL extracted"
                    } else {
                        viewModel.toastMessage = "Not a URL"
                    }
                } else {
                    viewModel.setBarcode(detectedCode)
                    isBarcodeScannerActive = false
                    viewModel.toastMessage = "Barcode: $detectedCode"
                }
            }
        )

        // Scanned Barcode / QR / Care URL status HUD chip (Top Center)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(top = 12.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            Surface(
                onClick = { showBarcodeManualDialog = true },
                shape = RoundedCornerShape(20.dp),
                color = Color.Black.copy(alpha = 0.7f),
                border = BorderStroke(
                    1.dp,
                    if (viewModel.activeBarcode.isNotBlank() || viewModel.activeCareInfo.isNotBlank()) LsGold500 else Color.White.copy(alpha = 0.35f)
                ),
                shadowElevation = 4.dp,
                modifier = Modifier.testTag("active_barcode_chip")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        painter = painterResource(
                            if (isQrScannerActive || viewModel.activeCareInfo.isNotBlank()) R.drawable.ic_qr_code else R.drawable.ic_barcode
                        ),
                        contentDescription = null,
                        tint = if (viewModel.activeBarcode.isNotBlank() || viewModel.activeCareInfo.isNotBlank()) LsGold500 else Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (viewModel.activeBarcode.isNotBlank()) {
                            if (viewModel.activeCareInfo.isNotBlank()) {
                                "${viewModel.activeBarcode} • URL attached"
                            } else {
                                viewModel.activeBarcode
                            }
                        } else if (viewModel.activeCareInfo.isNotBlank()) {
                            "Care URL: ${viewModel.activeCareInfo.take(24)}..."
                        } else if (isBarcodeScannerActive) {
                            "Point at Barcode..."
                        } else if (isQrScannerActive) {
                            "Point at QR Code..."
                        } else {
                            "Scan or tap to set Code"
                        },
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = "Edit barcode",
                        tint = Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }

        // 4-3 & 4-9 Left side vertical column: up to 8 square thumbnails
        Column(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(start = 12.dp)
                .testTag("thumbnail_column"),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            for (index in 0 until 8) {
                val photoFile = viewModel.capturedPhotos.getOrNull(index)
                val isFilled = photoFile != null
                val isKey = isFilled && index == viewModel.selectedKeyPhotoIndex

                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (isFilled) Color.Transparent else Color.Black.copy(alpha = 0.2f)
                        )
                        .border(
                            width = if (isKey) 2.dp else 1.dp,
                            color = if (isKey) {
                                LsGold500
                            } else if (isFilled) {
                                Color.White.copy(alpha = 0.85f)
                            } else {
                                Color.White.copy(alpha = 0.35f)
                            },
                            shape = RoundedCornerShape(8.dp)
                        )
                        .then(
                            if (isFilled) {
                                Modifier.clickable { previewPhotoIndex = index }
                            } else Modifier
                        )
                        .testTag("thumbnail_slot_$index")
                ) {
                    if (photoFile != null) {
                        AsyncImage(
                            model = ImageRequest.Builder(context)
                                .data(photoFile)
                                .crossfade(true)
                                .build(),
                            contentDescription = "Photo ${index + 1}",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        // 4-9 A: small "x" icon - removes the photo from scan set
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .align(Alignment.TopEnd)
                                .background(Color.Black.copy(alpha = 0.75f), CircleShape)
                                .clickable { viewModel.removePhotoAt(index) }
                                .testTag("remove_photo_$index"),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Remove photo ${index + 1}",
                                tint = Color.White,
                                modifier = Modifier.size(10.dp)
                            )
                        }

                        // Key photo star indicator
                        if (isKey) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .align(Alignment.BottomStart)
                                    .background(Color.Black.copy(alpha = 0.6f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Star,
                                    contentDescription = "Key Photo",
                                    tint = LsGold500,
                                    modifier = Modifier.size(10.dp)
                                )
                            }
                        }
                    } else {
                        // Empty slot with thin outline and transparent fill
                        Box(
                            modifier = Modifier.fillMaxSize(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${index + 1}",
                                color = Color.White.copy(alpha = 0.3f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Top-Right Floating Controls Column: Flash (4-6) -> Package Code (4-7) -> Set Size (4-8)
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .statusBarsPadding()
                .padding(top = 12.dp, end = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 4-6 Flash icon with 3 states (off - on - auto)
            Surface(
                onClick = {
                    flashOption = when (flashOption) {
                        FlashOption.OFF -> FlashOption.ON
                        FlashOption.ON -> FlashOption.AUTO
                        FlashOption.AUTO -> FlashOption.OFF
                    }
                },
                modifier = Modifier
                    .size(44.dp)
                    .testTag("floating_flash_button"),
                shape = CircleShape,
                color = when (flashOption) {
                    FlashOption.ON -> LsGold500
                    FlashOption.AUTO -> Color(0xFF38BDF8)
                    FlashOption.OFF -> Color.Black.copy(alpha = 0.65f)
                },
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
                shadowElevation = 4.dp
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        imageVector = when (flashOption) {
                            FlashOption.OFF -> Icons.Default.FlashOff
                            FlashOption.ON -> Icons.Default.FlashOn
                            FlashOption.AUTO -> Icons.Default.FlashAuto
                        },
                        contentDescription = "Flash state: ${flashOption.name}",
                        tint = when (flashOption) {
                            FlashOption.ON -> LsNavy900
                            FlashOption.AUTO -> LsNavy900
                            FlashOption.OFF -> Color.White
                        },
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            // 4-7 Floating button (square - top right) for package code
            Surface(
                onClick = { showPackageCodeDialog = true },
                modifier = Modifier
                    .size(44.dp)
                    .testTag("floating_package_code_button"),
                shape = RoundedCornerShape(10.dp),
                color = if (viewModel.activePackageCode.isNotBlank()) LsGold500 else Color.Black.copy(alpha = 0.65f),
                border = BorderStroke(
                    1.dp,
                    if (viewModel.activePackageCode.isNotBlank()) LsGold500 else Color.White.copy(alpha = 0.35f)
                ),
                shadowElevation = 4.dp
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        imageVector = Icons.Default.Inventory2,
                        contentDescription = "Package Code",
                        tint = if (viewModel.activePackageCode.isNotBlank()) LsNavy900 else Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            // 4-8 Floating pair button 50x150 pixels below package code button
            Surface(
                modifier = Modifier
                    .width(50.dp)
                    .height(150.dp)
                    .testTag("floating_set_size_widget"),
                shape = RoundedCornerShape(18.dp),
                color = Color.Black.copy(alpha = 0.65f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.35f)),
                shadowElevation = 4.dp
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Top section: "+" button
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .clickable {
                                if (setSize < 12) {
                                    setSize++
                                    viewModel.activeSetSize = setSize.toString()
                                }
                            }
                            .testTag("set_size_plus_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Increase set size",
                            tint = if (setSize < 12) Color.White else Color.White.copy(alpha = 0.3f),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Divider line
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color.White.copy(alpha = 0.25f))
                    )

                    // Middle section: Current number (min 1, max 12, default 1)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .testTag("set_size_display"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$setSize",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Divider line
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(Color.White.copy(alpha = 0.25f))
                    )

                    // Bottom section: "-" button
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .clickable {
                                if (setSize > 1) {
                                    setSize--
                                    viewModel.activeSetSize = setSize.toString()
                                }
                            }
                            .testTag("set_size_minus_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Remove,
                            contentDescription = "Decrease set size",
                            tint = if (setSize > 1) Color.White else Color.White.copy(alpha = 0.3f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }

        // 4-5 Horizontal row overlaying below the camera screen with equal distance
        // Ordered left to right: shoot - Barcode - QR code - finish (Send)
        // Buttons "shoot" and "finish" are 20% larger than "barcode" and "QR code"
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 20.dp)
                .testTag("bottom_controls_row"),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // 4-3 Main "shoot" button (plain white round button - no icon) (20% larger = 65dp)
            Surface(
                onClick = {
                    if (viewModel.capturedPhotos.size >= 8) {
                        viewModel.toastMessage = "Maximum 8 photos reached"
                        return@Surface
                    }
                    val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                    val photoIndex = viewModel.capturedPhotos.size
                    val barcode = viewModel.activeBarcode.ifBlank { "draft" }
                    val photoFile = File(context.filesDir, "IMG_${barcode}_${timeStamp}_$photoIndex.jpg")

                    takePhoto(
                        context = context,
                        imageCapture = imageCapture,
                        outputFile = photoFile,
                        onSuccess = { file ->
                            viewModel.addCapturedPhoto(file)
                        },
                        onError = { exc ->
                            viewModel.toastMessage = "Capture fallback: ${exc.message}"
                        }
                    )
                },
                modifier = Modifier
                    .size(65.dp)
                    .testTag("shoot_button"),
                shape = CircleShape,
                color = Color.White,
                border = BorderStroke(3.dp, Color.White.copy(alpha = 0.6f)),
                shadowElevation = 6.dp
            ) {
                // Plain white round button - no icon inside
                Box(modifier = Modifier.fillMaxSize())
            }

            // 4-1 Scan barcode button (round button with barcode icon) (54dp)
            Surface(
                onClick = {
                    if (isQrScannerActive) {
                        isQrScannerActive = false
                    }
                    isBarcodeScannerActive = !isBarcodeScannerActive
                },
                modifier = Modifier
                    .size(54.dp)
                    .testTag("scan_barcode_button"),
                shape = CircleShape,
                color = if (isBarcodeScannerActive) LsGold500 else Color.Black.copy(alpha = 0.65f),
                border = BorderStroke(
                    1.5.dp,
                    if (isBarcodeScannerActive) LsGold500 else Color.White.copy(alpha = 0.5f)
                ),
                shadowElevation = 6.dp
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        painter = painterResource(R.drawable.ic_barcode),
                        contentDescription = "Scan Barcode",
                        tint = if (isBarcodeScannerActive) LsNavy900 else Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // 4-2 Scan QR code button (round button with QR icon) (54dp)
            Surface(
                onClick = {
                    if (isBarcodeScannerActive) {
                        isBarcodeScannerActive = false
                    }
                    isQrScannerActive = !isQrScannerActive
                },
                modifier = Modifier
                    .size(54.dp)
                    .testTag("scan_qr_button"),
                shape = CircleShape,
                color = if (isQrScannerActive) LsGold500 else Color.Black.copy(alpha = 0.65f),
                border = BorderStroke(
                    1.5.dp,
                    if (isQrScannerActive) LsGold500 else Color.White.copy(alpha = 0.5f)
                ),
                shadowElevation = 6.dp
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Icon(
                        painter = painterResource(R.drawable.ic_qr_code),
                        contentDescription = "Scan QR Code",
                        tint = if (isQrScannerActive) LsNavy900 else Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // 4-4 Floating round button "Send" ("send" icon over round button) (20% larger = 65dp)
            Surface(
                onClick = {
                    if (viewModel.capturedPhotos.isEmpty()) {
                        viewModel.toastMessage = "Please shoot at least one photo"
                        return@Surface
                    }
                    if (viewModel.activeBarcode.isBlank()) {
                        val autoId = "ITEM-${SimpleDateFormat("MMdd_HHmmss", Locale.US).format(Date())}"
                        viewModel.setBarcode(autoId)
                    }
                    // Assign set size when scan is finished (4-8)
                    viewModel.activeSetSize = setSize.toString()
                    viewModel.queueCurrentItemBatch {
                        onNavigateToReview()
                    }
                },
                modifier = Modifier
                    .size(65.dp)
                    .testTag("send_button"),
                shape = CircleShape,
                color = LsGold500,
                border = BorderStroke(2.dp, LsGold100),
                shadowElevation = 6.dp
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    if (viewModel.isSavingCapture) {
                        CircularProgressIndicator(
                            color = LsNavy900,
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send and commit scan task",
                            tint = LsNavy900,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            }
        }
    }

    // 4-7 Floating dialog with text input "package code"
    if (showPackageCodeDialog) {
        var textInput by remember { mutableStateOf(viewModel.activePackageCode) }

        AlertDialog(
            onDismissRequest = { showPackageCodeDialog = false },
            title = {
                Text(
                    text = "Package Code",
                    fontWeight = FontWeight.Bold,
                    color = LsNavy900,
                    fontSize = 17.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Assign a batch or package tracking code for this scan set:",
                        fontSize = 13.sp,
                        color = LsCocoa600
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = textInput,
                        onValueChange = { textInput = it },
                        placeholder = { Text("e.g. PKG-2024-001", color = LsCocoa400, fontSize = 14.sp) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("package_code_text_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LsGold500,
                            unfocusedBorderColor = LsCocoa200,
                            focusedContainerColor = LsSurfaceRaised,
                            unfocusedContainerColor = LsSurfaceRaised,
                            focusedTextColor = LsNavy800,
                            unfocusedTextColor = LsNavy800
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updatePackageCode(textInput.trim())
                        showPackageCodeDialog = false
                        viewModel.toastMessage = if (textInput.isNotBlank()) {
                            "Package code: ${textInput.trim()}"
                        } else {
                            "Package code cleared"
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LsNavy800)
                ) {
                    Text("Save", color = LsCream50, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showPackageCodeDialog = false }) {
                    Text("Cancel", color = LsNavy800)
                }
            }
        )
    }

    // Manual Barcode Dialog if user clicks active barcode chip
    if (showBarcodeManualDialog) {
        var manualBarcode by remember { mutableStateOf(viewModel.activeBarcode) }

        AlertDialog(
            onDismissRequest = { showBarcodeManualDialog = false },
            title = {
                Text(
                    text = "Garment Barcode",
                    fontWeight = FontWeight.Bold,
                    color = LsNavy900,
                    fontSize = 17.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Enter garment barcode or inventory code:",
                        fontSize = 13.sp,
                        color = LsCocoa600
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = manualBarcode,
                        onValueChange = { manualBarcode = it },
                        placeholder = { Text("e.g. 405623412345", color = LsCocoa400, fontSize = 14.sp) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("manual_barcode_text_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LsGold500,
                            unfocusedBorderColor = LsCocoa200,
                            focusedContainerColor = LsSurfaceRaised,
                            unfocusedContainerColor = LsSurfaceRaised,
                            focusedTextColor = LsNavy800,
                            unfocusedTextColor = LsNavy800
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setBarcode(manualBarcode.trim())
                        showBarcodeManualDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LsNavy800)
                ) {
                    Text("Apply", color = LsCream50, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showBarcodeManualDialog = false }) {
                    Text("Cancel", color = LsNavy800)
                }
            }
        )
    }

    // 4-9 B: Large preview dialog with "x" button to close + "trash icon" to delete
    if (previewPhotoIndex != null) {
        val photoIndex = previewPhotoIndex!!
        val photo = viewModel.capturedPhotos.getOrNull(photoIndex)

        if (photo != null) {
            Dialog(
                onDismissRequest = { previewPhotoIndex = null },
                properties = DialogProperties(usePlatformDefaultWidth = false)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.88f))
                        .clickable { previewPhotoIndex = null }
                        .testTag("large_photo_preview_dialog"),
                    contentAlignment = Alignment.Center
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth(0.92f)
                            .clickable(enabled = false) {}, // Keep clicks from dismissing inside card
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = LsNavy900),
                        border = BorderStroke(1.dp, LsCocoa200.copy(alpha = 0.35f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            // Top Bar: Photo index + Key photo star + Trash icon + Close "x"
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Photo ${photoIndex + 1} of ${viewModel.capturedPhotos.size}",
                                        color = LsCream50,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    val isKey = photoIndex == viewModel.selectedKeyPhotoIndex
                                    IconButton(
                                        onClick = { viewModel.selectKeyPhoto(photoIndex) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (isKey) Icons.Filled.Star else Icons.Outlined.StarOutline,
                                            contentDescription = "Set as Key Photo",
                                            tint = if (isKey) LsGold500 else Color.White.copy(alpha = 0.65f),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Trash icon to delete
                                    IconButton(
                                        onClick = {
                                            viewModel.removePhotoAt(photoIndex)
                                            previewPhotoIndex = null
                                            viewModel.toastMessage = "Photo deleted"
                                        },
                                        modifier = Modifier
                                            .size(36.dp)
                                            .testTag("preview_trash_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete photo",
                                            tint = LsStatusCritical,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(4.dp))

                                    // "x" button to close
                                    IconButton(
                                        onClick = { previewPhotoIndex = null },
                                        modifier = Modifier
                                            .size(36.dp)
                                            .testTag("preview_close_button")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Close preview",
                                            tint = Color.White,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Large photo view
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(380.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color.Black),
                                contentAlignment = Alignment.Center
                            ) {
                                AsyncImage(
                                    model = ImageRequest.Builder(context)
                                        .data(photo)
                                        .crossfade(true)
                                        .build(),
                                    contentDescription = "Large photo preview",
                                    contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }
            }
        } else {
            previewPhotoIndex = null
        }
    }
}
