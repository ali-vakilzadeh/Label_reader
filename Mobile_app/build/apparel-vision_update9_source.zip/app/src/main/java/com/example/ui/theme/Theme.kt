package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = CyanAccent,
    secondary = BlueAccent,
    tertiary = ConfidenceLowBorder,
    background = Color(0xFF0B131E),
    surface = Color(0xFF132030),
    surfaceVariant = Color(0xFF1B2A3D),
    onPrimary = Color.Black,
    onSecondary = Color.White,
    onBackground = Color(0xFFF1F5F9),
    onSurface = Color(0xFFF1F5F9)
  )

private val LightColorScheme =
  lightColorScheme(
    primary = LsNavy800,
    onPrimary = LsCream50,
    secondary = LsGold500,
    onSecondary = LsCream50,
    tertiary = LsCocoa600,
    onTertiary = LsCream50,
    background = LsCream100,
    onBackground = LsNavy900,
    surface = LsCream50,
    onSurface = LsNavy900,
    surfaceVariant = LsCream200,
    onSurfaceVariant = LsCocoa600,
    outline = LsCocoa200
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = false,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  // OutFit Design System: fixed cream and navy pairing
  MaterialTheme(colorScheme = LightColorScheme, typography = Typography, content = content)
}

