package com.example.data.local.db

import android.content.Context
import android.util.Log
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.LedgerDao
import com.example.data.local.dao.ScanDao
import com.example.data.local.entity.DailyLedgerEntity
import com.example.data.local.entity.ScanEntity

@Database(
    entities = [ScanEntity::class, DailyLedgerEntity::class],
    version = 6,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun scanDao(): ScanDao
    abstract fun ledgerDao(): LedgerDao

    companion object {
        const val DATABASE_NAME = "apparel_vision.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: buildDatabase(context.applicationContext).also { INSTANCE = it }
            }
        }

        private fun buildDatabase(appContext: Context): AppDatabase {
            return try {
                val db = Room.databaseBuilder(
                    appContext,
                    AppDatabase::class.java,
                    DATABASE_NAME
                )
                    .fallbackToDestructiveMigration()
                    .fallbackToDestructiveMigrationOnDowngrade()
                    .build()

                // Eagerly trigger open to catch any schema or integrity mismatch immediately
                try {
                    db.openHelper.writableDatabase
                } catch (openErr: Throwable) {
                    throw openErr
                }
                db
            } catch (t: Throwable) {
                Log.e("AppDatabase", "Room schema integrity or migration error: ${t.message}. Recreating clean database.", t)
                try {
                    appContext.deleteDatabase(DATABASE_NAME)
                } catch (ignored: Throwable) {}

                val fallbackDb = Room.databaseBuilder(
                    appContext,
                    AppDatabase::class.java,
                    DATABASE_NAME
                )
                    .fallbackToDestructiveMigration()
                    .fallbackToDestructiveMigrationOnDowngrade()
                    .build()

                try {
                    fallbackDb.openHelper.writableDatabase
                } catch (ignored: Throwable) {}
                fallbackDb
            }
        }
    }
}

