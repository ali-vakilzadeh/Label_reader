package com.example.util

import android.graphics.Bitmap
import android.util.Log
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.RGBLuminanceSource
import com.google.zxing.common.HybridBinarizer
import java.util.EnumMap

data class ScanResult(
    val code: String,
    val isQrOr2D: Boolean,
    val source: String
)

object DualBarcodeDetector {
    private const val TAG = "DualBarcodeDetector"

    private val mlKitScanner: BarcodeScanner by lazy {
        val options = BarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
            .build()
        BarcodeScanning.getClient(options)
    }

    private val zxingReader: MultiFormatReader by lazy {
        MultiFormatReader().apply {
            val hints = EnumMap<DecodeHintType, Any>(DecodeHintType::class.java).apply {
                put(DecodeHintType.TRY_HARDER, java.lang.Boolean.TRUE)
                put(DecodeHintType.POSSIBLE_FORMATS, listOf(
                    com.google.zxing.BarcodeFormat.QR_CODE,
                    com.google.zxing.BarcodeFormat.CODE_128,
                    com.google.zxing.BarcodeFormat.CODE_39,
                    com.google.zxing.BarcodeFormat.CODE_93,
                    com.google.zxing.BarcodeFormat.EAN_13,
                    com.google.zxing.BarcodeFormat.EAN_8,
                    com.google.zxing.BarcodeFormat.UPC_A,
                    com.google.zxing.BarcodeFormat.UPC_E,
                    com.google.zxing.BarcodeFormat.ITF,
                    com.google.zxing.BarcodeFormat.DATA_MATRIX
                ))
            }
            setHints(hints)
        }
    }

    /**
     * Decodes an ImageProxy using ML Kit first; if ML Kit doesn't find anything,
     * immediately falls back to ZXing on the Y-luminance buffer with rotation awareness.
     * Guaranteed to always call onComplete() and close the imageProxy.
     */
    @androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
    fun detectFromImageProxy(
        imageProxy: ImageProxy,
        onResult: (ScanResult) -> Unit,
        onComplete: () -> Unit
    ) {
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            onComplete()
            return
        }

        val rotation = imageProxy.imageInfo.rotationDegrees

        // Try ML Kit first (Fast, handles rotation automatically)
        try {
            val inputImage = InputImage.fromMediaImage(mediaImage, rotation)
            mlKitScanner.process(inputImage)
                .addOnSuccessListener { barcodes ->
                    var found = false
                    for (barcode in barcodes) {
                        val raw = barcode.rawValue ?: barcode.displayValue
                        if (!raw.isNullOrBlank()) {
                            val is2D = barcode.format == Barcode.FORMAT_QR_CODE ||
                                    barcode.format == Barcode.FORMAT_DATA_MATRIX ||
                                    barcode.valueType == Barcode.TYPE_URL
                            onResult(ScanResult(raw.trim(), is2D, "MLKit"))
                            found = true
                            break
                        }
                    }

                    if (!found) {
                        // ML Kit returned 0 barcodes on this frame -> Fallback to ZXing
                        fallbackDecodeWithZxing(imageProxy, rotation, onResult)
                    }
                }
                .addOnFailureListener { e ->
                    Log.d(TAG, "ML Kit frame error: ${e.message}, trying ZXing fallback")
                    fallbackDecodeWithZxing(imageProxy, rotation, onResult)
                }
                .addOnCompleteListener {
                    imageProxy.close()
                    onComplete()
                }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during ML Kit scan: ${e.message}")
            try {
                fallbackDecodeWithZxing(imageProxy, rotation, onResult)
            } finally {
                imageProxy.close()
                onComplete()
            }
        }
    }

    /**
     * Decodes using ZXing directly on the Y plane (Luminance) of YUV_420_888 ImageProxy.
     * Takes rotation into account to decode vertical or horizontal orientations.
     */
    private fun fallbackDecodeWithZxing(
        imageProxy: ImageProxy,
        rotationDegrees: Int,
        onResult: (ScanResult) -> Unit
    ) {
        try {
            val planes = imageProxy.planes
            if (planes.isEmpty()) return
            val yBuffer = planes[0].buffer
            val ySize = yBuffer.remaining()
            val yBytes = ByteArray(ySize)
            yBuffer.rewind()
            yBuffer.get(yBytes)
            yBuffer.rewind()

            val rawWidth = imageProxy.width
            val rawHeight = imageProxy.height

            // Rotate Y-plane bytes if needed (phones are typically 90° or 270° in portrait)
            val (rotatedBytes, width, height) = when (rotationDegrees) {
                90 -> Triple(rotateYuv90(yBytes, rawWidth, rawHeight), rawHeight, rawWidth)
                180 -> Triple(rotateYuv180(yBytes, rawWidth, rawHeight), rawWidth, rawHeight)
                270 -> Triple(rotateYuv270(yBytes, rawWidth, rawHeight), rawHeight, rawWidth)
                else -> Triple(yBytes, rawWidth, rawHeight)
            }

            val source = PlanarYUVLuminanceSource(
                rotatedBytes, width, height, 0, 0, width, height, false
            )
            val binaryBitmap = BinaryBitmap(HybridBinarizer(source))

            try {
                val zxingResult = zxingReader.decodeWithState(binaryBitmap)
                val text = zxingResult.text
                if (!text.isNullOrBlank()) {
                    val is2D = zxingResult.barcodeFormat == com.google.zxing.BarcodeFormat.QR_CODE ||
                            zxingResult.barcodeFormat == com.google.zxing.BarcodeFormat.DATA_MATRIX
                    onResult(ScanResult(text.trim(), is2D, "ZXing"))
                    return
                }
            } catch (e: com.google.zxing.NotFoundException) {
                // Not found in primary rotation
            } catch (e: Exception) {
                // Other decode exception
            } finally {
                zxingReader.reset()
            }

            // If rotation was 90 or 270 and didn't find, also try unrotated raw source as secondary attempt
            if (rotationDegrees != 0) {
                val unrotatedSource = PlanarYUVLuminanceSource(
                    yBytes, rawWidth, rawHeight, 0, 0, rawWidth, rawHeight, false
                )
                try {
                    val rawBitmap = BinaryBitmap(HybridBinarizer(unrotatedSource))
                    val rawResult = zxingReader.decodeWithState(rawBitmap)
                    val rawText = rawResult.text
                    if (!rawText.isNullOrBlank()) {
                        val is2D = rawResult.barcodeFormat == com.google.zxing.BarcodeFormat.QR_CODE ||
                                rawResult.barcodeFormat == com.google.zxing.BarcodeFormat.DATA_MATRIX
                        onResult(ScanResult(rawText.trim(), is2D, "ZXing-Raw"))
                    }
                } catch (ignored: Exception) {
                } finally {
                    zxingReader.reset()
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "ZXing fallback processing exception: ${e.message}")
        }
    }

    private fun rotateYuv90(data: ByteArray, imageWidth: Int, imageHeight: Int): ByteArray {
        val y = ByteArray(imageWidth * imageHeight)
        var i = 0
        for (x in 0 until imageWidth) {
            for (yIdx in imageHeight - 1 downTo 0) {
                y[i] = data[yIdx * imageWidth + x]
                i++
            }
        }
        return y
    }

    private fun rotateYuv180(data: ByteArray, imageWidth: Int, imageHeight: Int): ByteArray {
        val count = imageWidth * imageHeight
        val y = ByteArray(count)
        for (i in 0 until count) {
            y[count - 1 - i] = data[i]
        }
        return y
    }

    private fun rotateYuv270(data: ByteArray, imageWidth: Int, imageHeight: Int): ByteArray {
        val y = ByteArray(imageWidth * imageHeight)
        var i = 0
        for (x in imageWidth - 1 downTo 0) {
            for (yIdx in 0 until imageHeight) {
                y[i] = data[yIdx * imageWidth + x]
                i++
            }
        }
        return y
    }

    /**
     * Decodes a Bitmap (e.g. from photo picker, camera photo, or test assets)
     * using ML Kit and ZXing dual engines.
     */
    fun detectFromBitmap(
        bitmap: Bitmap,
        onResult: (ScanResult?) -> Unit
    ) {
        val inputImage = InputImage.fromBitmap(bitmap, 0)
        mlKitScanner.process(inputImage)
            .addOnSuccessListener { barcodes ->
                for (b in barcodes) {
                    val raw = b.rawValue ?: b.displayValue
                    if (!raw.isNullOrBlank()) {
                        val is2D = b.format == Barcode.FORMAT_QR_CODE ||
                                b.format == Barcode.FORMAT_DATA_MATRIX ||
                                b.valueType == Barcode.TYPE_URL
                        onResult(ScanResult(raw.trim(), is2D, "MLKit-Bitmap"))
                        return@addOnSuccessListener
                    }
                }

                // Try ZXing with Bitmap RGB
                decodeBitmapWithZxing(bitmap, onResult)
            }
            .addOnFailureListener {
                decodeBitmapWithZxing(bitmap, onResult)
            }
    }

    private fun decodeBitmapWithZxing(
        bitmap: Bitmap,
        onResult: (ScanResult?) -> Unit
    ) {
        try {
            val width = bitmap.width
            val height = bitmap.height
            val pixels = IntArray(width * height)
            bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

            val source = RGBLuminanceSource(width, height, pixels)
            val binaryBitmap = BinaryBitmap(HybridBinarizer(source))

            val zxingResult = zxingReader.decodeWithState(binaryBitmap)
            val text = zxingResult.text
            if (!text.isNullOrBlank()) {
                val is2D = zxingResult.barcodeFormat == com.google.zxing.BarcodeFormat.QR_CODE ||
                        zxingResult.barcodeFormat == com.google.zxing.BarcodeFormat.DATA_MATRIX
                onResult(ScanResult(text.trim(), is2D, "ZXing-Bitmap"))
            } else {
                onResult(null)
            }
        } catch (e: Exception) {
            onResult(null)
        } finally {
            zxingReader.reset()
        }
    }
}
