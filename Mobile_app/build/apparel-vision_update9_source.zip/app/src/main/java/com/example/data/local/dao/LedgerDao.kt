package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.DailyLedgerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LedgerDao {
    @Query("SELECT * FROM daily_ledger WHERE submitted_to_csv = 0 ORDER BY timestamp DESC")
    fun getActiveLedger(): Flow<List<DailyLedgerEntity>>

    @Query("SELECT * FROM daily_ledger WHERE submitted_to_csv = 0 ORDER BY timestamp DESC")
    suspend fun getActiveLedgerList(): List<DailyLedgerEntity>

    @Query("SELECT * FROM daily_ledger ORDER BY timestamp DESC")
    fun getAllLedgerHistory(): Flow<List<DailyLedgerEntity>>

    @Query("SELECT * FROM daily_ledger ORDER BY timestamp DESC")
    suspend fun getAllLedgerHistoryList(): List<DailyLedgerEntity>

    @Query("SELECT * FROM daily_ledger WHERE apparel_id = :apparelId LIMIT 1")
    suspend fun getLedgerItemById(apparelId: String): DailyLedgerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedgerItem(item: DailyLedgerEntity)

    @Update
    suspend fun updateLedgerItem(item: DailyLedgerEntity)

    @Query("UPDATE daily_ledger SET exported_at = :exportedAt, export_batch_id = :batchId WHERE submitted_to_csv = 0")
    suspend fun stampExportBatch(exportedAt: Long, batchId: String)

    @Query("UPDATE daily_ledger SET submitted_to_csv = 1, submitted_at = :submittedAt WHERE export_batch_id = :batchId")
    suspend fun confirmBatchSubmission(batchId: String, submittedAt: Long)

    @Query("UPDATE daily_ledger SET submitted_to_csv = 1, submitted_at = :submittedAt WHERE submitted_to_csv = 0")
    suspend fun confirmAllActiveSubmitted(submittedAt: Long)

    @Query("SELECT * FROM daily_ledger WHERE export_batch_id = :batchId ORDER BY timestamp DESC")
    suspend fun getLedgerItemsByBatch(batchId: String): List<DailyLedgerEntity>

    @Query("SELECT DISTINCT export_batch_id FROM daily_ledger WHERE export_batch_id IS NOT NULL AND export_batch_id != '' ORDER BY timestamp DESC")
    suspend fun getDistinctBatchIdsList(): List<String>

    @Query("UPDATE daily_ledger SET sync_status = :status WHERE export_batch_id = :batchId")
    suspend fun updateBatchSyncStatus(batchId: String, status: String)

    @Query("UPDATE daily_ledger SET sync_status = :status WHERE submitted_to_csv = 1")
    suspend fun updateAllSubmittedSyncStatus(status: String)

    @Query("DELETE FROM daily_ledger WHERE apparel_id = :apparelId")
    suspend fun deleteLedgerItem(apparelId: String)

    @Query("DELETE FROM daily_ledger WHERE submitted_to_csv = 0")
    suspend fun clearActiveDailyLedger()

    @Query("DELETE FROM daily_ledger")
    suspend fun clearAllLedger()
}
