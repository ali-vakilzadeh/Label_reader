package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class AppSettings(context: Context) {
    private val prefs: SharedPreferences = run {
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            val encPrefs = EncryptedSharedPreferences.create(
                context,
                PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            // Test read to guarantee Keystore decryption works
            encPrefs.getString(KEY_USER_ID, "")
            encPrefs
        } catch (t: Throwable) {
            Log.w("AppSettings", "EncryptedSharedPreferences unavailable or corrupted: ${t.message}. Falling back to standard SharedPreferences.")
            try {
                // Delete corrupted encrypted file to prevent subsequent crashes
                context.deleteSharedPreferences(PREFS_NAME)
            } catch (ignored: Throwable) {}
            context.getSharedPreferences(FALLBACK_PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    var userId: String
        get() = try { prefs.getString(KEY_USER_ID, "") ?: "" } catch (t: Throwable) { "" }
        set(value) {
            try {
                prefs.edit().putString(KEY_USER_ID, value.trim()).apply()
            } catch (t: Throwable) {
                Log.e("AppSettings", "Error writing userId: ${t.message}")
            }
        }

    var devicePassword: String
        get() = try { prefs.getString(KEY_DEVICE_PASSWORD, "") ?: "" } catch (t: Throwable) { "" }
        set(value) {
            try {
                prefs.edit().putString(KEY_DEVICE_PASSWORD, value.trim()).apply()
            } catch (t: Throwable) {
                Log.e("AppSettings", "Error writing devicePassword: ${t.message}")
            }
        }

    var serverUrl: String
        get() = try { prefs.getString(KEY_SERVER_URL, DEFAULT_SERVER_URL) ?: DEFAULT_SERVER_URL } catch (t: Throwable) { DEFAULT_SERVER_URL }
        set(value) {
            try {
                val formatted = normalizeServerUrl(value)
                prefs.edit().putString(KEY_SERVER_URL, formatted).apply()
            } catch (t: Throwable) {
                Log.e("AppSettings", "Error writing serverUrl: ${t.message}")
            }
        }

    var sessionToken: String?
        get() = try { prefs.getString(KEY_SESSION_TOKEN, null)?.takeIf { it.isNotBlank() } } catch (t: Throwable) { null }
        set(value) {
            try {
                if (value.isNullOrBlank()) {
                    prefs.edit().remove(KEY_SESSION_TOKEN).apply()
                } else {
                    prefs.edit().putString(KEY_SESSION_TOKEN, value.trim()).apply()
                }
            } catch (t: Throwable) {
                Log.e("AppSettings", "Error writing sessionToken: ${t.message}")
            }
        }

    var defaultStartDestination: String
        get() = try {
            val v = prefs.getString(KEY_DEFAULT_START_DESTINATION, "capture") ?: "capture"
            if (v == "intake") "capture" else v
        } catch (t: Throwable) {
            "capture"
        }
        set(value) {
            try {
                val normalized = if (value == "intake") "capture" else value
                prefs.edit().putString(KEY_DEFAULT_START_DESTINATION, normalized).apply()
            } catch (t: Throwable) {
                Log.e("AppSettings", "Error writing defaultStartDestination: ${t.message}")
            }
        }

    var autoSyncAiVision: Boolean
        get() = try { prefs.getBoolean(KEY_AUTO_SYNC_AI, true) } catch (t: Throwable) { true }
        set(value) {
            try {
                prefs.edit().putBoolean(KEY_AUTO_SYNC_AI, value).apply()
            } catch (t: Throwable) {
                Log.e("AppSettings", "Error writing autoSyncAiVision: ${t.message}")
            }
        }

    var requireAllFieldsComplete: Boolean
        get() = try { prefs.getBoolean(KEY_REQUIRE_ALL_FIELDS, true) } catch (t: Throwable) { true }
        set(value) {
            try {
                prefs.edit().putBoolean(KEY_REQUIRE_ALL_FIELDS, value).apply()
            } catch (t: Throwable) {
                Log.e("AppSettings", "Error writing requireAllFieldsComplete: ${t.message}")
            }
        }

    var packageCode: String
        get() = try { prefs.getString(KEY_PACKAGE_CODE, "") ?: "" } catch (t: Throwable) { "" }
        set(value) {
            try {
                prefs.edit().putString(KEY_PACKAGE_CODE, value.trim()).apply()
            } catch (t: Throwable) {
                Log.e("AppSettings", "Error writing packageCode: ${t.message}")
            }
        }

    var lastScannedBarcode: String?
        get() = try { prefs.getString(KEY_LAST_BARCODE, null) } catch (t: Throwable) { null }
        set(value) {
            try {
                prefs.edit().putString(KEY_LAST_BARCODE, value).apply()
            } catch (t: Throwable) {
                Log.e("AppSettings", "Error writing lastScannedBarcode: ${t.message}")
            }
        }

    fun clearAuth() {
        try {
            prefs.edit().remove(KEY_SESSION_TOKEN).apply()
        } catch (t: Throwable) {
            Log.e("AppSettings", "Error clearing auth: ${t.message}")
        }
    }

    companion object {
        const val DEFAULT_SERVER_URL = "https://api.outfit.am"

        private const val PREFS_NAME = "apparel_vision_secure_prefs"
        private const val FALLBACK_PREFS_NAME = "apparel_vision_settings"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_DEVICE_PASSWORD = "device_password"
        private const val KEY_SERVER_URL = "server_url"
        private const val KEY_SESSION_TOKEN = "session_token"
        private const val KEY_DEFAULT_START_DESTINATION = "default_start_destination"
        private const val KEY_AUTO_SYNC_AI = "auto_sync_ai"
        private const val KEY_REQUIRE_ALL_FIELDS = "require_all_fields_complete"
        private const val KEY_PACKAGE_CODE = "package_code"
        private const val KEY_LAST_BARCODE = "last_scanned_barcode"

        @Volatile
        private var INSTANCE: AppSettings? = null

        fun normalizeServerUrl(input: String): String {
            var url = input.trim()
            if (url.isBlank()) return DEFAULT_SERVER_URL
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "https://$url"
            }
            url = url.trimEnd('/')
            if (url.endsWith("/api/v1", ignoreCase = true)) {
                url = url.substring(0, url.length - "/api/v1".length).trimEnd('/')
            }
            return url
        }

        fun getInstance(context: Context): AppSettings {
            return INSTANCE ?: synchronized(this) {
                val instance = AppSettings(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
