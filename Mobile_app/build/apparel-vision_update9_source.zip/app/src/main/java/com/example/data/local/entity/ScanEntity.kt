package com.example.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scans")
data class ScanEntity(
    @PrimaryKey
    @ColumnInfo(name = "apparel_id")
    val apparelId: String,

    @ColumnInfo(name = "user_id")
    val userId: String,

    @ColumnInfo(name = "timestamp")
    val timestamp: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "photo_paths_json")
    val photoPathsJson: String, // JSON array string of local file paths (up to 8)

    @ColumnInfo(name = "key_photo_index")
    val keyPhotoIndex: Int = 0,

    @ColumnInfo(name = "status")
    val status: Int = STATUS_PENDING_VISION, // 0=PENDING_VISION, 1=EXTRACTED_UNVERIFIED, 2=VERIFIED_SAVED, 3=FAILED

    @ColumnInfo(name = "server_stored")
    val serverStored: Boolean = false, // True once server returns 202 Accepted (Storage invariant guarantee)

    @ColumnInfo(name = "processing_status")
    val processingStatus: String? = null, // PENDING_AI, READY_TO_CONFIRM, NEEDS_ATTENTION

    @ColumnInfo(name = "queue_depth")
    val queueDepth: Int = 0,

    @ColumnInfo(name = "estimated_wait_seconds")
    val estimatedWaitSeconds: Int? = null,

    @ColumnInfo(name = "retry_after_seconds")
    val retryAfterSeconds: Int = 5,

    @ColumnInfo(name = "blocking_fault")
    val blockingFault: String? = null,

    @ColumnInfo(name = "attention_reason")
    val attentionReason: String? = null,

    @ColumnInfo(name = "extracted_category")
    val extractedCategory: String = "",

    @ColumnInfo(name = "extracted_sub_category")
    val extractedSubCategory: String = "",

    @ColumnInfo(name = "extracted_gender")
    val extractedGender: String = "",

    @ColumnInfo(name = "extracted_season")
    val extractedSeason: String = "",

    @ColumnInfo(name = "extracted_brand_name")
    val extractedBrandName: String = "",

    @ColumnInfo(name = "extracted_country_of_origin")
    val extractedCountryOfOrigin: String = "",

    @ColumnInfo(name = "extracted_size")
    val extractedSize: String = "",

    @ColumnInfo(name = "extracted_color")
    val extractedColor: String = "",

    @ColumnInfo(name = "extracted_material")
    val extractedMaterial: String = "",

    @ColumnInfo(name = "extracted_original_price")
    val extractedOriginalPrice: String = "",

    @ColumnInfo(name = "extracted_netto")
    val extractedNetto: String = "",

    @ColumnInfo(name = "extracted_brutto")
    val extractedBrutto: String = "",

    @ColumnInfo(name = "extracted_care_info")
    val extractedCareInfo: String = "",

    @ColumnInfo(name = "package_code")
    val packageCode: String? = null,

    @ColumnInfo(name = "set_size")
    val setSize: Int? = 1,

    @ColumnInfo(name = "suggested_key_photo_index")
    val suggestedKeyPhotoIndex: Int? = null,

    @ColumnInfo(name = "data_hy_json")
    val dataHyJson: String? = null,

    @ColumnInfo(name = "confidences_json")
    val confidencesJson: String = "{}", // Map of field_name -> Float confidence

    @ColumnInfo(name = "error_message")
    val errorMessage: String? = null,

    @ColumnInfo(name = "last_attempt_time")
    val lastAttemptTime: Long = 0L,

    @ColumnInfo(name = "retry_count")
    val retryCount: Int = 0
) {
    companion object {
        const val STATUS_PENDING_VISION = 0
        const val STATUS_EXTRACTED_UNVERIFIED = 1
        const val STATUS_VERIFIED_SAVED = 2
        const val STATUS_FAILED = 3

        const val PROCESSING_PENDING_AI = "PENDING_AI"
        const val PROCESSING_READY_TO_CONFIRM = "READY_TO_CONFIRM"
        const val PROCESSING_NEEDS_ATTENTION = "NEEDS_ATTENTION"
    }
}
