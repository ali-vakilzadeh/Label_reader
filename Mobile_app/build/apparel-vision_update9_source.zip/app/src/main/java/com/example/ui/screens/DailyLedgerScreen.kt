package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.local.entity.DailyLedgerEntity
import com.example.data.reference.ReferenceVocabulary
import com.example.ui.theme.LsBeige100
import com.example.ui.theme.LsBeige300
import com.example.ui.theme.LsCocoa500
import com.example.ui.theme.LsCocoa600
import com.example.ui.theme.LsCocoa900
import com.example.ui.theme.LsCreme
import com.example.ui.theme.LsGold100
import com.example.ui.theme.LsGold200
import com.example.ui.theme.LsGold500
import com.example.ui.theme.LsGold600
import com.example.ui.theme.LsGold800
import com.example.ui.theme.LsGoldWash
import com.example.ui.theme.LsLinen
import com.example.ui.theme.LsRust200
import com.example.ui.theme.LsRust50
import com.example.ui.theme.LsRust500
import com.example.ui.theme.LsRust700
import com.example.ui.viewmodel.ApparelViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DailyLedgerScreen(
    viewModel: ApparelViewModel
) {
    val activeLedger by viewModel.activeDailyLedger.collectAsStateWithLifecycle()
    val allLedgerHistory by viewModel.allLedgerHistory.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0 = Active Daily Session, 1 = Archive / All History
    var cloneItemTarget by remember { mutableStateOf<DailyLedgerEntity?>(null) }
    var cloneTargetBarcode by remember { mutableStateOf("") }
    var editingLedgerItem by remember { mutableStateOf<DailyLedgerEntity?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(LsCreme)
            .testTag("daily_ledger_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar
            Surface(
                color = LsGold800,
                modifier = Modifier.fillMaxWidth(),
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PRODUCTION AUDIT",
                            color = LsGold200,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Verified Daily Ledger",
                            color = LsLinen,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (selectedTabIndex == 0) {
                            if (viewModel.pendingExportBatchId != null) {
                                Button(
                                    onClick = { viewModel.showCsvCutoffConfirmDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("step2_top_button")
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = LsLinen, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Step 2: Cut-Off", color = LsLinen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                            } else if (activeLedger.isNotEmpty()) {
                                OutlinedButton(
                                    onClick = { viewModel.promptManualSessionCutoff() },
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = LsGold200),
                                    border = BorderStroke(1.dp, LsGold200),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("manual_cutoff_button")
                                ) {
                                    Text("Advance Session", color = LsGold200, fontSize = 11.sp)
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                            }

                            Button(
                                onClick = { viewModel.shareCsvExport() },
                                enabled = activeLedger.isNotEmpty(),
                                colors = ButtonDefaults.buttonColors(containerColor = LsGold500),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("export_csv_button")
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, tint = LsCocoa900, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (viewModel.pendingExportBatchId != null) "Re-Export" else "Export CSV", color = LsCocoa900, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OutlinedButton(
                                    onClick = { viewModel.showShiftManifestForBatch() },
                                    enabled = allLedgerHistory.isNotEmpty(),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = LsGold200),
                                    border = BorderStroke(1.dp, LsGold200),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("archive_step3_manifest_button")
                                ) {
                                    Icon(Icons.Default.ListAlt, contentDescription = null, tint = LsGold200, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Step 3: Manifest", color = LsGold200, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                Button(
                                    onClick = { viewModel.shareArchiveCsvExport() },
                                    enabled = allLedgerHistory.isNotEmpty(),
                                    colors = ButtonDefaults.buttonColors(containerColor = LsGold500),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("export_archive_button")
                                ) {
                                    Icon(Icons.Default.Archive, contentDescription = null, tint = LsCocoa900, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Export Archive", color = LsCocoa900, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Tab Bar
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = LsLinen,
                contentColor = LsGold800,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = LsGold800,
                        height = 3.dp
                    )
                }
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = {
                        Text(
                            text = "Active Session (${activeLedger.size})",
                            fontSize = 13.sp,
                            fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTabIndex == 0) LsGold800 else LsCocoa600
                        )
                    }
                )

                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = {
                        Text(
                            text = "All History Archive (${allLedgerHistory.size})",
                            fontSize = 13.sp,
                            fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTabIndex == 1) LsGold800 else LsCocoa600
                        )
                    }
                )
            }

            // Persistent Step 2 Cut-Off Banner when an export batch is awaiting session advance
            if (selectedTabIndex == 0 && viewModel.pendingExportBatchId != null) {
                Surface(
                    color = LsGold100,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, LsGold500),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                        .testTag("step2_cutoff_banner")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = LsGold800, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "STEP 2: CONFIRM CUT-OFF",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = LsGold800,
                                    letterSpacing = 0.5.sp
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Batch ${viewModel.pendingExportBatchId} exported (${viewModel.lastExportedItemCount} items). Delivery confirmed? Advance session to clean slate.",
                                fontSize = 12.sp,
                                color = LsCocoa900
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { viewModel.showCsvCutoffConfirmDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("step2_confirm_banner_button")
                        ) {
                            Text("Cut-Off", color = LsLinen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Display List
            val displayItems = if (selectedTabIndex == 0) activeLedger else allLedgerHistory

            if (displayItems.isEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = LsLinen),
                    border = BorderStroke(1.dp, LsBeige300)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = if (selectedTabIndex == 0) Icons.Default.ListAlt else Icons.Default.History,
                            contentDescription = null,
                            tint = LsGold500,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (selectedTabIndex == 0) "No Active Ledger Records" else "History is Empty",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = LsCocoa900
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (selectedTabIndex == 0) "Confirm items on the Review screen to populate the active daily session." else "Previously exported sessions will be cataloged here.",
                            fontSize = 12.sp,
                            color = LsCocoa600,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(displayItems, key = { it.apparelId }) { item ->
                        LedgerItemCard(
                            item = item,
                            viewModel = viewModel,
                            onEdit = { editingLedgerItem = item },
                            onDuplicate = {
                                cloneItemTarget = item
                                cloneTargetBarcode = ""
                            },
                            onDelete = { viewModel.deleteLedgerItem(item.apparelId) }
                        )
                    }
                }
            }
        }

        // Two-Step CSV Confirmation Dialog (Session Cut-Off)
        if (viewModel.showCsvCutoffConfirmDialog) {
            AlertDialog(
                onDismissRequest = { viewModel.dismissCsvCutoffDialog() },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = LsGold800, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Step 2: Confirm Delivery & Cut-Off", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = LsCocoa900)
                    }
                },
                text = {
                    Column {
                        Text(
                            text = "Have all ${viewModel.lastExportedItemCount} exported items been successfully received or saved?",
                            color = LsCocoa900,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Confirming Step 2 will stamp the submission timestamp in SQLite and advance the active daily session to a clean slate. All items are permanently retained in the History Archive.",
                            color = LsCocoa600,
                            fontSize = 12.sp
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { viewModel.confirmCsvCutoff() },
                        colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("dialog_confirm_step2_button")
                    ) {
                        Text("Confirm Step 2 Cut-Off", color = LsLinen, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    Button(
                        onClick = { viewModel.dismissCsvCutoffDialog() },
                        colors = ButtonDefaults.buttonColors(containerColor = LsBeige100),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Keep in Active Session", color = LsCocoa900)
                    }
                },
                containerColor = LsLinen,
                shape = RoundedCornerShape(14.dp)
            )
        }

        // =====================================================================
        // Step 3: Shift Handover Manifest & Production Audit Dialog
        // =====================================================================
        if (viewModel.showStep3ManifestDialog && viewModel.currentShiftManifest != null) {
            val manifest = viewModel.currentShiftManifest!!
            AlertDialog(
                onDismissRequest = { viewModel.showStep3ManifestDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF166534),
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Step 3: Shift Production Manifest",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = LsCocoa900
                            )
                            Text(
                                text = "Batch: ${manifest.batchId} • Operator: ${manifest.operatorId}",
                                fontSize = 11.sp,
                                color = LsCocoa600
                            )
                        }
                    }
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Key Metrics Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = LsCreme,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, LsBeige300)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("TOTAL PIECES", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = LsCocoa600)
                                    Text("${manifest.totalItems} pcs", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = LsCocoa900)
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                color = LsCreme,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, LsBeige300)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("EST. VALUE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = LsCocoa600)
                                    Text("$${String.format(Locale.US, "%.2f", manifest.totalEstimatedValue)}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = LsGold800)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Sync Status & Care Label Info
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = if (manifest.syncStatus == "SYNCED_BACKEND") Color(0xFFDCFCE7) else LsGold100,
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(1.dp, if (manifest.syncStatus == "SYNCED_BACKEND") Color(0xFF166534) else LsGold500)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        if (manifest.syncStatus == "SYNCED_BACKEND") Icons.Default.Check else Icons.Default.Sync,
                                        contentDescription = null,
                                        tint = if (manifest.syncStatus == "SYNCED_BACKEND") Color(0xFF166534) else LsGold800,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (manifest.syncStatus == "SYNCED_BACKEND") "SYNCED TO CENTRAL SERVER" else "LOCAL ARCHIVE CONFIRMED",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (manifest.syncStatus == "SYNCED_BACKEND") Color(0xFF166534) else LsGold800
                                    )
                                }
                            }

                            Text(
                                text = "Care Labels: ${manifest.careInfoCoverageCount}/${manifest.totalItems}",
                                fontSize = 11.sp,
                                color = LsCocoa600,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Preformatted Shift Manifest Terminal Box
                        Text("Formal Shift Handover Text:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LsCocoa600)
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            color = Color(0xFF0F2439),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "BATCH: ${manifest.batchId}\nOPERATOR: ${manifest.operatorId}\nCONFIRMED PIECES: ${manifest.totalItems}\nTOTAL VALUATION: $${String.format(Locale.US, "%.2f", manifest.totalEstimatedValue)}\nTOP BRANDS: " +
                                        manifest.brandCounts.entries.take(4).joinToString(", ") { "${it.key}: ${it.value}" },
                                color = Color(0xFFDCB055),
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { viewModel.shareShiftManifest(manifest) },
                            colors = ButtonDefaults.buttonColors(containerColor = LsGold500),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("step3_share_manifest_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = LsCocoa900, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Share Report", color = LsCocoa900, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Button(
                            onClick = { viewModel.completeStep3Closeout(cleanupPhotos = true) },
                            colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("step3_closeout_button")
                        ) {
                            Text("Complete & Close", color = LsLinen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                },
                dismissButton = {
                    OutlinedButton(
                        onClick = { viewModel.syncCurrentBatchToBackend() },
                        enabled = !viewModel.isSyncingBatch && manifest.syncStatus != "SYNCED_BACKEND",
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = LsGold800),
                        border = BorderStroke(1.dp, LsGold800),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("step3_sync_backend_button")
                    ) {
                        if (viewModel.isSyncingBatch) {
                            Text("Syncing...", fontSize = 11.sp)
                        } else {
                            Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Sync Backend", fontSize = 11.sp)
                        }
                    }
                },
                containerColor = LsLinen,
                shape = RoundedCornerShape(14.dp)
            )
        }

        // Duplicate Clone Dialog
        cloneItemTarget?.let { item ->
            AlertDialog(
                onDismissRequest = { cloneItemTarget = null },
                title = { Text("Clone Item Attributes", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = LsCocoa900) },
                text = {
                    Column {
                        Text("Duplicate '${item.apparelId}' values to a new barcode:", color = LsCocoa600, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = cloneTargetBarcode,
                            onValueChange = { cloneTargetBarcode = it },
                            label = { Text("New Garment Barcode", color = LsCocoa600) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = LsGold500,
                                unfocusedBorderColor = LsBeige300,
                                focusedTextColor = LsCocoa900,
                                unfocusedTextColor = LsCocoa900
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.duplicateLedgerItem(item.apparelId, cloneTargetBarcode)
                            cloneItemTarget = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Duplicate", color = LsLinen, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    Button(
                        onClick = { cloneItemTarget = null },
                        colors = ButtonDefaults.buttonColors(containerColor = LsBeige100),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Cancel", color = LsCocoa900)
                    }
                },
                containerColor = LsLinen,
                shape = RoundedCornerShape(14.dp)
            )
        }

        // Export Blocked Dialog (Require All Fields Complete enabled)
        if (viewModel.showExportBlockedDialog) {
            AlertDialog(
                onDismissRequest = { viewModel.showExportBlockedDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = LsRust500, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Export Blocked: Incomplete Items", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = LsCocoa900)
                    }
                },
                text = {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        Text(
                            text = "'Require All Mandatory Fields' is enabled in Settings. The following items have missing values and must be completed before CSV export:",
                            color = LsCocoa900,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        viewModel.incompleteItemsList.forEach { (barcode, missing) ->
                            Surface(
                                color = LsRust50,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                border = BorderStroke(1.dp, LsRust200)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text(text = "Item: $barcode", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = LsRust700)
                                    Text(text = "Missing: ${missing.joinToString(", ")}", fontSize = 11.sp, color = LsCocoa600)
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { viewModel.showExportBlockedDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Review Items", color = LsLinen, fontWeight = FontWeight.Bold)
                    }
                },
                containerColor = LsLinen,
                shape = RoundedCornerShape(14.dp)
            )
        }

        // Export Warning Dialog (Require All Fields Complete disabled)
        if (viewModel.showExportWarnDialog) {
            AlertDialog(
                onDismissRequest = { viewModel.showExportWarnDialog = false },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = LsGold800, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Incomplete Items Warning", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = LsCocoa900)
                    }
                },
                text = {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        Text(
                            text = "Some active ledger items are missing mandatory fields:",
                            color = LsCocoa900,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        viewModel.incompleteItemsList.take(5).forEach { (barcode, missing) ->
                            Text(
                                text = "• $barcode: missing ${missing.joinToString(", ")}",
                                fontSize = 12.sp,
                                color = LsRust700
                            )
                        }
                        if (viewModel.incompleteItemsList.size > 5) {
                            Text(
                                text = "... and ${viewModel.incompleteItemsList.size - 5} more items",
                                fontSize = 11.sp,
                                color = LsCocoa500
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Do you want to proceed with CSV export anyway?",
                            fontWeight = FontWeight.SemiBold,
                            color = LsCocoa900,
                            fontSize = 12.sp
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { viewModel.executeCsvExport() },
                        colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Export Anyway", color = LsLinen, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    Button(
                        onClick = { viewModel.showExportWarnDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = LsBeige100),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Cancel", color = LsCocoa900)
                    }
                },
                containerColor = LsLinen,
                shape = RoundedCornerShape(14.dp)
            )
        }

        // Edit Ledger Item Dialog
        editingLedgerItem?.let { item ->
            EditLedgerItemDialog(
                item = item,
                onDismiss = { editingLedgerItem = null },
                onSave = { updated ->
                    viewModel.updateLedgerItem(updated)
                    editingLedgerItem = null
                }
            )
        }
    }
}

@Composable
fun LedgerItemCard(
    item: DailyLedgerEntity,
    viewModel: ApparelViewModel,
    onEdit: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val photoPaths = viewModel.getPhotoPaths(item.photosJson)
    val keyPhotoFile = if (photoPaths.isNotEmpty()) {
        File(photoPaths.getOrElse(item.keyPhotoIndex.coerceIn(0, photoPaths.lastIndex)) { photoPaths.first() })
    } else null

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ledger_card_${item.apparelId}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = LsLinen),
        border = BorderStroke(1.dp, LsBeige300)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(LsBeige100)
            ) {
                if (keyPhotoFile != null && keyPhotoFile.exists()) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(keyPhotoFile)
                            .crossfade(true)
                            .build(),
                        contentDescription = "Ledger Photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.ListAlt,
                        contentDescription = null,
                        tint = LsCocoa500,
                        modifier = Modifier
                            .size(24.dp)
                            .align(Alignment.Center)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.apparelId,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = LsCocoa900
                    )

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = if (item.submittedToCsv) LsBeige100 else Color(0xFFDCFCE7),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = if (item.submittedToCsv) "SUBMITTED CSV" else "ACTIVE",
                                color = if (item.submittedToCsv) LsCocoa600 else Color(0xFF166534),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }

                        if (item.submittedToCsv) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Surface(
                                color = if (item.syncStatus == "SYNCED_BACKEND") Color(0xFFDCFCE7) else LsBeige100,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (item.syncStatus == "SYNCED_BACKEND") "SYNCED" else "LOCAL",
                                    color = if (item.syncStatus == "SYNCED_BACKEND") Color(0xFF166534) else LsCocoa600,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "${item.brandName} • ${item.category} (${item.subCategory})",
                    fontSize = 12.sp,
                    color = LsCocoa600,
                    fontWeight = FontWeight.Medium
                )

                Text(
                    text = "Size: ${item.size} | ${item.color} | ${item.originalPrice} | ${item.material}",
                    fontSize = 11.sp,
                    color = LsCocoa500
                )

                if (item.exportedAt != null) {
                    val exportTime = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(item.exportedAt))
                    Text(
                        text = "Batch: ${item.exportBatchId ?: "Exported"} @ $exportTime",
                        fontSize = 10.sp,
                        color = LsGold800
                    )
                }

                if (item.submittedToCsv && item.submittedAt != null) {
                    val submittedTime = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(item.submittedAt))
                    Text(
                        text = "Cut-Off Confirmed: $submittedTime",
                        fontSize = 10.sp,
                        color = LsCocoa600
                    )
                }
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Actions
            IconButton(onClick = onEdit) {
                Icon(Icons.Default.Edit, contentDescription = "Edit item", tint = LsGold800, modifier = Modifier.size(18.dp))
            }

            IconButton(onClick = onDuplicate) {
                Icon(Icons.Default.ContentCopy, contentDescription = "Clone item", tint = LsGold800, modifier = Modifier.size(18.dp))
            }

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete item", tint = LsRust500, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun EditLedgerItemDialog(
    item: DailyLedgerEntity,
    onDismiss: () -> Unit,
    onSave: (DailyLedgerEntity) -> Unit
) {
    var brand by remember { mutableStateOf(item.brandName) }
    var category by remember { mutableStateOf(item.category) }
    var subCategory by remember { mutableStateOf(item.subCategory) }
    var gender by remember { mutableStateOf(item.gender) }
    var season by remember { mutableStateOf(item.season) }
    var size by remember { mutableStateOf(item.size) }
    var color by remember { mutableStateOf(item.color) }
    var material by remember { mutableStateOf(item.material) }
    var country by remember { mutableStateOf(item.countryOfOrigin) }
    var price by remember { mutableStateOf(item.originalPrice) }
    var netto by remember { mutableStateOf(item.netto) }
    var brutto by remember { mutableStateOf(item.brutto) }
    var packageCode by remember { mutableStateOf(item.packageCode ?: "") }
    var setSize by remember { mutableStateOf(item.setSize.toString()) }
    var careInfo by remember { mutableStateOf(item.careInfo ?: "") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(16.dp)),
            color = LsLinen
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Edit Ledger Item",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = LsCocoa900
                        )
                        Text(
                            text = "Barcode: ${item.apparelId}",
                            fontSize = 12.sp,
                            color = LsGold800,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = LsCocoa600)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = brand,
                        onValueChange = { brand = it },
                        label = { Text("Brand") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = category,
                            onValueChange = { category = it },
                            label = { Text("Category") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = subCategory,
                            onValueChange = { subCategory = it },
                            label = { Text("Sub-Category") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = gender,
                            onValueChange = { gender = it },
                            label = { Text("Gender") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = season,
                            onValueChange = { season = it },
                            label = { Text("Season") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = size,
                            onValueChange = { size = it },
                            label = { Text("Size") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = color,
                            onValueChange = { color = it },
                            label = { Text("Color") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = material,
                        onValueChange = { material = it },
                        label = { Text("Material Composition") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = country,
                            onValueChange = { country = it },
                            label = { Text("Country of Origin") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = price,
                            onValueChange = { price = it },
                            label = { Text("Original Price") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = netto,
                            onValueChange = { netto = it },
                            label = { Text("Netto Weight") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = brutto,
                            onValueChange = { brutto = it },
                            label = { Text("Brutto Weight") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = packageCode,
                            onValueChange = { packageCode = it },
                            label = { Text("Package Code") },
                            modifier = Modifier.weight(1.2f)
                        )
                        OutlinedTextField(
                            value = setSize,
                            onValueChange = { setSize = it.filter { ch -> ch.isDigit() } },
                            label = { Text("Set Size") },
                            modifier = Modifier.weight(0.8f)
                        )
                    }
                    OutlinedTextField(
                        value = careInfo,
                        onValueChange = { careInfo = it },
                        label = { Text("Care / Wash Info") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = LsBeige100),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Cancel", color = LsCocoa900)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            onSave(
                                item.copy(
                                    brandName = brand,
                                    category = category,
                                    subCategory = subCategory,
                                    gender = gender,
                                    season = season,
                                    size = size,
                                    color = color,
                                    material = material,
                                    countryOfOrigin = country,
                                    originalPrice = price,
                                    netto = netto,
                                    brutto = brutto,
                                    packageCode = packageCode.ifBlank { null },
                                    setSize = setSize.toIntOrNull() ?: 1,
                                    careInfo = careInfo.ifBlank { null }
                                )
                            )
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Save Changes", color = LsLinen, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
