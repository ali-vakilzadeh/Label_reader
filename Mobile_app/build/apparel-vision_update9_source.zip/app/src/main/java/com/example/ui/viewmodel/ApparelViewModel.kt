package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.DailyLedgerEntity
import com.example.data.local.entity.ScanEntity
import com.example.data.model.ShiftManifestSummary
import com.example.data.remote.VisionExtractionService
import com.example.data.repository.ApparelRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ApparelViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ApparelRepository(application)
    val appSettings = repository.appSettings

    // Reactive database streams
    val pendingScans: StateFlow<List<ScanEntity>> = repository.getPendingAndFailedScans()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unverifiedScans: StateFlow<List<ScanEntity>> = repository.getUnverifiedScans()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeDailyLedger: StateFlow<List<DailyLedgerEntity>> = repository.getActiveDailyLedger()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLedgerHistory: StateFlow<List<DailyLedgerEntity>> = repository.getAllLedgerHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isServerReachable = repository.isServerReachable
    val isProcessingQueue = repository.isProcessingQueue
    val orphanedPhotoCount = repository.orphanedPhotoCount
    val orphanedPhotoBytes = repository.orphanedPhotoBytes

    // Capture Session State (Up to 8 photos)
    var activeBarcode by mutableStateOf("")
    var activeCareInfo by mutableStateOf("")
    var activePackageCode by mutableStateOf(appSettings.packageCode)
    var activeSetSize by mutableStateOf("1")
    val capturedPhotos = mutableStateListOf<File>()
    var selectedKeyPhotoIndex by mutableStateOf(0)
    var isTorchEnabled by mutableStateOf(false)
    var isSavingCapture by mutableStateOf(false)

    // Export validation toggle
    var requireAllFieldsComplete by mutableStateOf(appSettings.requireAllFieldsComplete)
    var showExportBlockedDialog by mutableStateOf(false)
    var showExportWarnDialog by mutableStateOf(false)
    var incompleteItemsList by mutableStateOf<List<Pair<String, List<String>>>>(emptyList())

    // Review & Edit Modal State
    var selectedScanForReview by mutableStateOf<ScanEntity?>(null)

    // UI Notices
    var toastMessage by mutableStateOf<String?>(null)
    var showConnectionAlertBanner by mutableStateOf(false)
    var hasDismissedBannerSession by mutableStateOf(false)

    // Live Server Connection Validation State
    var isTestingConnection by mutableStateOf(false)
    var connectionTestResult by mutableStateOf<VisionExtractionService.ConnectionValidationResult?>(null)

    // CSV Export & Cut-Off Confirmation State
    var pendingExportBatchId by mutableStateOf<String?>(null)
    var showCsvCutoffConfirmDialog by mutableStateOf(false)
    var lastExportedItemCount by mutableStateOf(0)

    // Step 3: Shift Manifest & Production Audit State
    var showStep3ManifestDialog by mutableStateOf(false)
    var currentShiftManifest by mutableStateOf<ShiftManifestSummary?>(null)
    var isSyncingBatch by mutableStateOf(false)
    var lastCompletedBatchId by mutableStateOf<String?>(null)

    init {
        viewModelScope.launch {
            repository.isServerReachable.collect { reachable ->
                if (!reachable && !hasDismissedBannerSession) {
                    showConnectionAlertBanner = true
                } else if (reachable) {
                    showConnectionAlertBanner = false
                }
            }
        }
    }

    fun dismissConnectionAlert() {
        showConnectionAlertBanner = false
        hasDismissedBannerSession = true
    }

    fun updatePackageCode(code: String) {
        activePackageCode = code
        appSettings.packageCode = code
    }

    fun updateRequireAllFieldsComplete(require: Boolean) {
        requireAllFieldsComplete = require
        appSettings.requireAllFieldsComplete = require
    }

    fun testServerConnection() {
        viewModelScope.launch {
            isTestingConnection = true
            try {
                val result = repository.validateServerConnection()
                connectionTestResult = result
                if (result.isSuccessful) {
                    showConnectionAlertBanner = false
                    toastMessage = "Middleware connection & JWT auth validated successfully!"
                } else {
                    toastMessage = result.errorMessage ?: "Validation failed"
                }
            } catch (e: Exception) {
                toastMessage = "Connection failed: ${e.message}"
            } finally {
                isTestingConnection = false
            }
        }
    }

    fun setBarcode(barcode: String) {
        activeBarcode = barcode.trim()
    }

    fun addCapturedPhoto(file: File) {
        if (capturedPhotos.size < 8) {
            capturedPhotos.add(file)
            if (capturedPhotos.size == 1) {
                selectedKeyPhotoIndex = 0
            }
        } else {
            toastMessage = "Maximum 8 photos allowed per label session"
        }
    }

    fun removePhotoAt(index: Int) {
        if (index in capturedPhotos.indices) {
            val removed = capturedPhotos.removeAt(index)
            try {
                removed.delete()
            } catch (ignored: Exception) {}
            if (selectedKeyPhotoIndex >= capturedPhotos.size) {
                selectedKeyPhotoIndex = (capturedPhotos.size - 1).coerceAtLeast(0)
            }
        }
    }

    fun selectKeyPhoto(index: Int) {
        if (index in capturedPhotos.indices) {
            selectedKeyPhotoIndex = index
        }
    }

    fun toggleTorch() {
        isTorchEnabled = !isTorchEnabled
    }

    fun resetCaptureSession() {
        activeBarcode = ""
        activeCareInfo = ""
        capturedPhotos.clear()
        selectedKeyPhotoIndex = 0
        isTorchEnabled = false
    }

    /**
     * Guaranteed Lifecycle: Moves ephemeral capture session into Room database.
     */
    fun queueCurrentItemBatch(onSuccess: () -> Unit) {
        val barcode = activeBarcode.trim()
        if (barcode.isBlank()) {
            toastMessage = "Please scan or enter a garment barcode"
            return
        }

        if (capturedPhotos.isEmpty()) {
            toastMessage = "Please capture at least one care tag photo"
            return
        }

        isSavingCapture = true
        val photosSnapshot = capturedPhotos.toList()
        val keyIndex = selectedKeyPhotoIndex
        val pkg = activePackageCode
        val set = activeSetSize.toIntOrNull() ?: 1
        val care = activeCareInfo

        viewModelScope.launch {
            try {
                repository.createNewScanBatch(
                    apparelId = barcode,
                    photoFiles = photosSnapshot,
                    keyPhotoIndex = keyIndex,
                    packageCode = pkg,
                    setSize = set,
                    careInfo = care
                )
                toastMessage = "Item $barcode queued for AI Extraction"
                resetCaptureSession()
                onSuccess()
            } catch (e: Exception) {
                toastMessage = "Failed to queue session: ${e.message}"
            } finally {
                isSavingCapture = false
            }
        }
    }

    fun triggerManualRetry(scan: ScanEntity) {
        viewModelScope.launch {
            toastMessage = "Submitting ${scan.apparelId} to Vision service..."
            repository.submitScanToMiddleware(scan)
        }
    }

    fun syncAllPending() {
        viewModelScope.launch {
            toastMessage = "Processing queue..."
            repository.triggerManualSyncAll()
        }
    }

    fun openReviewDialog(scan: ScanEntity) {
        selectedScanForReview = scan
    }

    fun dismissReviewDialog() {
        selectedScanForReview = null
    }

    fun confirmAndSaveVerifiedItem(
        scan: ScanEntity,
        category: String,
        subCategory: String,
        gender: String,
        season: String,
        brandName: String,
        country: String,
        size: String,
        color: String,
        material: String,
        price: String,
        netto: String,
        brutto: String,
        packageCode: String? = null,
        setSize: Int? = 1,
        careInfo: String? = null
    ) {
        viewModelScope.launch {
            try {
                repository.confirmAndSaveLedger(
                    scan = scan,
                    verifiedCategory = category,
                    verifiedSubCategory = subCategory,
                    verifiedGender = gender,
                    verifiedSeason = season,
                    verifiedBrandName = brandName,
                    verifiedCountryOfOrigin = country,
                    verifiedSize = size,
                    verifiedColor = color,
                    verifiedMaterial = material,
                    verifiedOriginalPrice = price,
                    verifiedNetto = netto,
                    verifiedBrutto = brutto,
                    packageCode = packageCode,
                    setSize = setSize,
                    careInfo = careInfo
                )
                selectedScanForReview = null
                toastMessage = "Saved ${scan.apparelId} to Daily Ledger"
            } catch (e: Exception) {
                toastMessage = "Save failed: ${e.message}"
            }
        }
    }

    fun saveScanTemporaryDraft(
        scan: ScanEntity,
        category: String,
        subCategory: String,
        gender: String,
        season: String,
        brandName: String,
        country: String,
        size: String,
        color: String,
        material: String,
        price: String,
        netto: String,
        brutto: String,
        packageCode: String? = null,
        setSize: Int? = null,
        careInfo: String? = null,
        keyPhotoIndex: Int = scan.keyPhotoIndex
    ) {
        viewModelScope.launch {
            try {
                val updatedScan = scan.copy(
                    extractedCategory = category,
                    extractedSubCategory = subCategory,
                    extractedGender = gender,
                    extractedSeason = season,
                    extractedBrandName = brandName,
                    extractedCountryOfOrigin = country,
                    extractedSize = size,
                    extractedColor = color,
                    extractedMaterial = material,
                    extractedOriginalPrice = price,
                    extractedNetto = netto,
                    extractedBrutto = brutto,
                    packageCode = packageCode ?: scan.packageCode,
                    setSize = setSize ?: scan.setSize,
                    extractedCareInfo = careInfo ?: scan.extractedCareInfo,
                    keyPhotoIndex = keyPhotoIndex
                )
                repository.updateScan(updatedScan)
                selectedScanForReview = null
                toastMessage = "Draft saved for ${scan.apparelId}. Review or confirm later."
            } catch (e: Exception) {
                toastMessage = "Failed to save draft: ${e.message}"
            }
        }
    }

    fun updateLedgerItem(item: DailyLedgerEntity) {
        viewModelScope.launch {
            try {
                repository.updateLedgerItem(item)
                toastMessage = "Updated ${item.apparelId}"
            } catch (e: Exception) {
                toastMessage = "Update failed: ${e.message}"
            }
        }
    }

    fun deleteScan(apparelId: String) {
        viewModelScope.launch {
            repository.deleteScan(apparelId)
            toastMessage = "Removed $apparelId"
        }
    }

    fun deleteLedgerItem(apparelId: String) {
        viewModelScope.launch {
            repository.deleteLedgerItem(apparelId)
            toastMessage = "Deleted from ledger"
        }
    }

    fun duplicateLedgerItem(originalId: String, newId: String) {
        if (newId.isBlank()) {
            toastMessage = "Please enter target barcode"
            return
        }
        viewModelScope.launch {
            try {
                repository.duplicateLedgerItem(originalId, newId)
                toastMessage = "Created clone with barcode $newId"
            } catch (e: Exception) {
                toastMessage = "Duplication error: ${e.message}"
            }
        }
    }

    fun validateItemsForExport(items: List<DailyLedgerEntity>): List<Pair<String, List<String>>> {
        val incomplete = mutableListOf<Pair<String, List<String>>>()
        for (item in items) {
            val missing = mutableListOf<String>()
            if (item.apparelId.isBlank()) missing.add("Barcode")
            if (item.brandName.isBlank()) missing.add("Brand")
            if (item.category.isBlank()) missing.add("Category")
            if (item.subCategory.isBlank()) missing.add("SubCategory")
            if (item.gender.isBlank()) missing.add("Gender")
            if (item.season.isBlank()) missing.add("Season")
            if (item.size.isBlank()) missing.add("Size")
            if (item.color.isBlank()) missing.add("Color")
            if (item.material.isBlank()) missing.add("Material")
            if (item.countryOfOrigin.isBlank()) missing.add("Country")
            if (item.netto.isBlank()) missing.add("Netto")
            if (item.brutto.isBlank()) missing.add("Brutto")
            if (missing.isNotEmpty()) {
                incomplete.add(Pair(item.apparelId.ifBlank { "Unknown Item" }, missing))
            }
        }
        return incomplete
    }

    // Step 1: Export CSV and share without clearing DB
    fun shareCsvExport() {
        viewModelScope.launch {
            val activeItems = repository.getActiveDailyLedgerList()
            if (activeItems.isEmpty()) {
                toastMessage = "No active ledger items to export"
                return@launch
            }

            val incomplete = validateItemsForExport(activeItems)
            if (incomplete.isNotEmpty()) {
                incompleteItemsList = incomplete
                if (requireAllFieldsComplete) {
                    showExportBlockedDialog = true
                    return@launch
                } else {
                    showExportWarnDialog = true
                    return@launch
                }
            }

            executeCsvExport()
        }
    }

    fun executeCsvExport() {
        showExportWarnDialog = false
        showExportBlockedDialog = false
        viewModelScope.launch {
            try {
                val activeList = repository.getActiveDailyLedgerList()
                lastExportedItemCount = activeList.size
                val (csvFile, batchId) = repository.generateCsvExportFile()
                pendingExportBatchId = batchId

                val context = getApplication<Application>()
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    csvFile
                )

                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_SUBJECT, "Apparel Care Labels Export - ${csvFile.name}")
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }

                val chooser = Intent.createChooser(intent, "Export Apparel CSV").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)

                // Show confirmation prompt for moving session cut-off
                showCsvCutoffConfirmDialog = true
            } catch (e: Exception) {
                toastMessage = "CSV export error: ${e.message}"
            }
        }
    }

    // Step 2: Confirm delivery and advance session cut-off
    fun confirmCsvCutoff() {
        val batchId = pendingExportBatchId
        viewModelScope.launch {
            if (!batchId.isNullOrBlank()) {
                repository.confirmCsvCutOff(batchId)
            } else {
                repository.confirmAllActiveCsvCutOff()
            }
            showCsvCutoffConfirmDialog = false
            pendingExportBatchId = null
            lastCompletedBatchId = batchId

            // Automatically launch Step 3: Shift Handover Manifest & Production Audit
            try {
                val manifest = repository.generateShiftManifest(batchId)
                currentShiftManifest = manifest
                showStep3ManifestDialog = true
                toastMessage = "Step 2 Complete! Step 3: Shift Manifest generated."
            } catch (e: Exception) {
                toastMessage = "Step 2 Complete: CSV cut-off confirmed. Session advanced."
            }
        }
    }

    // =========================================================================
    // Step 3: Shift Manifest, Backend Sync & Production Closeout
    // =========================================================================

    fun showShiftManifestForBatch(batchId: String? = null) {
        viewModelScope.launch {
            try {
                val targetBatch = batchId ?: lastCompletedBatchId
                val manifest = repository.generateShiftManifest(targetBatch)
                currentShiftManifest = manifest
                showStep3ManifestDialog = true
            } catch (e: Exception) {
                toastMessage = "Could not generate manifest: ${e.message}"
            }
        }
    }

    fun shareShiftManifest(summary: ShiftManifestSummary) {
        viewModelScope.launch {
            try {
                val file = repository.generateShiftManifestFile(summary)
                val context = getApplication<Application>()
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    file
                )
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "Apparel Vision Shift Manifest - ${summary.batchId}")
                    putExtra(Intent.EXTRA_TEXT, repository.formatShiftManifestText(summary))
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                val chooser = Intent.createChooser(intent, "Share Shift Manifest").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
            } catch (e: Exception) {
                toastMessage = "Share manifest failed: ${e.message}"
            }
        }
    }

    fun syncCurrentBatchToBackend() {
        val summary = currentShiftManifest ?: return
        viewModelScope.launch {
            isSyncingBatch = true
            try {
                val count = repository.syncBatchToBackend(summary.batchId)
                currentShiftManifest = summary.copy(syncStatus = "SYNCED_BACKEND")
                toastMessage = "Step 3: Synced $count items for batch ${summary.batchId} to backend."
            } catch (e: Exception) {
                toastMessage = "Sync failed: ${e.message}"
            } finally {
                isSyncingBatch = false
            }
        }
    }

    fun completeStep3Closeout(cleanupPhotos: Boolean = true) {
        viewModelScope.launch {
            showStep3ManifestDialog = false
            if (cleanupPhotos) {
                val deleted = repository.cleanOrphanedPhotos()
                toastMessage = "Step 3 Complete: Shift closed out and $deleted cache files cleaned."
            } else {
                toastMessage = "Step 3 Complete: Shift closed out. Ready for next session."
            }
        }
    }

    fun promptManualSessionCutoff() {
        viewModelScope.launch {
            val activeList = repository.getActiveDailyLedgerList()
            if (activeList.isEmpty()) {
                toastMessage = "No active ledger records to cut off"
                return@launch
            }
            lastExportedItemCount = activeList.size
            showCsvCutoffConfirmDialog = true
        }
    }

    fun shareArchiveCsvExport() {
        viewModelScope.launch {
            try {
                val history = repository.getAllLedgerHistoryList()
                if (history.isEmpty()) {
                    toastMessage = "No archive records to export"
                    return@launch
                }
                val csvFile = repository.generateArchiveCsvExportFile()
                val context = getApplication<Application>()
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    csvFile
                )

                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_SUBJECT, "Apparel Care Labels Archive - ${csvFile.name}")
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }

                val chooser = Intent.createChooser(intent, "Export Archive CSV").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)
                toastMessage = "Archive CSV exported (${history.size} records)"
            } catch (e: Exception) {
                toastMessage = "Archive export error: ${e.message}"
            }
        }
    }

    fun dismissCsvCutoffDialog() {
        showCsvCutoffConfirmDialog = false
        toastMessage = "Records kept in active session."
    }

    fun cleanOrphanedPhotos() {
        viewModelScope.launch {
            val count = repository.cleanOrphanedPhotos()
            toastMessage = "Cleaned $count unused photos from storage"
        }
    }

    fun purgeAllDataAndPhotos() {
        viewModelScope.launch {
            repository.purgeAllDataAndPhotos()
            resetCaptureSession()
            toastMessage = "All database records and photo cache cleared"
        }
    }

    fun getPhotoPaths(json: String?): List<String> = repository.getPhotoPaths(json)
    fun getConfidences(json: String?): Map<String, Float> = repository.getConfidences(json)
}
