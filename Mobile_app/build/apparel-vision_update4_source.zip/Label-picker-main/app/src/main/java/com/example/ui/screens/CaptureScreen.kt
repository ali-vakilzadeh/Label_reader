package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.camera.core.ImageCapture
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.ui.components.CameraPreviewView
import com.example.ui.components.generateSampleTagImageFile
import com.example.ui.components.takePhoto
import com.example.ui.theme.LsBeige100
import com.example.ui.theme.LsBeige300
import com.example.ui.theme.LsCocoa500
import com.example.ui.theme.LsCocoa600
import com.example.ui.theme.LsCocoa900
import com.example.ui.theme.LsCreme
import com.example.ui.theme.LsGold200
import com.example.ui.theme.LsGold500
import com.example.ui.theme.LsGold600
import com.example.ui.theme.LsGold800
import com.example.ui.theme.LsGoldWash
import com.example.ui.theme.LsLinen
import com.example.ui.theme.LsNavy700
import com.example.ui.theme.LsNavy900
import com.example.ui.theme.LsOchre600
import com.example.ui.theme.LsRust50
import com.example.ui.theme.LsRust500
import com.example.ui.theme.LsRust700
import com.example.ui.viewmodel.ApparelViewModel
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CaptureScreen(
    viewModel: ApparelViewModel,
    onNavigateToReview: () -> Unit
) {
    val context = LocalContext.current
    var isBarcodeMode by remember { mutableStateOf(false) }
    val imageCapture = remember { ImageCapture.Builder().build() }

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris: List<Uri> ->
        for (uri in uris) {
            if (viewModel.capturedPhotos.size >= 8) break
            try {
                val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val photoIndex = viewModel.capturedPhotos.size
                val barcode = viewModel.activeBarcode.ifBlank { "draft" }
                val targetFile = File(context.filesDir, "IMG_${barcode}_${timeStamp}_$photoIndex.jpg")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(targetFile).use { output ->
                        input.copyTo(output)
                    }
                }
                viewModel.addCapturedPhoto(targetFile)
            } catch (e: Exception) {
                viewModel.toastMessage = "Could not import image: ${e.message}"
            }
        }
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(LsCreme)
            .testTag("capture_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar
            Surface(
                color = LsGold800,
                modifier = Modifier.fillMaxWidth(),
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "GARMENT INTAKE",
                            color = LsGold200,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Barcode & Care Tag Capture",
                            color = LsLinen,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = { viewModel.toggleTorch() },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(if (viewModel.isTorchEnabled) LsGold500 else Color.White.copy(alpha = 0.15f))
                                .size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (viewModel.isTorchEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                                contentDescription = "Toggle Torch",
                                tint = if (viewModel.isTorchEnabled) LsCocoa900 else LsLinen,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // Barcode Input Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = LsLinen),
                border = BorderStroke(1.dp, LsBeige300)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = viewModel.activeBarcode,
                        onValueChange = { viewModel.setBarcode(it) },
                        label = { Text("Garment Barcode / ID", fontSize = 12.sp, color = LsCocoa600) },
                        placeholder = { Text("Scan or type barcode", color = LsCocoa500) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("barcode_input_field"),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LsGold500,
                            unfocusedBorderColor = LsBeige300,
                            focusedTextColor = LsCocoa900,
                            unfocusedTextColor = LsCocoa900,
                            focusedContainerColor = LsLinen,
                            unfocusedContainerColor = LsLinen
                        )
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = {
                            if (!hasCameraPermission) {
                                permissionLauncher.launch(Manifest.permission.CAMERA)
                            }
                            isBarcodeMode = !isBarcodeMode
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isBarcodeMode) LsGold500 else LsNavy900
                        ),
                        modifier = Modifier.testTag("toggle_barcode_scanner_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = null,
                            tint = if (isBarcodeMode) LsCocoa900 else LsLinen,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isBarcodeMode) "Scanner ON" else "Scan",
                            color = if (isBarcodeMode) LsCocoa900 else LsLinen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // Live Camera Viewfinder Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 14.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, LsBeige300, RoundedCornerShape(14.dp))
            ) {
                CameraPreviewView(
                    modifier = Modifier.fillMaxSize(),
                    isTorchEnabled = viewModel.isTorchEnabled,
                    imageCapture = imageCapture,
                    isBarcodeMode = isBarcodeMode,
                    onBarcodeDetected = { scannedCode ->
                        viewModel.setBarcode(scannedCode)
                        isBarcodeMode = false
                        viewModel.toastMessage = "Barcode: $scannedCode"
                    }
                )

                // If permission missing, show permission prompt button
                if (!hasCameraPermission) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                            colors = ButtonDefaults.buttonColors(containerColor = LsGold500),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = null, tint = LsCocoa900)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Grant Camera Permission", color = LsCocoa900, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Snapping & Auxiliary Action Buttons Floating on Viewfinder Bottom
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Gallery / Files Import Button
                        IconButton(
                            onClick = { galleryLauncher.launch("image/*") },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.65f))
                                .border(1.dp, LsGold500, CircleShape)
                                .size(48.dp)
                                .testTag("import_gallery_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhotoLibrary,
                                contentDescription = "Import from Gallery",
                                tint = LsGold200,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        // Main Snap Photo Button
                        Button(
                            onClick = {
                                val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                val photoIndex = viewModel.capturedPhotos.size
                                val barcode = viewModel.activeBarcode.ifBlank { "draft" }
                                val photoFile = File(context.filesDir, "IMG_${barcode}_${timeStamp}_$photoIndex.jpg")

                                takePhoto(
                                    context = context,
                                    imageCapture = imageCapture,
                                    outputFile = photoFile,
                                    onSuccess = { file ->
                                        viewModel.addCapturedPhoto(file)
                                    },
                                    onError = { exc ->
                                        viewModel.toastMessage = "Capture fallback: ${exc.message}"
                                    }
                                )
                            },
                            enabled = viewModel.capturedPhotos.size < 8,
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(containerColor = LsGold500),
                            modifier = Modifier
                                .size(68.dp)
                                .testTag("snap_photo_button"),
                            elevation = ButtonDefaults.buttonElevation(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "Take Photo",
                                tint = LsCocoa900,
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        // Sample Care Tag Generator Button (Instant demo care label)
                        IconButton(
                            onClick = {
                                if (viewModel.capturedPhotos.size < 8) {
                                    val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                                    val photoIndex = viewModel.capturedPhotos.size
                                    val barcode = viewModel.activeBarcode.ifBlank { "sample" }
                                    val sampleFile = File(context.filesDir, "IMG_${barcode}_${timeStamp}_$photoIndex.jpg")
                                    generateSampleTagImageFile(sampleFile)
                                    viewModel.addCapturedPhoto(sampleFile)
                                    viewModel.toastMessage = "Generated sample care tag photo"
                                }
                            },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.65f))
                                .border(1.dp, LsGold500, CircleShape)
                                .size(48.dp)
                                .testTag("sample_tag_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Add Sample Tag",
                                tint = LsGold200,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }
            }

            // Up to 8 Photos Filmstrip Carousel
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = LsLinen),
                border = BorderStroke(1.dp, LsBeige300)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Captured Care Labels (${viewModel.capturedPhotos.size}/8)",
                            color = LsCocoa900,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "★ = Key Image for Catalog",
                            color = LsGold800,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    if (viewModel.capturedPhotos.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(72.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(LsBeige100),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "Take 1 to 8 photos of care tag, labels & composition",
                                color = LsCocoa600,
                                fontSize = 12.sp
                            )
                        }
                    } else {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            itemsIndexed(viewModel.capturedPhotos) { index, photoFile ->
                                val isKey = index == viewModel.selectedKeyPhotoIndex

                                Box(
                                    modifier = Modifier
                                        .size(72.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(
                                            width = if (isKey) 2.dp else 1.dp,
                                            color = if (isKey) LsGold500 else LsBeige300,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable { viewModel.selectKeyPhoto(index) }
                                ) {
                                    AsyncImage(
                                        model = ImageRequest.Builder(context)
                                            .data(photoFile)
                                            .crossfade(true)
                                            .build(),
                                        contentDescription = "Label Photo #$index",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )

                                    // Key Photo star tag
                                    IconButton(
                                        onClick = { viewModel.selectKeyPhoto(index) },
                                        modifier = Modifier
                                            .size(22.dp)
                                            .align(Alignment.TopStart)
                                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                                    ) {
                                        Icon(
                                            imageVector = if (isKey) Icons.Filled.Star else Icons.Outlined.StarOutline,
                                            contentDescription = "Set as Key Photo",
                                            tint = if (isKey) LsGold500 else Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }

                                    // Delete photo button
                                    IconButton(
                                        onClick = { viewModel.removePhotoAt(index) },
                                        modifier = Modifier
                                            .size(20.dp)
                                            .align(Alignment.TopEnd)
                                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Remove photo",
                                            tint = Color.White,
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Guaranteed Lifecycle Commit Action: "Finish Item"
            Surface(
                color = LsLinen,
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(1.dp, LsBeige300)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { viewModel.resetCaptureSession() },
                        colors = ButtonDefaults.buttonColors(containerColor = LsBeige100),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(0.35f)
                    ) {
                        Text("Reset", color = LsCocoa900, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = {
                            viewModel.queueCurrentItemBatch {
                                onNavigateToReview()
                            }
                        },
                        enabled = !viewModel.isSavingCapture && viewModel.activeBarcode.isNotBlank() && viewModel.capturedPhotos.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(0.65f)
                            .testTag("finish_item_button")
                    ) {
                        if (viewModel.isSavingCapture) {
                            CircularProgressIndicator(color = LsLinen, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Check, contentDescription = null, tint = LsLinen, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Finish Item",
                                color = LsLinen,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
