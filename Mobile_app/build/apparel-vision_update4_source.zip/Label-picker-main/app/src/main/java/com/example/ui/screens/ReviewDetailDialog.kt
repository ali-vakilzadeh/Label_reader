package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.local.entity.ScanEntity
import com.example.data.reference.ReferenceVocabulary
import com.example.ui.theme.LsBeige100
import com.example.ui.theme.LsBeige300
import com.example.ui.theme.LsCocoa500
import com.example.ui.theme.LsCocoa600
import com.example.ui.theme.LsCocoa900
import com.example.ui.theme.LsCreme
import com.example.ui.theme.LsGold200
import com.example.ui.theme.LsGold500
import com.example.ui.theme.LsGold600
import com.example.ui.theme.LsGold800
import com.example.ui.theme.LsLinen
import com.example.ui.theme.LsRust200
import com.example.ui.theme.LsRust50
import com.example.ui.theme.LsRust500
import com.example.ui.theme.LsRust700
import com.example.ui.viewmodel.ApparelViewModel
import java.io.File

@Composable
fun ReviewDetailDialog(
    scan: ScanEntity,
    viewModel: ApparelViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val photoPaths = viewModel.getPhotoPaths(scan.photoPathsJson)
    val confidences = viewModel.getConfidences(scan.confidencesJson)

    var activePhotoIndex by remember { mutableStateOf(scan.keyPhotoIndex.coerceIn(0, (photoPaths.size - 1).coerceAtLeast(0))) }

    var category by remember { mutableStateOf(scan.extractedCategory) }
    var subCategory by remember { mutableStateOf(scan.extractedSubCategory) }
    var gender by remember { mutableStateOf(scan.extractedGender) }
    var season by remember { mutableStateOf(scan.extractedSeason) }
    var brandName by remember { mutableStateOf(scan.extractedBrandName) }
    var country by remember { mutableStateOf(scan.extractedCountryOfOrigin) }
    var size by remember { mutableStateOf(scan.extractedSize) }
    var color by remember { mutableStateOf(scan.extractedColor) }
    var material by remember { mutableStateOf(scan.extractedMaterial) }
    var price by remember { mutableStateOf(scan.extractedOriginalPrice) }
    var netto by remember { mutableStateOf(scan.extractedNetto) }
    var brutto by remember { mutableStateOf(scan.extractedBrutto) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(LsCreme)
                .testTag("review_detail_dialog"),
            color = LsCreme
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Header
                Surface(
                    color = LsGold800,
                    modifier = Modifier.fillMaxWidth(),
                    shadowElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "VERIFY ITEM: ${scan.apparelId}",
                                color = LsGold200,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Care Label & Composition Audit",
                                color = LsLinen,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = LsLinen)
                        }
                    }
                }

                // Scrollable Form & Image Inspector
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Image Viewer Box
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = LsLinen),
                        border = BorderStroke(1.dp, LsBeige300)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            val activePhoto = if (photoPaths.isNotEmpty() && activePhotoIndex in photoPaths.indices) {
                                File(photoPaths[activePhotoIndex])
                            } else null

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(LsBeige100),
                                contentAlignment = Alignment.Center
                            ) {
                                if (activePhoto != null && activePhoto.exists()) {
                                    AsyncImage(
                                        model = ImageRequest.Builder(context)
                                            .data(activePhoto)
                                            .crossfade(true)
                                            .build(),
                                        contentDescription = "Active Care Label Photo",
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Text("No photo available", color = LsCocoa500, fontSize = 12.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Filmstrip Selector
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                itemsIndexed(photoPaths) { idx, path ->
                                    val isSelected = idx == activePhotoIndex
                                    Box(
                                        modifier = Modifier
                                            .size(52.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .border(
                                                width = if (isSelected) 2.dp else 1.dp,
                                                color = if (isSelected) LsGold500 else LsBeige300,
                                                shape = RoundedCornerShape(6.dp)
                                            )
                                            .clickable { activePhotoIndex = idx }
                                    ) {
                                        AsyncImage(
                                            model = ImageRequest.Builder(context)
                                                .data(File(path))
                                                .crossfade(true)
                                                .build(),
                                            contentDescription = "Thumb #$idx",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // 12 Care Label Fields Form
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = LsLinen),
                        border = BorderStroke(1.dp, LsBeige300)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = "12 Extracted Care Attributes (v1.2 Standard)",
                                color = LsCocoa900,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )

                            // Brand Name (839 entries autocomplete)
                            AutoCompleteReviewInputField(
                                label = "Brand Name",
                                value = brandName,
                                confidence = confidences["brand_name"],
                                suggestions = ReferenceVocabulary.searchBrands(brandName, limit = 6),
                                onValueChange = { brandName = it }
                            )

                            // Category (clothing, shoe, accessories)
                            EnumSelectorField(
                                label = "Category",
                                selectedValue = category,
                                confidence = confidences["category"],
                                options = ReferenceVocabulary.CATEGORIES,
                                onSelect = { category = it }
                            )

                            // Sub-Category (295 entries autocomplete)
                            AutoCompleteReviewInputField(
                                label = "Sub-Category",
                                value = subCategory,
                                confidence = confidences["sub_category"],
                                suggestions = ReferenceVocabulary.searchSubCategories(subCategory, limit = 6),
                                onValueChange = { subCategory = it }
                            )

                            // Gender & Season Pickers
                            EnumSelectorField(
                                label = "Gender",
                                selectedValue = gender,
                                confidence = confidences["gender"],
                                options = ReferenceVocabulary.GENDERS,
                                onSelect = { gender = it }
                            )

                            EnumSelectorField(
                                label = "Season",
                                selectedValue = season,
                                confidence = confidences["season"],
                                options = ReferenceVocabulary.SEASONS,
                                onSelect = { season = it }
                            )

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(modifier = Modifier.weight(1f)) {
                                    ReviewInputField("Size", size, confidences["size"]) { size = it }
                                }
                                Box(modifier = Modifier.weight(1f)) {
                                    AutoCompleteReviewInputField(
                                        label = "Color",
                                        value = color,
                                        confidence = confidences["color"],
                                        suggestions = ReferenceVocabulary.COLORS.filter { it.contains(color.trim(), ignoreCase = true) }.take(6),
                                        onValueChange = { color = it }
                                    )
                                }
                            }

                            // Material (85 single-fibre entries)
                            AutoCompleteReviewInputField(
                                label = "Material (Single Fibre)",
                                value = material,
                                confidence = confidences["material"],
                                suggestions = ReferenceVocabulary.searchMaterials(material, limit = 6),
                                onValueChange = { material = it }
                            )

                            // Country of Origin (222 uppercase entries)
                            AutoCompleteReviewInputField(
                                label = "Country of Origin (UPPERCASE)",
                                value = country,
                                confidence = confidences["country_of_origin"],
                                suggestions = ReferenceVocabulary.searchCountries(country, limit = 6),
                                onValueChange = { country = it.uppercase() }
                            )

                            ReviewInputField("Original Price", price, confidences["original_price"]) { price = it }

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(modifier = Modifier.weight(1f)) {
                                    ReviewInputField("Netto Weight", netto, confidences["netto"]) { netto = it }
                                }
                                Box(modifier = Modifier.weight(1f)) {
                                    ReviewInputField("Brutto Weight", brutto, confidences["brutto"]) { brutto = it }
                                }
                            }
                        }
                    }
                }

                // Bottom Action Bar
                Surface(
                    color = LsLinen,
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, LsBeige300)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = LsBeige100),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(0.35f)
                        ) {
                            Text("Cancel", color = LsCocoa900, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }

                        Button(
                            onClick = {
                                viewModel.confirmAndSaveVerifiedItem(
                                    scan = scan,
                                    category = category,
                                    subCategory = subCategory,
                                    gender = gender,
                                    season = season,
                                    brandName = brandName,
                                    country = country,
                                    size = size,
                                    color = color,
                                    material = material,
                                    price = price,
                                    netto = netto,
                                    brutto = brutto
                                )
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(0.65f)
                                .testTag("confirm_and_save_button")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = LsLinen, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Confirm & Save to Ledger", color = LsLinen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EnumSelectorField(
    label: String,
    selectedValue: String,
    confidence: Float?,
    options: List<String>,
    onSelect: (String) -> Unit
) {
    val isLowConfidence = confidence != null && confidence < 0.70f && selectedValue.isNotBlank()
    val isMissing = selectedValue.isBlank()

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, fontSize = 12.sp, color = LsCocoa600, fontWeight = FontWeight.Medium)
            if (isMissing) {
                Text("Missing from scan", fontSize = 10.sp, color = LsRust700, fontWeight = FontWeight.Bold)
            } else if (confidence != null) {
                Text(
                    text = "${(confidence * 100).toInt()}% conf",
                    fontSize = 10.sp,
                    color = if (isLowConfidence) LsRust700 else LsGold800,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(options) { opt ->
                val isSelected = opt.equals(selectedValue, ignoreCase = true)
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isSelected) LsGold800 else LsBeige100,
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (isSelected) LsGold800 else if (isLowConfidence || isMissing) LsRust200 else LsBeige300
                    ),
                    modifier = Modifier
                        .clickable { onSelect(opt) }
                ) {
                    Text(
                        text = opt,
                        color = if (isSelected) LsLinen else LsCocoa900,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AutoCompleteReviewInputField(
    label: String,
    value: String,
    confidence: Float?,
    suggestions: List<String>,
    onValueChange: (String) -> Unit
) {
    val isLowConfidence = confidence != null && confidence < 0.70f && value.isNotBlank()
    val isMissing = value.isBlank()

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, fontSize = 12.sp, color = LsCocoa600, fontWeight = FontWeight.Medium)
            if (isMissing) {
                Text("Missing from scan", fontSize = 10.sp, color = LsRust700, fontWeight = FontWeight.Bold)
            } else if (confidence != null) {
                Text(
                    text = "${(confidence * 100).toInt()}% conf",
                    fontSize = 10.sp,
                    color = if (isLowConfidence) LsRust700 else LsGold800,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(2.dp))

        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = if (isLowConfidence || isMissing) LsRust500 else LsGold500,
                unfocusedBorderColor = if (isLowConfidence || isMissing) LsRust200 else LsBeige300,
                focusedContainerColor = if (isLowConfidence || isMissing) LsRust50 else LsLinen,
                unfocusedContainerColor = if (isLowConfidence || isMissing) LsRust50 else LsLinen,
                focusedTextColor = LsCocoa900,
                unfocusedTextColor = LsCocoa900
            )
        )

        // Type-ahead suggestion chips
        if (suggestions.isNotEmpty() && suggestions.none { it.equals(value.trim(), ignoreCase = true) }) {
            Spacer(modifier = Modifier.height(4.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(suggestions) { sugg ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = LsBeige100,
                        border = BorderStroke(1.dp, LsGold500.copy(alpha = 0.5f)),
                        modifier = Modifier.clickable { onValueChange(sugg) }
                    ) {
                        Text(
                            text = sugg,
                            color = LsGold800,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ReviewInputField(
    label: String,
    value: String,
    confidence: Float?,
    onValueChange: (String) -> Unit
) {
    val isLowConfidence = confidence != null && confidence < 0.70f && value.isNotBlank()
    val isMissing = value.isBlank()

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = label, fontSize = 12.sp, color = LsCocoa600, fontWeight = FontWeight.Medium)
            if (isMissing) {
                Text("Missing from scan", fontSize = 10.sp, color = LsRust700, fontWeight = FontWeight.Bold)
            } else if (confidence != null) {
                Text(
                    text = "${(confidence * 100).toInt()}% conf",
                    fontSize = 10.sp,
                    color = if (isLowConfidence) LsRust700 else LsGold800,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Spacer(modifier = Modifier.height(2.dp))

        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = if (isLowConfidence || isMissing) LsRust500 else LsGold500,
                unfocusedBorderColor = if (isLowConfidence || isMissing) LsRust200 else LsBeige300,
                focusedContainerColor = if (isLowConfidence || isMissing) LsRust50 else LsLinen,
                unfocusedContainerColor = if (isLowConfidence || isMissing) LsRust50 else LsLinen,
                focusedTextColor = LsCocoa900,
                unfocusedTextColor = LsCocoa900
            )
        )
    }
}

