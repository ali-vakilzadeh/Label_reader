package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.local.entity.ScanEntity
import com.example.ui.theme.LsBeige100
import com.example.ui.theme.LsBeige300
import com.example.ui.theme.LsCocoa500
import com.example.ui.theme.LsCocoa600
import com.example.ui.theme.LsCocoa900
import com.example.ui.theme.LsCreme
import com.example.ui.theme.LsGold200
import com.example.ui.theme.LsGold500
import com.example.ui.theme.LsGold600
import com.example.ui.theme.LsGold800
import com.example.ui.theme.LsGoldWash
import com.example.ui.theme.LsLinen
import com.example.ui.theme.LsNavy700
import com.example.ui.theme.LsNavy900
import com.example.ui.theme.LsOchre600
import com.example.ui.theme.LsRust200
import com.example.ui.theme.LsRust50
import com.example.ui.theme.LsRust500
import com.example.ui.theme.LsRust700
import com.example.ui.viewmodel.ApparelViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReviewScreen(
    viewModel: ApparelViewModel,
    onNavigateToCapture: () -> Unit
) {
    val pendingScans by viewModel.pendingScans.collectAsStateWithLifecycle()
    val unverifiedScans by viewModel.unverifiedScans.collectAsStateWithLifecycle()
    val isProcessingQueue by viewModel.isProcessingQueue.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0 = Ready for Review, 1 = Server AI Queue / Needs Attention

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(LsCreme)
            .testTag("review_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar
            Surface(
                color = LsGold800,
                modifier = Modifier.fillMaxWidth(),
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "VERIFICATION WORKSPACE",
                            color = LsGold200,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Operator Extraction Review",
                            color = LsLinen,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { viewModel.syncAllPending() },
                            colors = ButtonDefaults.buttonColors(containerColor = LsGold500),
                            shape = RoundedCornerShape(8.dp),
                            enabled = !isProcessingQueue,
                            modifier = Modifier.testTag("sync_all_button")
                        ) {
                            if (isProcessingQueue) {
                                CircularProgressIndicator(color = LsCocoa900, modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.Sync, contentDescription = null, tint = LsCocoa900, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Sync Queue", color = LsCocoa900, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Tab Bar
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = LsLinen,
                contentColor = LsGold800,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = LsGold800,
                        height = 3.dp
                    )
                }
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = {
                        Text(
                            text = "Ready to Review (${unverifiedScans.size})",
                            fontSize = 13.sp,
                            fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTabIndex == 0) LsGold800 else LsCocoa600
                        )
                    }
                )

                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = {
                        Text(
                            text = "AI Queue / Attention (${pendingScans.size})",
                            fontSize = 13.sp,
                            fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTabIndex == 1) LsGold800 else LsCocoa600
                        )
                    }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Tab Content
            if (selectedTabIndex == 0) {
                if (unverifiedScans.isEmpty()) {
                    EmptyStateCard(
                        title = "No Items Awaiting Verification",
                        subtitle = "Scans extracted by AI will appear here for manual verification and confirmation into the Daily Ledger.",
                        actionLabel = "Capture New Item",
                        onAction = onNavigateToCapture
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(unverifiedScans, key = { it.apparelId }) { scan ->
                            ExtractedReviewCard(
                                scan = scan,
                                viewModel = viewModel,
                                onOpenReview = { viewModel.openReviewDialog(scan) },
                                onDelete = { viewModel.deleteScan(scan.apparelId) }
                            )
                        }
                    }
                }
            } else {
                if (pendingScans.isEmpty()) {
                    EmptyStateCard(
                        title = "Queue is Clear",
                        subtitle = "All captured garments have completed vision processing.",
                        actionLabel = "Scan Next Item",
                        onAction = onNavigateToCapture
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(pendingScans, key = { it.apparelId }) { scan ->
                            PendingOrFailedCard(
                                scan = scan,
                                viewModel = viewModel,
                                onRetry = { viewModel.triggerManualRetry(scan) },
                                onOpenManualReview = { viewModel.openReviewDialog(scan) },
                                onDelete = { viewModel.deleteScan(scan.apparelId) }
                            )
                        }
                    }
                }
            }
        }

        // Active Review Detail Modal
        viewModel.selectedScanForReview?.let { scan ->
            ReviewDetailDialog(
                scan = scan,
                viewModel = viewModel,
                onDismiss = { viewModel.dismissReviewDialog() }
            )
        }
    }
}

@Composable
fun ExtractedReviewCard(
    scan: ScanEntity,
    viewModel: ApparelViewModel,
    onOpenReview: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val photoPaths = viewModel.getPhotoPaths(scan.photoPathsJson)
    val keyPhotoFile = if (photoPaths.isNotEmpty()) {
        File(photoPaths.getOrElse(scan.keyPhotoIndex.coerceIn(0, photoPaths.lastIndex)) { photoPaths.first() })
    } else null

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenReview() }
            .testTag("unverified_card_${scan.apparelId}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = LsLinen),
        border = BorderStroke(1.dp, LsBeige300),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Key Thumbnail
            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(LsBeige100)
            ) {
                if (keyPhotoFile != null && keyPhotoFile.exists()) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(keyPhotoFile)
                            .crossfade(true)
                            .build(),
                        contentDescription = "Garment Photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = null,
                        tint = LsCocoa500,
                        modifier = Modifier
                            .size(24.dp)
                            .align(Alignment.Center)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = scan.apparelId,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = LsCocoa900
                    )

                    Surface(
                        color = Color(0xFFDCFCE7),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "AI EXTRACTED",
                            color = Color(0xFF166534),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(3.dp))

                Text(
                    text = "${scan.extractedBrandName.ifBlank { "Unbranded" }} • ${scan.extractedCategory.ifBlank { "Apparel" }}",
                    fontSize = 13.sp,
                    color = LsCocoa600,
                    fontWeight = FontWeight.Medium
                )

                Text(
                    text = "Size: ${scan.extractedSize.ifBlank { "N/A" }} | Color: ${scan.extractedColor.ifBlank { "N/A" }} | Price: ${scan.extractedOriginalPrice.ifBlank { "N/A" }}",
                    fontSize = 11.sp,
                    color = LsCocoa500
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete item",
                    tint = LsRust500,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun PendingOrFailedCard(
    scan: ScanEntity,
    viewModel: ApparelViewModel,
    onRetry: () -> Unit,
    onOpenManualReview: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val photoPaths = viewModel.getPhotoPaths(scan.photoPathsJson)
    val isNeedsAttention = scan.processingStatus == ScanEntity.PROCESSING_NEEDS_ATTENTION || scan.status == ScanEntity.STATUS_FAILED
    val isServerStored = scan.serverStored

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("pending_card_${scan.apparelId}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isNeedsAttention) LsRust50 else LsLinen
        ),
        border = BorderStroke(
            1.dp,
            if (isNeedsAttention) LsRust200 else LsBeige300
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = scan.apparelId,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = LsCocoa900
                    )
                    val dateFormatted = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date(scan.timestamp))
                    Text(
                        text = "Captured: $dateFormatted (${photoPaths.size} photos)",
                        fontSize = 11.sp,
                        color = LsCocoa500
                    )
                }

                Surface(
                    color = if (isNeedsAttention) LsRust200 else if (isServerStored) LsGoldWash else LsBeige100,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = if (isNeedsAttention) "NEEDS ATTENTION" else if (isServerStored) "QUEUED ON SERVER" else "LOCAL QUEUE",
                        color = if (isNeedsAttention) LsRust700 else LsGold800,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Queue status details
            if (isServerStored && !isNeedsAttention) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 2.dp)
                ) {
                    Icon(
                        imageVector = if (scan.blockingFault != null) Icons.Default.PauseCircle else Icons.Default.HourglassTop,
                        contentDescription = null,
                        tint = if (scan.blockingFault != null) LsRust500 else LsGold800,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (scan.blockingFault != null) "Processing paused: ${scan.blockingFault}"
                        else "Queue depth: ${scan.queueDepth} ahead • Est wait: ${scan.estimatedWaitSeconds ?: scan.retryAfterSeconds}s",
                        fontSize = 12.sp,
                        color = LsCocoa600
                    )
                }
            } else if (isNeedsAttention) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Warning,
                        contentDescription = null,
                        tint = LsRust500,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = scan.attentionReason ?: scan.errorMessage ?: "Image requires operator manual review",
                        fontSize = 12.sp,
                        color = LsRust700
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = LsCocoa500, modifier = Modifier.size(18.dp))
                }

                Spacer(modifier = Modifier.width(4.dp))

                Button(
                    onClick = onOpenManualReview,
                    colors = ButtonDefaults.buttonColors(containerColor = LsBeige100),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text("Manual Entry", color = LsCocoa900, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                }

                Spacer(modifier = Modifier.width(6.dp))

                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, tint = LsLinen, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Retry", color = LsLinen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun EmptyStateCard(
    title: String,
    subtitle: String,
    actionLabel: String,
    onAction: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = LsLinen),
        border = BorderStroke(1.dp, LsBeige300)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = LsGold500,
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = LsCocoa900)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = LsCocoa600,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onAction,
                colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(text = actionLabel, color = LsLinen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
