package com.example.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_ledger")
data class DailyLedgerEntity(
    @PrimaryKey
    @ColumnInfo(name = "apparel_id")
    val apparelId: String,

    @ColumnInfo(name = "user_id")
    val userId: String,

    @ColumnInfo(name = "timestamp")
    val timestamp: Long = System.currentTimeMillis(),

    @ColumnInfo(name = "created_date")
    val createdDate: String, // e.g. "2026-08-27"

    // Verified Fields
    @ColumnInfo(name = "category")
    val category: String,

    @ColumnInfo(name = "sub_category")
    val subCategory: String,

    @ColumnInfo(name = "gender")
    val gender: String,

    @ColumnInfo(name = "season")
    val season: String,

    @ColumnInfo(name = "brand_name")
    val brandName: String,

    @ColumnInfo(name = "country_of_origin")
    val countryOfOrigin: String,

    @ColumnInfo(name = "size")
    val size: String,

    @ColumnInfo(name = "color")
    val color: String,

    @ColumnInfo(name = "material")
    val material: String,

    @ColumnInfo(name = "original_price")
    val originalPrice: String,

    @ColumnInfo(name = "netto")
    val netto: String,

    @ColumnInfo(name = "brutto")
    val brutto: String,

    // Photos & Metadata
    @ColumnInfo(name = "photos_json")
    val photosJson: String, // Up to 8 photo file paths

    @ColumnInfo(name = "key_photo_index")
    val keyPhotoIndex: Int = 0,

    @ColumnInfo(name = "is_verified")
    val isVerified: Boolean = true,

    @ColumnInfo(name = "edited_by_user")
    val editedByUser: Boolean = false,

    @ColumnInfo(name = "sync_status")
    val syncStatus: String = "LOCAL_ONLY", // LOCAL_ONLY, SYNCED_BACKEND

    // CSV Session Tracking & Cut-Off Metadata
    @ColumnInfo(name = "exported_at")
    val exportedAt: Long? = null, // Epoch ms when CSV was generated & shared

    @ColumnInfo(name = "export_batch_id")
    val exportBatchId: String? = null, // e.g. "EXPORT_20260827_120400"

    @ColumnInfo(name = "submitted_to_csv")
    val submittedToCsv: Boolean = false, // True once operator explicitly confirms receipt

    @ColumnInfo(name = "submitted_at")
    val submittedAt: Long? = null // Epoch ms when operator confirmed submission
)
