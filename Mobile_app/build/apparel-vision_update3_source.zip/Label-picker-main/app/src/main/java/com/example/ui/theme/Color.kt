package com.example.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// Exact Brand CSS Color Tokens
val LsCreme = Color(0xFFFBF6EC)        // app canvas
val LsLinen = Color(0xFFFFFDF9)        // card / chrome surface
val LsBeige100 = Color(0xFFF4EADA)    // inset, disabled field fill
val LsBeige300 = Color(0xFFE6D8C1)    // the one hairline border color

val LsCocoa900 = Color(0xFF2A1D14)    // primary text — 14:1 on creme
val LsCocoa600 = Color(0xFF6B5442)    // strong secondary text
val LsCocoa500 = Color(0xFF7D6650)    // muted text, secondary icons — 4.7:1 on creme

val LsGold800 = Color(0xFF86611F)     // accent text on light — 4.8:1 on creme
val LsGold600 = Color(0xFFA87C2E)     // accent hover
val LsGold500 = Color(0xFFBF9445)     // the brand gold, taken from the mark
val LsGold200 = Color(0xFFE9D3A5)     // gradient partner, gold hairlines
val LsGoldWash = Color(191, 148, 69, (255 * 0.14).toInt()) // rgba(191, 148, 69, 0.14)

// Studio Photo accents: wall-sign letters and desk panels
val LsNavy900 = Color(0xFF2B3454)     // OUTFIT lettering — 11.8:1 on creme
val LsNavy700 = Color(0xFF3A4667)     // the darker desk panel
val LsOchre600 = Color(0xFFC8860F)    // the ochre desk panel

// Warning & Attention accents
val LsRust700 = Color(0xFFB4531B)     // "Missing from scan" copy
val LsRust500 = Color(0xFFD2691E)     // warning glyph
val LsRust200 = Color(0xFFF0CBAF)     // warning field border
val LsRust50 = Color(0xFFFCEFE6)      // warning field fill

// Gradient Helpers
val GoldTitleGradient = Brush.horizontalGradient(
    listOf(LsGold500, LsGold600)
)

// Legacy Aliases for Seamless View Compatibility
val GoldStatusBand = LsGold800
val GoldTitleStart = LsGold500
val GoldTitleEnd = LsGold600
val GoldTextWash = LsGoldWash

val GoldAccent = LsGold500
val GoldDark = LsGold800
val GoldLightWash = LsGoldWash
val GoldCreme = LsCreme

val BrandScreenBackground = LsCreme

val NavyPrimary = LsNavy900
val NavySecondary = LsNavy700
val BlueAccent = LsGold500
val CyanAccent = LsGold600

val SlateSurface = LsCreme
val SlateCard = LsLinen
val SlateBorder = LsBeige300
val SlateTextPrimary = LsCocoa900
val SlateTextSecondary = LsCocoa600
val SlateDarkText = LsCocoa900
val SlateMediumText = LsCocoa600
val SlateMutedText = LsCocoa500
val SlateFieldBg = LsBeige100

// Status & Confidence Colors
val ConfidenceLowYellow = LsRust50
val ConfidenceLowBorder = LsRust200
val ConfidenceLowText = LsRust700

val ConfidenceHighGreen = Color(0xFFDCFCE7)
val ConfidenceHighBorder = Color(0xFF16A34A)
val ConfidenceHighText = Color(0xFF166534)

val StatusPending = LsBeige100
val StatusPendingText = LsGold800
val StatusSuccess = Color(0xFFDCFCE7)
val StatusSuccessText = Color(0xFF166534)
val StatusError = LsRust50
val StatusErrorText = LsRust700
