package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.ScanEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ScanDao {
    @Query("SELECT * FROM scans ORDER BY timestamp DESC")
    fun getAllScans(): Flow<List<ScanEntity>>

    @Query("SELECT * FROM scans WHERE status = 0 OR status = 3 ORDER BY timestamp DESC")
    fun getPendingAndFailedScans(): Flow<List<ScanEntity>>

    @Query("SELECT * FROM scans WHERE status = 1 ORDER BY timestamp DESC")
    fun getUnverifiedScans(): Flow<List<ScanEntity>>

    @Query("SELECT * FROM scans WHERE status = 0 OR (status = 3 AND server_stored = 0)")
    suspend fun getScansNeedingUpload(): List<ScanEntity>

    @Query("SELECT * FROM scans WHERE status = 0 AND server_stored = 1")
    suspend fun getScansNeedingPolling(): List<ScanEntity>

    @Query("SELECT * FROM scans WHERE apparel_id = :apparelId LIMIT 1")
    suspend fun getScanById(apparelId: String): ScanEntity?

    @Query("SELECT * FROM scans")
    suspend fun getAllScansSync(): List<ScanEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScan(scan: ScanEntity)

    @Update
    suspend fun updateScan(scan: ScanEntity)

    @Query("DELETE FROM scans WHERE apparel_id = :apparelId")
    suspend fun deleteScan(apparelId: String)

    @Query("DELETE FROM scans")
    suspend fun clearAllScans()
}
