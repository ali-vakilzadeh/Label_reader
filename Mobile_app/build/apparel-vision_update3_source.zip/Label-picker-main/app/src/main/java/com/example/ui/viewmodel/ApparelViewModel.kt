package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.DailyLedgerEntity
import com.example.data.local.entity.ScanEntity
import com.example.data.repository.ApparelRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ApparelViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ApparelRepository(application)
    val appSettings = repository.appSettings

    // Reactive database streams
    val pendingScans: StateFlow<List<ScanEntity>> = repository.getPendingAndFailedScans()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unverifiedScans: StateFlow<List<ScanEntity>> = repository.getUnverifiedScans()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeDailyLedger: StateFlow<List<DailyLedgerEntity>> = repository.getActiveDailyLedger()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLedgerHistory: StateFlow<List<DailyLedgerEntity>> = repository.getAllLedgerHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isServerReachable = repository.isServerReachable
    val isProcessingQueue = repository.isProcessingQueue
    val orphanedPhotoCount = repository.orphanedPhotoCount
    val orphanedPhotoBytes = repository.orphanedPhotoBytes

    // Capture Session State (Up to 8 photos)
    var activeBarcode by mutableStateOf("")
    val capturedPhotos = mutableStateListOf<File>()
    var selectedKeyPhotoIndex by mutableStateOf(0)
    var isTorchEnabled by mutableStateOf(false)
    var isSavingCapture by mutableStateOf(false)

    // Review & Edit Modal State
    var selectedScanForReview by mutableStateOf<ScanEntity?>(null)

    // UI Notices
    var toastMessage by mutableStateOf<String?>(null)
    var showConnectionAlertBanner by mutableStateOf(false)

    // CSV Export & Cut-Off Confirmation State
    var pendingExportBatchId by mutableStateOf<String?>(null)
    var showCsvCutoffConfirmDialog by mutableStateOf(false)
    var lastExportedItemCount by mutableStateOf(0)

    init {
        viewModelScope.launch {
            repository.isServerReachable.collect { reachable ->
                if (!reachable && !appSettings.demoModeEnabled) {
                    showConnectionAlertBanner = true
                } else {
                    showConnectionAlertBanner = false
                }
            }
        }
    }

    fun dismissConnectionAlert() {
        showConnectionAlertBanner = false
    }

    fun enableDemoModeFromBanner() {
        appSettings.demoModeEnabled = true
        appSettings.isDemoModeConfigured = true
        showConnectionAlertBanner = false
        toastMessage = "Demo Mode Activated. Local AI heuristics enabled."
    }

    fun setBarcode(barcode: String) {
        activeBarcode = barcode.trim()
    }

    fun addCapturedPhoto(file: File) {
        if (capturedPhotos.size < 8) {
            capturedPhotos.add(file)
            if (capturedPhotos.size == 1) {
                selectedKeyPhotoIndex = 0
            }
        } else {
            toastMessage = "Maximum 8 photos allowed per label session"
        }
    }

    fun removePhotoAt(index: Int) {
        if (index in capturedPhotos.indices) {
            val removed = capturedPhotos.removeAt(index)
            try {
                removed.delete()
            } catch (ignored: Exception) {}
            if (selectedKeyPhotoIndex >= capturedPhotos.size) {
                selectedKeyPhotoIndex = (capturedPhotos.size - 1).coerceAtLeast(0)
            }
        }
    }

    fun selectKeyPhoto(index: Int) {
        if (index in capturedPhotos.indices) {
            selectedKeyPhotoIndex = index
        }
    }

    fun toggleTorch() {
        isTorchEnabled = !isTorchEnabled
    }

    fun resetCaptureSession() {
        activeBarcode = ""
        capturedPhotos.clear()
        selectedKeyPhotoIndex = 0
        isTorchEnabled = false
    }

    /**
     * Guaranteed Lifecycle: Moves ephemeral capture session into Room database.
     */
    fun queueCurrentItemBatch(onSuccess: () -> Unit) {
        val barcode = activeBarcode.trim()
        if (barcode.isBlank()) {
            toastMessage = "Please scan or enter a garment barcode"
            return
        }

        if (capturedPhotos.isEmpty()) {
            toastMessage = "Please capture at least one care tag photo"
            return
        }

        isSavingCapture = true
        val photosSnapshot = capturedPhotos.toList()
        val keyIndex = selectedKeyPhotoIndex

        viewModelScope.launch {
            try {
                repository.createNewScanBatch(
                    apparelId = barcode,
                    photoFiles = photosSnapshot,
                    keyPhotoIndex = keyIndex
                )
                toastMessage = "Item $barcode queued for AI Extraction"
                resetCaptureSession()
                onSuccess()
            } catch (e: Exception) {
                toastMessage = "Failed to queue session: ${e.message}"
            } finally {
                isSavingCapture = false
            }
        }
    }

    fun triggerManualRetry(scan: ScanEntity) {
        viewModelScope.launch {
            toastMessage = "Submitting ${scan.apparelId} to Vision service..."
            repository.submitScanToMiddleware(scan)
        }
    }

    fun syncAllPending() {
        viewModelScope.launch {
            toastMessage = "Processing queue..."
            repository.triggerManualSyncAll()
        }
    }

    fun openReviewDialog(scan: ScanEntity) {
        selectedScanForReview = scan
    }

    fun dismissReviewDialog() {
        selectedScanForReview = null
    }

    fun confirmAndSaveVerifiedItem(
        scan: ScanEntity,
        category: String,
        subCategory: String,
        gender: String,
        season: String,
        brandName: String,
        country: String,
        size: String,
        color: String,
        material: String,
        price: String,
        netto: String,
        brutto: String
    ) {
        viewModelScope.launch {
            try {
                repository.confirmAndSaveLedger(
                    scan = scan,
                    verifiedCategory = category,
                    verifiedSubCategory = subCategory,
                    verifiedGender = gender,
                    verifiedSeason = season,
                    verifiedBrandName = brandName,
                    verifiedCountryOfOrigin = country,
                    verifiedSize = size,
                    verifiedColor = color,
                    verifiedMaterial = material,
                    verifiedOriginalPrice = price,
                    verifiedNetto = netto,
                    verifiedBrutto = brutto
                )
                selectedScanForReview = null
                toastMessage = "Saved ${scan.apparelId} to Daily Ledger"
            } catch (e: Exception) {
                toastMessage = "Save failed: ${e.message}"
            }
        }
    }

    fun deleteScan(apparelId: String) {
        viewModelScope.launch {
            repository.deleteScan(apparelId)
            toastMessage = "Removed $apparelId"
        }
    }

    fun deleteLedgerItem(apparelId: String) {
        viewModelScope.launch {
            repository.deleteLedgerItem(apparelId)
            toastMessage = "Deleted from ledger"
        }
    }

    fun duplicateLedgerItem(originalId: String, newId: String) {
        if (newId.isBlank()) {
            toastMessage = "Please enter target barcode"
            return
        }
        viewModelScope.launch {
            try {
                repository.duplicateLedgerItem(originalId, newId)
                toastMessage = "Created clone with barcode $newId"
            } catch (e: Exception) {
                toastMessage = "Duplication error: ${e.message}"
            }
        }
    }

    // Step 1: Export CSV and share without clearing DB
    fun shareCsvExport() {
        viewModelScope.launch {
            try {
                val activeItems = repository.getActiveDailyLedger()
                val (csvFile, batchId) = repository.generateCsvExportFile()
                pendingExportBatchId = batchId
                lastExportedItemCount = activeDailyLedger.value.size

                val context = getApplication<Application>()
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.fileprovider",
                    csvFile
                )

                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_SUBJECT, "Apparel Care Labels Export - ${csvFile.name}")
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }

                val chooser = Intent.createChooser(intent, "Export Apparel CSV").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(chooser)

                // Show confirmation prompt for moving session cut-off
                showCsvCutoffConfirmDialog = true
            } catch (e: Exception) {
                toastMessage = "CSV export error: ${e.message}"
            }
        }
    }

    // Step 2: Confirm delivery and advance session cut-off
    fun confirmCsvCutoff() {
        val batchId = pendingExportBatchId
        viewModelScope.launch {
            if (!batchId.isNullOrBlank()) {
                repository.confirmCsvCutOff(batchId)
            } else {
                repository.confirmAllActiveCsvCutOff()
            }
            showCsvCutoffConfirmDialog = false
            pendingExportBatchId = null
            toastMessage = "CSV cut-off confirmed. Session advanced."
        }
    }

    fun dismissCsvCutoffDialog() {
        showCsvCutoffConfirmDialog = false
        toastMessage = "Records kept in active session."
    }

    fun cleanOrphanedPhotos() {
        viewModelScope.launch {
            val count = repository.cleanOrphanedPhotos()
            toastMessage = "Cleaned $count unused photos from storage"
        }
    }

    fun purgeAllDataAndPhotos() {
        viewModelScope.launch {
            repository.purgeAllDataAndPhotos()
            resetCaptureSession()
            toastMessage = "All database records and photo cache cleared"
        }
    }

    fun getPhotoPaths(json: String?): List<String> = repository.getPhotoPaths(json)
    fun getConfidences(json: String?): Map<String, Float> = repository.getConfidences(json)
}
