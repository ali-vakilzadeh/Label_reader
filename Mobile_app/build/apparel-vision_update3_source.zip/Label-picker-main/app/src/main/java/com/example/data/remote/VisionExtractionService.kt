package com.example.data.remote

import android.content.Context
import android.util.Log
import com.example.data.local.entity.ScanEntity
import com.example.data.preferences.AppSettings
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.io.File
import java.util.concurrent.TimeUnit

class VisionExtractionService(private val context: Context) {
    private val appSettings = AppSettings.getInstance(context)
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun getRetrofit(baseUrl: String): Retrofit {
        val sanitized = if (!baseUrl.endsWith("/")) "$baseUrl/" else baseUrl
        return Retrofit.Builder()
            .baseUrl(sanitized)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
    }

    private fun getApi(): MiddlewareApiService {
        return getRetrofit(appSettings.serverUrl).create(MiddlewareApiService::class.java)
    }

    private suspend fun getAuthToken(): String? {
        val cached = appSettings.sessionToken
        if (!cached.isNullOrBlank()) return cached

        return try {
            val api = getApi()
            val res = api.login(
                LoginRequest(
                    username = appSettings.userId,
                    password = appSettings.devicePassword
                )
            )
            if (res.isSuccessful && res.body()?.status == "success" && !res.body()?.token.isNullOrBlank()) {
                val token = res.body()?.token!!
                appSettings.sessionToken = token
                token
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Device auth handshake unavailable: ${e.message}")
            null
        }
    }

    suspend fun checkHealth(): Result<HealthResponse> = withContext(Dispatchers.IO) {
        try {
            val api = getApi()
            val res = api.checkHealth()
            if (res.isSuccessful && res.body() != null) {
                Result.success(res.body()!!)
            } else {
                Result.failure(Exception("Health check returned HTTP ${res.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun submitVisionExtract(
        scan: ScanEntity,
        imageFiles: List<File>,
        clonedFrom: String? = null
    ): Result<AsyncVisionResponse> = withContext(Dispatchers.IO) {
        val token = getAuthToken()
        if (token.isNullOrBlank()) {
            return@withContext Result.failure(Exception("AUTH_REQUIRED: Invalid device credentials or server unreachable"))
        }

        try {
            val api = getApi()
            val textPlain = "text/plain".toMediaTypeOrNull()
            val apparelIdBody = scan.apparelId.toRequestBody(textPlain)
            val usernameBody = appSettings.userId.toRequestBody(textPlain)
            val keyPhotoBody = scan.keyPhotoIndex.toString().toRequestBody(textPlain)
            val clonedFromBody = clonedFrom?.toRequestBody(textPlain)

            val imageParts = imageFiles.filter { it.exists() }.take(8).mapIndexed { index, file ->
                val requestFile = file.asRequestBody("image/jpeg".toMediaTypeOrNull())
                MultipartBody.Part.createFormData("images", file.name, requestFile)
            }

            val response = api.submitVisionExtract(
                authorization = "Bearer $token",
                apparelId = apparelIdBody,
                username = usernameBody,
                keyPhotoIndex = keyPhotoBody,
                clonedFrom = clonedFromBody,
                images = imageParts
            )

            if (response.code() in 200..299 && response.body() != null) {
                // Storage invariant: 2xx response guarantees server has stored the scan
                Result.success(response.body()!!)
            } else {
                val errorCode = response.code()
                val errorBody = response.errorBody()?.string() ?: ""
                val msg = "HTTP $errorCode: $errorBody"
                Result.failure(Exception(msg))
            }
        } catch (e: Exception) {
            Log.w(TAG, "submitVisionExtract transport error: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun getBatchVisionResults(apparelIds: List<String>): Result<BatchVisionResultsResponse> = withContext(Dispatchers.IO) {
        if (apparelIds.isEmpty()) {
            return@withContext Result.success(BatchVisionResultsResponse(status = "success"))
        }

        val token = getAuthToken()
        if (token.isNullOrBlank()) {
            return@withContext Result.failure(Exception("AUTH_REQUIRED: Invalid session token"))
        }

        try {
            val api = getApi()
            val idsQuery = apparelIds.take(100).joinToString(",")
            val response = api.getBatchVisionResults(
                authorization = "Bearer $token",
                idsCommaSeparated = idsQuery
            )

            if (response.isSuccessful && response.body() != null) {
                Result.success(response.body()!!)
            } else {
                Result.failure(Exception("Batch fetch error HTTP ${response.code()}"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun generateLocalSyntheticExtraction(barcode: String): VisionExtraction {
        return VisionExtraction(
            brandName = VisionField(value = "Zara Man", confidence = 0.94f),
            category = VisionField(value = "Shirt", confidence = 0.91f),
            subCategory = VisionField(value = "Formal Shirt", confidence = 0.88f),
            gender = VisionField(value = "Men", confidence = 0.90f),
            season = VisionField(value = "SS26", confidence = 0.85f),
            size = VisionField(value = "L (42)", confidence = 0.92f),
            color = VisionField(value = "Navy Blue", confidence = 0.89f),
            material = VisionField(value = "100% Cotton", confidence = 0.86f),
            countryOfOrigin = VisionField(value = "Portugal", confidence = 0.82f),
            originalPrice = VisionField(value = "79.90 EUR", confidence = 0.80f),
            netto = VisionField(value = "0.280 KG", confidence = 0.75f),
            brutto = VisionField(value = "0.320 KG", confidence = 0.75f)
        )
    }

    companion object {
        private const val TAG = "VisionExtractionService"
    }
}
