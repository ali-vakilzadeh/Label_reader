package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.local.entity.DailyLedgerEntity
import com.example.ui.theme.LsBeige100
import com.example.ui.theme.LsBeige300
import com.example.ui.theme.LsCocoa500
import com.example.ui.theme.LsCocoa600
import com.example.ui.theme.LsCocoa900
import com.example.ui.theme.LsCreme
import com.example.ui.theme.LsGold200
import com.example.ui.theme.LsGold500
import com.example.ui.theme.LsGold600
import com.example.ui.theme.LsGold800
import com.example.ui.theme.LsGoldWash
import com.example.ui.theme.LsLinen
import com.example.ui.theme.LsRust200
import com.example.ui.theme.LsRust50
import com.example.ui.theme.LsRust500
import com.example.ui.theme.LsRust700
import com.example.ui.viewmodel.ApparelViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DailyLedgerScreen(
    viewModel: ApparelViewModel
) {
    val activeLedger by viewModel.activeDailyLedger.collectAsStateWithLifecycle()
    val allLedgerHistory by viewModel.allLedgerHistory.collectAsStateWithLifecycle()

    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0 = Active Daily Session, 1 = Archive / All History
    var cloneItemTarget by remember { mutableStateOf<DailyLedgerEntity?>(null) }
    var cloneTargetBarcode by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(LsCreme)
            .testTag("daily_ledger_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar
            Surface(
                color = LsGold800,
                modifier = Modifier.fillMaxWidth(),
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "PRODUCTION AUDIT",
                            color = LsGold200,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Verified Daily Ledger",
                            color = LsLinen,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { viewModel.shareCsvExport() },
                            enabled = activeLedger.isNotEmpty(),
                            colors = ButtonDefaults.buttonColors(containerColor = LsGold500),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("export_csv_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = LsCocoa900, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Export CSV", color = LsCocoa900, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Tab Bar
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = LsLinen,
                contentColor = LsGold800,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = LsGold800,
                        height = 3.dp
                    )
                }
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = {
                        Text(
                            text = "Active Session (${activeLedger.size})",
                            fontSize = 13.sp,
                            fontWeight = if (selectedTabIndex == 0) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTabIndex == 0) LsGold800 else LsCocoa600
                        )
                    }
                )

                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = {
                        Text(
                            text = "All History Archive (${allLedgerHistory.size})",
                            fontSize = 13.sp,
                            fontWeight = if (selectedTabIndex == 1) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTabIndex == 1) LsGold800 else LsCocoa600
                        )
                    }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Display List
            val displayItems = if (selectedTabIndex == 0) activeLedger else allLedgerHistory

            if (displayItems.isEmpty()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = LsLinen),
                    border = BorderStroke(1.dp, LsBeige300)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = if (selectedTabIndex == 0) Icons.Default.ListAlt else Icons.Default.History,
                            contentDescription = null,
                            tint = LsGold500,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (selectedTabIndex == 0) "No Active Ledger Records" else "History is Empty",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = LsCocoa900
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (selectedTabIndex == 0) "Confirm items on the Review screen to populate the active daily session." else "Previously exported sessions will be cataloged here.",
                            fontSize = 12.sp,
                            color = LsCocoa600,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(displayItems, key = { it.apparelId }) { item ->
                        LedgerItemCard(
                            item = item,
                            viewModel = viewModel,
                            onDuplicate = {
                                cloneItemTarget = item
                                cloneTargetBarcode = ""
                            },
                            onDelete = { viewModel.deleteLedgerItem(item.apparelId) }
                        )
                    }
                }
            }
        }

        // Two-Step CSV Confirmation Dialog (Session Cut-Off)
        if (viewModel.showCsvCutoffConfirmDialog) {
            AlertDialog(
                onDismissRequest = { viewModel.dismissCsvCutoffDialog() },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = LsGold800, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Confirm CSV Delivery & Cut-Off", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = LsCocoa900)
                    }
                },
                text = {
                    Column {
                        Text(
                            text = "Have all ${viewModel.lastExportedItemCount} exported items been successfully received or saved?",
                            color = LsCocoa900,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Confirming will record the export timestamp in SQLite and advance the active daily session to a clean slate. No items are deleted.",
                            color = LsCocoa600,
                            fontSize = 12.sp
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = { viewModel.confirmCsvCutoff() },
                        colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Confirm Cut-Off", color = LsLinen, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    Button(
                        onClick = { viewModel.dismissCsvCutoffDialog() },
                        colors = ButtonDefaults.buttonColors(containerColor = LsBeige100),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Keep in Active Session", color = LsCocoa900)
                    }
                },
                containerColor = LsLinen,
                shape = RoundedCornerShape(14.dp)
            )
        }

        // Duplicate Clone Dialog
        cloneItemTarget?.let { item ->
            AlertDialog(
                onDismissRequest = { cloneItemTarget = null },
                title = { Text("Clone Item Attributes", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = LsCocoa900) },
                text = {
                    Column {
                        Text("Duplicate '${item.apparelId}' values to a new barcode:", color = LsCocoa600, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = cloneTargetBarcode,
                            onValueChange = { cloneTargetBarcode = it },
                            label = { Text("New Garment Barcode", color = LsCocoa600) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = LsGold500,
                                unfocusedBorderColor = LsBeige300,
                                focusedTextColor = LsCocoa900,
                                unfocusedTextColor = LsCocoa900
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.duplicateLedgerItem(item.apparelId, cloneTargetBarcode)
                            cloneItemTarget = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LsGold800),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Duplicate", color = LsLinen, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    Button(
                        onClick = { cloneItemTarget = null },
                        colors = ButtonDefaults.buttonColors(containerColor = LsBeige100),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Cancel", color = LsCocoa900)
                    }
                },
                containerColor = LsLinen,
                shape = RoundedCornerShape(14.dp)
            )
        }
    }
}

@Composable
fun LedgerItemCard(
    item: DailyLedgerEntity,
    viewModel: ApparelViewModel,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    val context = LocalContext.current
    val photoPaths = viewModel.getPhotoPaths(item.photosJson)
    val keyPhotoFile = if (photoPaths.isNotEmpty()) {
        File(photoPaths.getOrElse(item.keyPhotoIndex.coerceIn(0, photoPaths.lastIndex)) { photoPaths.first() })
    } else null

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ledger_card_${item.apparelId}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = LsLinen),
        border = BorderStroke(1.dp, LsBeige300)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(LsBeige100)
            ) {
                if (keyPhotoFile != null && keyPhotoFile.exists()) {
                    AsyncImage(
                        model = ImageRequest.Builder(context)
                            .data(keyPhotoFile)
                            .crossfade(true)
                            .build(),
                        contentDescription = "Ledger Photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.ListAlt,
                        contentDescription = null,
                        tint = LsCocoa500,
                        modifier = Modifier
                            .size(24.dp)
                            .align(Alignment.Center)
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.apparelId,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = LsCocoa900
                    )

                    Surface(
                        color = if (item.submittedToCsv) LsBeige100 else Color(0xFFDCFCE7),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = if (item.submittedToCsv) "SUBMITTED CSV" else "ACTIVE",
                            color = if (item.submittedToCsv) LsCocoa600 else Color(0xFF166534),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "${item.brandName} • ${item.category} (${item.subCategory})",
                    fontSize = 12.sp,
                    color = LsCocoa600,
                    fontWeight = FontWeight.Medium
                )

                Text(
                    text = "Size: ${item.size} | ${item.color} | ${item.originalPrice} | ${item.material}",
                    fontSize = 11.sp,
                    color = LsCocoa500
                )

                if (item.exportedAt != null) {
                    val exportTime = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(item.exportedAt))
                    Text(
                        text = "Batch: ${item.exportBatchId ?: "Exported"} @ $exportTime",
                        fontSize = 10.sp,
                        color = LsGold800
                    )
                }
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Actions
            IconButton(onClick = onDuplicate) {
                Icon(Icons.Default.ContentCopy, contentDescription = "Clone item", tint = LsGold800, modifier = Modifier.size(18.dp))
            }

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete item", tint = LsRust500, modifier = Modifier.size(18.dp))
            }
        }
    }
}
