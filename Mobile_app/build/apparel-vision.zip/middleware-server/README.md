# Apparel Vision Middleware Server

Enterprise Node.js/Express server interfacing between up to 10 Android devices and Google Gemini Vision AI.

## Quick Start

1. Install dependencies:
```bash
npm install
```

2. Configure environment variables in `.env`:
```env
PORT=3000
DEVICE_MASTER_PASSWORD=enterprise2026
JWT_SECRET=your-enterprise-jwt-secret
GEMINI_API_KEY=your_gemini_api_key_here
```

3. Run server:
```bash
npm start
```

## API Specification

### 1. Authenticate Device
* **Route:** `POST /api/v1/auth/login`
* **Body:**
```json
{
  "password": "enterprise2026",
  "user_id": "operator_01"
}
```
* **Response:**
```json
{
  "success": true,
  "token": "eyJhbGciOi...",
  "message": "Device authenticated successfully"
}
```

### 2. Extract Apparel Labels
* **Route:** `POST /api/v1/vision/extract`
* **Headers:** `Authorization: Bearer <token>`
* **Body:** Multipart form with up to 8 images (`images`), `apparel_id`, `username`
* **Response:** Structured JSON with field values and confidence scores (0.0-1.0).
