package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.ScanEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ScanDao {
    @Query("SELECT * FROM scans ORDER BY apparel_id DESC")
    fun getAllScansFlow(): Flow<List<ScanEntity>>

    @Query("SELECT * FROM scans WHERE status != 'COMPLETED' ORDER BY apparel_id DESC")
    fun getActivePendingScansFlow(): Flow<List<ScanEntity>>

    @Query("SELECT * FROM scans WHERE status = 'PENDING_VISION' ORDER BY id ASC")
    suspend fun getPendingVisionScans(): List<ScanEntity>

    @Query("SELECT * FROM scans WHERE id = :id LIMIT 1")
    suspend fun getScanById(id: Int): ScanEntity?

    @Query("SELECT * FROM scans WHERE apparel_id = :apparelId LIMIT 1")
    suspend fun getScanByApparelId(apparelId: String): ScanEntity?

    @Query("SELECT apparel_id FROM scans ORDER BY id DESC LIMIT 1")
    suspend fun getLatestApparelId(): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScan(scan: ScanEntity): Long

    @Update
    suspend fun updateScan(scan: ScanEntity)

    @Delete
    suspend fun deleteScan(scan: ScanEntity)

    @Query("DELETE FROM scans WHERE id = :id")
    suspend fun deleteScanById(id: Int)

    @Query("DELETE FROM scans")
    suspend fun deleteAllScans()
}
