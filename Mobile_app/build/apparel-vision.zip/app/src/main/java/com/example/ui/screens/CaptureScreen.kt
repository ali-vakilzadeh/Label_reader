package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.ImageCapture
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.ui.components.CameraPreviewView
import com.example.ui.components.takePhoto
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.viewmodel.ApparelViewModel
import java.io.File

@Composable
fun CaptureScreen(
    viewModel: ApparelViewModel,
    onNavigateToReview: () -> Unit
) {
    val context = LocalContext.current
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    val imageCapture = remember {
        ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .build()
    }

    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()
    val activeBarcode = viewModel.activeBarcode
    val isBarcodePhase = activeBarcode == null
    val capturedCount = viewModel.capturedPhotos.size

    var isCapturingEffect by remember { mutableStateOf(false) }
    var showManualBarcodeDialog by remember { mutableStateOf(false) }
    var manualBarcodeInput by remember { mutableStateOf("") }

    // Barcode detection feedback
    fun onBarcodeScanned(barcode: String) {
        if (barcode.isNotBlank() && viewModel.activeBarcode == null) {
            try {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createOneShot(100, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(100)
                }
            } catch (ignored: Exception) {}

            viewModel.setScannedBarcode(barcode)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("screen_capture")
    ) {
        if (hasCameraPermission) {
            CameraPreviewView(
                modifier = Modifier.fillMaxSize(),
                isTorchEnabled = viewModel.isTorchEnabled,
                imageCapture = imageCapture,
                isBarcodeMode = isBarcodePhase,
                onBarcodeDetected = { barcode ->
                    if (isBarcodePhase) {
                        onBarcodeScanned(barcode)
                    }
                }
            )
        } else {
            // Permission placeholder
            Box(
                modifier = Modifier
                    .fillMaxSize()
                .background(Color(0xFF1E293B)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PhotoCamera,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Camera Permission Required",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Apparel Vision requires camera access for ML Kit barcode scanning and label photo captures.",
                        color = Color(0xFF94A3B8),
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                        colors = ButtonDefaults.buttonColors(containerColor = BlueAccent)
                    ) {
                        Text("Grant Permission")
                    }
                }
            }
        }

        // Tag Alignment Viewfinder Frame (Photo Capture Phase)
        if (!isBarcodePhase) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(width = 300.dp, height = 360.dp)
                    .border(
                        width = 2.dp,
                        color = Color.White.copy(alpha = 0.6f),
                        shape = RoundedCornerShape(16.dp)
                    )
            ) {
                Text(
                    text = "Center Apparel Tag / Label",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 12.dp)
                        .background(Color.Black.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }

        // Flash capture effect animation
        AnimatedVisibility(
            visible = isCapturingEffect,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White.copy(alpha = 0.8f))
            )
        }

        // Top Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Workflow Status Pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Black.copy(alpha = 0.75f),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isBarcodePhase) Color(0xFF38BDF8) else Color(0xFF4ADE80)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isBarcodePhase) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = null,
                                tint = Color(0xFF38BDF8),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Step 1: Scan Barcode",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF4ADE80))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Item #$activeBarcode",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "($capturedCount/8 photos)",
                                color = Color(0xFFCBD5E1),
                                fontSize = 12.sp
                            )
                        }
                    }
                }

                // Action icons (Reset barcode if locked, Torch Toggle)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (!isBarcodePhase) {
                        IconButton(
                            onClick = { viewModel.resetBarcodePhase() },
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .background(Color.Black.copy(alpha = 0.65f), CircleShape)
                                .testTag("button_reset_barcode")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Re-scan Barcode",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Torch Toggle
                    IconButton(
                        onClick = { viewModel.isTorchEnabled = !viewModel.isTorchEnabled },
                        modifier = Modifier
                            .background(Color.Black.copy(alpha = 0.65f), CircleShape)
                            .testTag("button_torch_toggle")
                    ) {
                        Icon(
                            imageVector = if (viewModel.isTorchEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                            contentDescription = "Toggle Torch",
                            tint = if (viewModel.isTorchEnabled) Color(0xFFFACC15) else Color.White
                        )
                    }
                }
            }
        }

        // Bottom Controls
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f), Color.Black)
                    )
                )
                .navigationBarsPadding()
                .padding(bottom = 12.dp)
        ) {
            if (isBarcodePhase) {
                // PHASE 1: Barcode Scan Prompt & Manual Barcode Entry
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Point camera at inventory barcode (apparel_id)",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showManualBarcodeDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("button_manual_barcode"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.5f))
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Type Barcode")
                        }

                        Button(
                            onClick = {
                                val demoBarcode = if (viewModel.appSettings.demoModeEnabled) {
                                    viewModel.appSettings.getNextDemoId()
                                } else {
                                    "BAR-${(100000..999999).random()}"
                                }
                                onBarcodeScanned(demoBarcode)
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("button_demo_barcode"),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (viewModel.appSettings.demoModeEnabled) Color(0xFFD97706) else BlueAccent
                            )
                        ) {
                            Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (viewModel.appSettings.demoModeEnabled) "Gen Demo ID" else "Demo Barcode")
                        }
                    }
                }
            } else {
                // PHASE 2: Photo Capture Strip & Shutter
                // Captured Photos Thumbnail Strip (up to 8)
                if (capturedCount > 0) {
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        itemsIndexed(viewModel.capturedPhotos) { index, photoFile ->
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(1.5.dp, Color.White, RoundedCornerShape(8.dp))
                            ) {
                                AsyncImage(
                                    model = photoFile,
                                    contentDescription = "Photo ${index + 1}",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                // Delete photo overlay
                                IconButton(
                                    onClick = { viewModel.removeCapturedPhoto(index) },
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .size(22.dp)
                                        .background(Color.Black.copy(alpha = 0.7f), CircleShape)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Remove photo",
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                                // Index badge
                                Text(
                                    text = "${index + 1}",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .align(Alignment.BottomStart)
                                        .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(topEnd = 4.dp))
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }
                }

                // Main Actions Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Quick Test / Demo Sample Tag Button
                    IconButton(
                        onClick = {
                            if (capturedCount < 8) {
                                viewModel.createSampleLabelPhoto(context)
                                Toast.makeText(context, "Sample Tag Photo Added ($capturedCount/8)", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Max 8 photos reached", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .background(Color.White.copy(alpha = 0.2f), CircleShape)
                            .testTag("button_sample_capture")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = "Add Demo Sample Label",
                            tint = Color.White
                        )
                    }

                    // Big Shutter Button
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .padding(6.dp)
                            .clickable(enabled = capturedCount < 8 && !isProcessing) {
                                if (hasCameraPermission) {
                                    val nextIndex = capturedCount + 1
                                    val fileName = "IMG_${activeBarcode}_$nextIndex.jpg"
                                    val targetFile = File(context.filesDir, fileName)

                                    isCapturingEffect = true
                                    takePhoto(
                                        context = context,
                                        imageCapture = imageCapture,
                                        outputFile = targetFile,
                                        onSuccess = { file ->
                                            isCapturingEffect = false
                                            viewModel.addCapturedPhoto(file)
                                        },
                                        onError = {
                                            isCapturingEffect = false
                                            viewModel.createSampleLabelPhoto(context)
                                        }
                                    )
                                } else {
                                    viewModel.createSampleLabelPhoto(context)
                                }
                            }
                            .testTag("button_shutter"),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(if (capturedCount >= 8) Color.Gray else NavyPrimary)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhotoCamera,
                                contentDescription = "Capture Tag Photo",
                                tint = Color.White,
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .size(34.dp)
                                )
                        }
                    }

                    // Queue Item / Complete Batch Button
                    Button(
                        onClick = {
                            viewModel.queueCurrentItemBatch {
                                onNavigateToReview()
                            }
                        },
                        enabled = capturedCount > 0 && !isProcessing,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = BlueAccent,
                            disabledContainerColor = Color.White.copy(alpha = 0.2f)
                        ),
                        shape = RoundedCornerShape(24.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                        modifier = Modifier.testTag("button_queue_item")
                    ) {
                        if (isProcessing) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Finish Item", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    // Manual Barcode Entry Dialog
    if (showManualBarcodeDialog) {
        AlertDialog(
            onDismissRequest = { showManualBarcodeDialog = false },
            title = { Text("Enter Inventory Barcode") },
            text = {
                Column {
                    Text("Type the apparel item's barcode or SKU identifier:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = manualBarcodeInput,
                        onValueChange = { manualBarcodeInput = it },
                        singleLine = true,
                        placeholder = { Text("e.g. BAR-849204") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (manualBarcodeInput.isNotBlank()) {
                            onBarcodeScanned(manualBarcodeInput.trim())
                            showManualBarcodeDialog = false
                            manualBarcodeInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary)
                ) {
                    Text("Lock Barcode")
                }
            },
            dismissButton = {
                TextButton(onClick = { showManualBarcodeDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
