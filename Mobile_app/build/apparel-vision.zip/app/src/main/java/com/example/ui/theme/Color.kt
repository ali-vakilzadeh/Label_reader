package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Enterprise Modern Theme Colors
val NavyPrimary = Color(0xFF0F2B48)
val NavySecondary = Color(0xFF1E3A5F)
val BlueAccent = Color(0xFF0077CC)
val CyanAccent = Color(0xFF00B4D8)

val SlateSurface = Color(0xFFF4F7FB)
val SlateCard = Color(0xFFFFFFFF)
val SlateBorder = Color(0xFFE2E8F0)
val SlateTextPrimary = Color(0xFF0F172A)
val SlateTextSecondary = Color(0xFF64748B)

// Status & Confidence Colors
val ConfidenceLowYellow = Color(0xFFFFF9C4)
val ConfidenceLowBorder = Color(0xFFFBC02D)
val ConfidenceLowText = Color(0xFF7A5900)

val ConfidenceHighGreen = Color(0xFFE8F5E9)
val ConfidenceHighBorder = Color(0xFF4CAF50)
val ConfidenceHighText = Color(0xFF1B5E20)

val StatusPending = Color(0xFFE0E7FF)
val StatusPendingText = Color(0xFF3730A3)
val StatusSuccess = Color(0xFFDCFCE7)
val StatusSuccessText = Color(0xFF166534)
val StatusError = Color(0xFFFEE2E2)
val StatusErrorText = Color(0xFF991B1B)

