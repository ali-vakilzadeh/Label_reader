package com.example.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_ledger")
data class DailyLedgerEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    
    @ColumnInfo(name = "apparel_id")
    val apparelId: String,

    @ColumnInfo(name = "parent_item_id")
    val parentItemId: String? = null,
    
    @ColumnInfo(name = "username")
    val username: String,
    
    @ColumnInfo(name = "timestamp")
    val timestamp: String,
    
    @ColumnInfo(name = "category")
    val category: String,
    
    @ColumnInfo(name = "sub_category")
    val subCategory: String,
    
    @ColumnInfo(name = "gender")
    val gender: String,
    
    @ColumnInfo(name = "season")
    val season: String,
    
    @ColumnInfo(name = "netto")
    val netto: String,
    
    @ColumnInfo(name = "brutto")
    val brutto: String,
    
    @ColumnInfo(name = "brand_name")
    val brandName: String,
    
    @ColumnInfo(name = "country_of_origin")
    val countryOfOrigin: String,
    
    @ColumnInfo(name = "size")
    val size: String,
    
    @ColumnInfo(name = "color")
    val color: String,
    
    @ColumnInfo(name = "material")
    val material: String,
    
    @ColumnInfo(name = "original_price")
    val originalPrice: String,
    
    @ColumnInfo(name = "image_files")
    val imageFiles: String,
    
    @ColumnInfo(name = "is_demo_record")
    val isDemoRecord: Boolean = false,

    @ColumnInfo(name = "is_cleared_from_active_view")
    val isClearedFromActiveView: Boolean = false,
    
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toCsvRow(): String {
        return listOf(
            escapeCsv(apparelId),
            escapeCsv(parentItemId ?: ""),
            escapeCsv(username),
            escapeCsv(timestamp),
            escapeCsv(category),
            escapeCsv(subCategory),
            escapeCsv(gender),
            escapeCsv(season),
            escapeCsv(netto),
            escapeCsv(brutto),
            escapeCsv(brandName),
            escapeCsv(countryOfOrigin),
            escapeCsv(size),
            escapeCsv(color),
            escapeCsv(material),
            escapeCsv(originalPrice),
            escapeCsv(if (isDemoRecord) "DEMO" else "REAL"),
            escapeCsv(imageFiles)
        ).joinToString(",")
    }

    private fun escapeCsv(value: String): String {
        val clean = value.replace("\"", "\"\"")
        return if (clean.contains(",") || clean.contains("\"") || clean.contains("\n")) {
            "\"$clean\""
        } else {
            clean
        }
    }

    companion object {
        const val CSV_HEADER = "apparel_id,parent_item_id,username,timestamp,category,sub-category,gender,season,netto,brutto,brand_name,country_of_origin,size,color,material,original_price,record_type,image_files"
    }
}
