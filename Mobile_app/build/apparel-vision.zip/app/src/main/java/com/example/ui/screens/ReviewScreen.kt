package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.local.entity.ScanEntity
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.ConfidenceLowBorder
import com.example.ui.theme.ConfidenceLowText
import com.example.ui.theme.ConfidenceLowYellow
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateCard
import com.example.ui.theme.SlateSurface
import com.example.ui.theme.SlateTextSecondary
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusErrorText
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusPendingText
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusSuccessText
import com.example.ui.viewmodel.ApparelViewModel
import java.io.File

@Composable
fun ReviewScreen(
    viewModel: ApparelViewModel,
    onNavigateToCapture: () -> Unit
) {
    val context = LocalContext.current
    val pendingScans by viewModel.pendingScans.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessing.collectAsStateWithLifecycle()

    val pendingVisionCount = pendingScans.count { it.status == ScanEntity.STATUS_PENDING_VISION }
    val readyForReviewCount = pendingScans.count { it.status == ScanEntity.STATUS_READY_FOR_REVIEW }
    val extractingCount = pendingScans.count { it.status == ScanEntity.STATUS_EXTRACTING }

    val selectedScan = viewModel.selectedScanForReview

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SlateSurface)
            .testTag("screen_review")
    ) {
        // Top Header
        Surface(
            color = NavyPrimary,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Review & Verification",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Text(
                            text = "${pendingScans.size} pending items in queue",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color(0xFFCBD5E1)
                            )
                        )
                    }

                    // Auto-sync status indicator
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (viewModel.appSettings.autoSyncAiVision) Color(0xFF1E3A5F) else Color(0xFF334155)
                    ) {
                        Text(
                            text = if (viewModel.appSettings.autoSyncAiVision) "Auto-Sync ON" else "Auto-Sync OFF",
                            color = Color(0xFF93C5FD),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                // Launch AI Vision Button (if items are pending)
                if (pendingVisionCount > 0) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.launchAiVisionBatch() },
                        enabled = !isProcessing,
                        colors = ButtonDefaults.buttonColors(containerColor = BlueAccent),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("button_launch_ai_vision")
                    ) {
                        if (isProcessing) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Extracting with Gemini AI...")
                        } else {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Launch AI Vision ($pendingVisionCount items)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // List of Pending Batches
        if (pendingScans.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFE2E8F0),
                        modifier = Modifier.size(72.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF64748B),
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No Pending Scans",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Capture apparel labels to queue items for automated Gemini extraction.",
                        color = SlateTextSecondary,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = onNavigateToCapture,
                        colors = ButtonDefaults.buttonColors(containerColor = NavyPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Open Camera Capture")
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(pendingScans, key = { it.id }) { scan ->
                    PendingScanCard(
                        scan = scan,
                        onCardClick = {
                            if (scan.status == ScanEntity.STATUS_READY_FOR_REVIEW || scan.status == ScanEntity.STATUS_PENDING_VISION) {
                                viewModel.selectedScanForReview = scan
                            }
                        },
                        onTriggerAI = {
                            viewModel.processSingleScan(scan.id)
                        }
                    )
                }
            }
        }
    }

    // Floating Edit / Verification Modal
    if (selectedScan != null) {
        ReviewDetailDialog(
            scan = selectedScan,
            isProcessing = isProcessing,
            onDismiss = { viewModel.selectedScanForReview = null },
            onConfirmAndSave = { category, subCategory, gender, season, brand, origin, size, color, material, price, netto, brutto ->
                viewModel.confirmAndSaveVerifiedScan(
                    scanId = selectedScan.id,
                    category = category,
                    subCategory = subCategory,
                    gender = gender,
                    season = season,
                    brandName = brand,
                    countryOfOrigin = origin,
                    size = size,
                    color = color,
                    material = material,
                    originalPrice = price,
                    netto = netto,
                    brutto = brutto
                )
            },
            onDeleteScan = { scanId ->
                viewModel.deleteScan(scanId)
            }
        )
    }
}

@Composable
fun PendingScanCard(
    scan: ScanEntity,
    onCardClick: () -> Unit,
    onTriggerAI: () -> Unit
) {
    val context = LocalContext.current
    val imageList = scan.getImageList()
    val firstImageFile = imageList.firstOrNull()?.let { name ->
        if (File(name).isAbsolute) File(name) else File(context.filesDir, name)
    }

    val isReady = scan.status == ScanEntity.STATUS_READY_FOR_REVIEW
    val isExtracting = scan.status == ScanEntity.STATUS_EXTRACTING
    val isPendingVision = scan.status == ScanEntity.STATUS_PENDING_VISION
    val isFailed = scan.status == ScanEntity.STATUS_FAILED

    val lowConfCount = scan.lowConfidenceCount()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(enabled = !isExtracting) { onCardClick() }
            .testTag("card_scan_${scan.apparelId}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SlateCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFE2E8F0))
            ) {
                if (firstImageFile != null && firstImageFile.exists()) {
                    AsyncImage(
                        model = firstImageFile,
                        contentDescription = "Scan #${scan.apparelId}",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.HourglassEmpty,
                        contentDescription = null,
                        tint = Color.Gray,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(28.dp)
                    )
                }

                // Photo Count Pill
                Text(
                    text = "${imageList.size} pics",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .background(Color.Black.copy(alpha = 0.75f), RoundedCornerShape(topStart = 4.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Info Column
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Item #${scan.apparelId}",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (scan.isDemoRecord || scan.apparelId.startsWith("demo_")) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = Color(0xFFFEF3C7)
                            ) {
                                Text(
                                    text = "DEMO",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFB45309),
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                )
                            }
                        }
                    }

                    // Status Badge
                    when {
                        isReady -> {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = StatusSuccess
                            ) {
                                Text(
                                    text = "Ready to Review",
                                    color = StatusSuccessText,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        isExtracting -> {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = StatusPending
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CircularProgressIndicator(
                                        color = StatusPendingText,
                                        modifier = Modifier.size(10.dp),
                                        strokeWidth = 1.5.dp
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Extracting...",
                                        color = StatusPendingText,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                        isFailed -> {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = StatusError
                            ) {
                                Text(
                                    text = "Failed",
                                    color = StatusErrorText,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                        else -> {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color(0xFFF1F5F9)
                            ) {
                                Text(
                                    text = "Pending Vision",
                                    color = Color(0xFF475569),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                if (isReady && scan.brandName.isNotBlank()) {
                    Text(
                        text = "${scan.brandName} • ${scan.category.replaceFirstChar { it.uppercase() }}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.primary
                    )
                } else {
                    Text(
                        text = "Captured: ${scan.timestamp}",
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateTextSecondary
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Low Confidence Warning Badge
                if (isReady && lowConfCount > 0) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = ConfidenceLowYellow,
                        border = androidx.compose.foundation.BorderStroke(1.dp, ConfidenceLowBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = ConfidenceLowText,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "$lowConfCount field(s) require verification",
                                color = ConfidenceLowText,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                } else if (isPendingVision) {
                    Text(
                        text = "Tap to review or launch AI extraction",
                        color = SlateTextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Action arrow or trigger icon
            if (isPendingVision || isFailed) {
                IconButton(
                    onClick = onTriggerAI,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Extract with AI",
                        tint = BlueAccent
                    )
                }
            } else if (isReady) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = "Open Verification Modal",
                    tint = Color.Gray,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
