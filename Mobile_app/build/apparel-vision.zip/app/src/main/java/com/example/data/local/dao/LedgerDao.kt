package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.DailyLedgerEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface LedgerDao {
    @Query("SELECT * FROM daily_ledger WHERE is_cleared_from_active_view = 0 ORDER BY apparel_id DESC")
    fun getActiveLedgerFlow(): Flow<List<DailyLedgerEntity>>

    @Query("SELECT * FROM daily_ledger ORDER BY apparel_id DESC")
    fun getAllLedgerFlow(): Flow<List<DailyLedgerEntity>>

    @Query("SELECT * FROM daily_ledger WHERE is_cleared_from_active_view = 0 ORDER BY apparel_id DESC")
    suspend fun getActiveLedgerList(): List<DailyLedgerEntity>

    @Query("SELECT * FROM daily_ledger ORDER BY apparel_id DESC")
    suspend fun getAllLedgerList(): List<DailyLedgerEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLedger(entry: DailyLedgerEntity): Long

    @Query("UPDATE daily_ledger SET is_cleared_from_active_view = 1 WHERE is_cleared_from_active_view = 0")
    suspend fun clearActiveView()

    @Query("UPDATE daily_ledger SET is_cleared_from_active_view = 0")
    suspend fun restoreActiveView()

    @Query("DELETE FROM daily_ledger WHERE id = :id")
    suspend fun deleteLedgerById(id: Int)

    @Query("DELETE FROM daily_ledger")
    suspend fun deleteAllLedger()
}
