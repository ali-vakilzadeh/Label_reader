package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class VisionField(
    @Json(name = "value")
    val value: String = "",
    @Json(name = "confidence")
    val confidence: Float = 0.0f
)

@JsonClass(generateAdapter = true)
data class VisionExtraction(
    @Json(name = "category")
    val category: VisionField = VisionField(),
    @Json(name = "sub_category")
    val subCategory: VisionField = VisionField(),
    @Json(name = "gender")
    val gender: VisionField = VisionField(),
    @Json(name = "season")
    val season: VisionField = VisionField(),
    @Json(name = "brand_name")
    val brandName: VisionField = VisionField(),
    @Json(name = "country_of_origin")
    val countryOfOrigin: VisionField = VisionField(),
    @Json(name = "size")
    val size: VisionField = VisionField(),
    @Json(name = "color")
    val color: VisionField = VisionField(),
    @Json(name = "material")
    val material: VisionField = VisionField(),
    @Json(name = "original_price")
    val originalPrice: VisionField = VisionField(),
    @Json(name = "netto")
    val netto: VisionField = VisionField(),
    @Json(name = "brutto")
    val brutto: VisionField = VisionField()
)

@JsonClass(generateAdapter = true)
data class VisionResponse(
    @Json(name = "success")
    val success: Boolean = false,
    @Json(name = "apparel_id")
    val apparelId: String? = null,
    @Json(name = "username")
    val username: String? = null,
    @Json(name = "timestamp")
    val timestamp: String? = null,
    @Json(name = "extraction")
    val extraction: VisionExtraction? = null,
    @Json(name = "error")
    val error: String? = null,
    @Json(name = "details")
    val details: String? = null
)

@JsonClass(generateAdapter = true)
data class LoginRequest(
    @Json(name = "password")
    val password: String,
    @Json(name = "user_id")
    val userId: String
)

@JsonClass(generateAdapter = true)
data class LoginResponse(
    @Json(name = "success")
    val success: Boolean = false,
    @Json(name = "token")
    val token: String? = null,
    @Json(name = "message")
    val message: String? = null,
    @Json(name = "error")
    val error: String? = null
)

@JsonClass(generateAdapter = true)
data class HealthResponse(
    @Json(name = "status")
    val status: String = "",
    @Json(name = "service")
    val service: String = "",
    @Json(name = "geminiConfigured")
    val geminiConfigured: Boolean = false
)
