package com.example.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scans")
data class ScanEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    @ColumnInfo(name = "apparel_id")
    val apparelId: String,
    @ColumnInfo(name = "parent_item_id")
    val parentItemId: String? = null,
    @ColumnInfo(name = "username")
    val username: String,
    @ColumnInfo(name = "timestamp")
    val timestamp: String,
    @ColumnInfo(name = "image_files")
    val imageFiles: String, // Semicolon-separated filenames or paths
    @ColumnInfo(name = "status")
    val status: String = STATUS_PENDING_VISION, // PENDING_VISION, EXTRACTING, READY_FOR_REVIEW, COMPLETED, FAILED
    
    // Extracted Fields
    @ColumnInfo(name = "category")
    val category: String = "",
    @ColumnInfo(name = "sub_category")
    val subCategory: String = "",
    @ColumnInfo(name = "gender")
    val gender: String = "",
    @ColumnInfo(name = "season")
    val season: String = "",
    @ColumnInfo(name = "brand_name")
    val brandName: String = "",
    @ColumnInfo(name = "country_of_origin")
    val countryOfOrigin: String = "",
    @ColumnInfo(name = "size")
    val size: String = "",
    @ColumnInfo(name = "color")
    val color: String = "",
    @ColumnInfo(name = "material")
    val material: String = "",
    @ColumnInfo(name = "original_price")
    val originalPrice: String = "",
    @ColumnInfo(name = "netto")
    val netto: String = "",
    @ColumnInfo(name = "brutto")
    val brutto: String = "",
    
    // Confidence Scores (0.0 to 1.0)
    @ColumnInfo(name = "category_conf")
    val categoryConf: Float = 0.0f,
    @ColumnInfo(name = "sub_category_conf")
    val subCategoryConf: Float = 0.0f,
    @ColumnInfo(name = "gender_conf")
    val genderConf: Float = 0.0f,
    @ColumnInfo(name = "season_conf")
    val seasonConf: Float = 0.0f,
    @ColumnInfo(name = "brand_conf")
    val brandConf: Float = 0.0f,
    @ColumnInfo(name = "country_conf")
    val countryConf: Float = 0.0f,
    @ColumnInfo(name = "size_conf")
    val sizeConf: Float = 0.0f,
    @ColumnInfo(name = "color_conf")
    val colorConf: Float = 0.0f,
    @ColumnInfo(name = "material_conf")
    val materialConf: Float = 0.0f,
    @ColumnInfo(name = "price_conf")
    val priceConf: Float = 0.0f,
    @ColumnInfo(name = "netto_conf")
    val nettoConf: Float = 0.0f,
    @ColumnInfo(name = "brutto_conf")
    val bruttoConf: Float = 0.0f,
    
    @ColumnInfo(name = "is_demo_record")
    val isDemoRecord: Boolean = false,
    @ColumnInfo(name = "error_message")
    val errorMessage: String? = null,
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val STATUS_PENDING_VISION = "PENDING_VISION"
        const val STATUS_EXTRACTING = "EXTRACTING"
        const val STATUS_READY_FOR_REVIEW = "READY_FOR_REVIEW"
        const val STATUS_COMPLETED = "COMPLETED"
        const val STATUS_FAILED = "FAILED"
    }

    fun getImageList(): List<String> {
        return if (imageFiles.isBlank()) emptyList() else imageFiles.split(";").map { it.trim() }.filter { it.isNotEmpty() }
    }

    fun hasLowConfidenceFields(): Boolean {
        val confidences = listOf(
            categoryConf, subCategoryConf, genderConf, seasonConf,
            brandConf, countryConf, sizeConf, colorConf,
            materialConf, priceConf, nettoConf, bruttoConf
        )
        return confidences.any { it < 0.70f }
    }

    fun lowConfidenceCount(): Int {
        val confidences = listOf(
            categoryConf, subCategoryConf, genderConf, seasonConf,
            brandConf, countryConf, sizeConf, colorConf,
            materialConf, priceConf, nettoConf, bruttoConf
        )
        return confidences.count { it < 0.70f }
    }
}
