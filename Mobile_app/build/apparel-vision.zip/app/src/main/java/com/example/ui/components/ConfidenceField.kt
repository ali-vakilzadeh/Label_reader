package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ConfidenceHighBorder
import com.example.ui.theme.ConfidenceHighGreen
import com.example.ui.theme.ConfidenceHighText
import com.example.ui.theme.ConfidenceLowBorder
import com.example.ui.theme.ConfidenceLowText
import com.example.ui.theme.ConfidenceLowYellow
import com.example.ui.theme.SlateBorder

@Composable
fun ConfidenceField(
    label: String,
    value: String,
    confidence: Float,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    options: List<String>? = null,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    singleLine: Boolean = true
) {
    val isLowConfidence = confidence < 0.70f
    val backgroundColor = if (isLowConfidence) ConfidenceLowYellow else Color.White
    val borderColor = if (isLowConfidence) ConfidenceLowBorder else SlateBorder
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        // Field Header: Label + Confidence Badge
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                modifier = Modifier.weight(1f)
            )

            // Confidence Score Pill
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isLowConfidence) ConfidenceLowYellow else ConfidenceHighGreen,
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isLowConfidence) ConfidenceLowBorder else ConfidenceHighBorder
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isLowConfidence) Icons.Default.Warning else Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = if (isLowConfidence) ConfidenceLowText else ConfidenceHighText,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = if (confidence > 0f) "${(confidence * 100).toInt()}%" else "Manual/0%",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isLowConfidence) ConfidenceLowText else ConfidenceHighText
                    )
                    if (isLowConfidence) {
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "Verify",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = ConfidenceLowText
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        if (options != null && options.isNotEmpty()) {
            // Dropdown Selector with Yellow Highlight if Low Confidence
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(backgroundColor)
                    .border(
                        width = if (isLowConfidence) 1.5.dp else 1.dp,
                        color = borderColor,
                        shape = RoundedCornerShape(8.dp)
                    )
                    .clickable { expanded = true }
                    .padding(horizontal = 14.dp, vertical = 12.dp)
                    .testTag("dropdown_${label.lowercase().replace(" ", "_")}")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (value.isNotBlank()) value else "Select $label...",
                        color = if (value.isNotBlank()) MaterialTheme.colorScheme.onSurface else Color.Gray,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowDropDown,
                        contentDescription = "Open $label dropdown",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                DropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    options.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(text = option) },
                            onClick = {
                                onValueChange(option)
                                expanded = false
                            }
                        )
                    }
                }
            }
        } else {
            // Standard Outlined Text Field with Custom Yellow Container Color
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("input_${label.lowercase().replace(" ", "_")}"),
                singleLine = singleLine,
                keyboardOptions = keyboardOptions,
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = backgroundColor,
                    unfocusedContainerColor = backgroundColor,
                    focusedBorderColor = if (isLowConfidence) ConfidenceLowBorder else MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = borderColor
                ),
                textStyle = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
