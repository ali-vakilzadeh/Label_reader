package com.example.data.remote

import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

interface MiddlewareApiService {
    @GET("/health")
    suspend fun checkHealth(): Response<HealthResponse>

    @POST("/api/v1/auth/login")
    suspend fun login(
        @Body request: LoginRequest
    ): Response<LoginResponse>

    @Multipart
    @POST("/api/v1/vision/extract")
    suspend fun extractApparelVision(
        @Header("Authorization") authorization: String,
        @Part images: List<MultipartBody.Part>,
        @Part("apparel_id") apparelId: RequestBody,
        @Part("username") username: RequestBody
    ): Response<VisionResponse>
}
