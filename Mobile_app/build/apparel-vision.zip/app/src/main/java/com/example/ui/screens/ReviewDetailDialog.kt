package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.local.entity.ScanEntity
import com.example.ui.components.ConfidenceField
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.ConfidenceLowBorder
import com.example.ui.theme.ConfidenceLowText
import com.example.ui.theme.ConfidenceLowYellow
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateSurface
import java.io.File

@Composable
fun ReviewDetailDialog(
    scan: ScanEntity,
    isProcessing: Boolean,
    onDismiss: () -> Unit,
    onConfirmAndSave: (
        category: String,
        subCategory: String,
        gender: String,
        season: String,
        brandName: String,
        countryOfOrigin: String,
        size: String,
        color: String,
        material: String,
        originalPrice: String,
        netto: String,
        brutto: String
    ) -> Unit,
    onDeleteScan: (Int) -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    // Form state initialized with extracted AI values
    var category by remember { mutableStateOf(scan.category) }
    var subCategory by remember { mutableStateOf(scan.subCategory) }
    var gender by remember { mutableStateOf(scan.gender) }
    var season by remember { mutableStateOf(scan.season) }
    var brandName by remember { mutableStateOf(scan.brandName) }
    var countryOfOrigin by remember { mutableStateOf(scan.countryOfOrigin) }
    var size by remember { mutableStateOf(scan.size) }
    var color by remember { mutableStateOf(scan.color) }
    var material by remember { mutableStateOf(scan.material) }
    var originalPrice by remember { mutableStateOf(scan.originalPrice) }
    var netto by remember { mutableStateOf(scan.netto) }
    var brutto by remember { mutableStateOf(scan.brutto) }

    val categoryOptions = listOf("clothing", "shoe", "accessories")
    val subCategoryOptions = listOf(
        "shirt", "pants", "all-body", "coat", "jacket", "pullover",
        "scarf", "shorts", "underwear", "cap", "hat", "shawl", "sunglasses", "others"
    )
    val genderOptions = listOf("male", "female", "unisex", "kids-boy", "kids-girl", "newborn")
    val seasonOptions = listOf("spring", "summer", "fall", "winter", "all-seasons")
    val colorOptions = listOf("black", "white", "blue", "red", "orange", "yellow", "brown", "green", "gray")

    val lowConfCount = scan.lowConfidenceCount()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(20.dp))
                .testTag("floating_review_modal"),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Header Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(NavyPrimary)
                        .padding(horizontal = 20.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Verify Item #${scan.apparelId}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Text(
                            text = "Captured: ${scan.timestamp}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFCBD5E1)
                            )
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { onDeleteScan(scan.id) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete scan",
                                tint = Color(0xFFF87171)
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close dialog",
                                tint = Color.White
                            )
                        }
                    }
                }

                // Confidence Banner Notice
                if (lowConfCount > 0) {
                    Surface(
                        color = ConfidenceLowYellow,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = ConfidenceLowText,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "$lowConfCount field(s) have confidence < 70% (highlighted in yellow). Please review.",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = ConfidenceLowText,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                }

                // Scrollable Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(scrollState)
                        .padding(16.dp)
                ) {
                    // Image Carousel Section
                    val imageList = scan.getImageList()
                    if (imageList.isNotEmpty()) {
                        Text(
                            text = "Captured Label Photos (${imageList.size}/8)",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            itemsIndexed(imageList) { idx, fileName ->
                                val file = if (File(fileName).isAbsolute) File(fileName) else File(context.filesDir, fileName)
                                Box(
                                    modifier = Modifier
                                        .size(120.dp, 120.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .border(1.dp, SlateBorder, RoundedCornerShape(10.dp))
                                ) {
                                    AsyncImage(
                                        model = file,
                                        contentDescription = "Photo ${idx + 1}",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                    Text(
                                        text = "#${idx + 1}",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(topEnd = 4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider(color = SlateBorder)
                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    // Section 1: Inferred Categories
                    Text(
                        text = "Classification (AI Inferred)",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    ConfidenceField(
                        label = "Category",
                        value = category,
                        confidence = scan.categoryConf,
                        options = categoryOptions,
                        onValueChange = { category = it }
                    )

                    ConfidenceField(
                        label = "Sub-Category",
                        value = subCategory,
                        confidence = scan.subCategoryConf,
                        options = subCategoryOptions,
                        onValueChange = { subCategory = it }
                    )

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Box(modifier = Modifier.weight(1f)) {
                            ConfidenceField(
                                label = "Gender",
                                value = gender,
                                confidence = scan.genderConf,
                                options = genderOptions,
                                onValueChange = { gender = it }
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Box(modifier = Modifier.weight(1f)) {
                            ConfidenceField(
                                label = "Season",
                                value = season,
                                confidence = scan.seasonConf,
                                options = seasonOptions,
                                onValueChange = { season = it }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = SlateBorder)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Section 2: Apparel Details
                    Text(
                        text = "Label Details & Weights",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    ConfidenceField(
                        label = "Brand Name",
                        value = brandName,
                        confidence = scan.brandConf,
                        onValueChange = { brandName = it }
                    )

                    ConfidenceField(
                        label = "Country of Origin",
                        value = countryOfOrigin,
                        confidence = scan.countryConf,
                        onValueChange = { countryOfOrigin = it }
                    )

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Box(modifier = Modifier.weight(1f)) {
                            ConfidenceField(
                                label = "Size",
                                value = size,
                                confidence = scan.sizeConf,
                                onValueChange = { size = it }
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Box(modifier = Modifier.weight(1f)) {
                            ConfidenceField(
                                label = "Dominant Color",
                                value = color,
                                confidence = scan.colorConf,
                                options = colorOptions,
                                onValueChange = { color = it }
                            )
                        }
                    }

                    ConfidenceField(
                        label = "Material",
                        value = material,
                        confidence = scan.materialConf,
                        onValueChange = { material = it }
                    )

                    ConfidenceField(
                        label = "Original Price",
                        value = originalPrice,
                        confidence = scan.priceConf,
                        onValueChange = { originalPrice = it }
                    )

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Box(modifier = Modifier.weight(1f)) {
                            ConfidenceField(
                                label = "Netto (Net Weight)",
                                value = netto,
                                confidence = scan.nettoConf,
                                onValueChange = { netto = it }
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Box(modifier = Modifier.weight(1f)) {
                            ConfidenceField(
                                label = "Brutto (Gross Weight)",
                                value = brutto,
                                confidence = scan.bruttoConf,
                                onValueChange = { brutto = it }
                            )
                        }
                    }
                }

                // Bottom Action Footer
                Surface(
                    color = SlateSurface,
                    modifier = Modifier.fillMaxWidth(),
                    tonalElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("button_cancel_review")
                        ) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Button(
                            onClick = {
                                onConfirmAndSave(
                                    category, subCategory, gender, season,
                                    brandName, countryOfOrigin, size, color,
                                    material, originalPrice, netto, brutto
                                )
                            },
                            enabled = !isProcessing,
                            colors = ButtonDefaults.buttonColors(containerColor = BlueAccent),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("button_confirm_save")
                        ) {
                            if (isProcessing) {
                                CircularProgressIndicator(
                                    color = Color.White,
                                    modifier = Modifier.size(18.dp),
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Confirm & Save", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
