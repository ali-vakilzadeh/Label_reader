package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.entity.DailyLedgerEntity
import com.example.data.local.entity.ScanEntity
import com.example.data.preferences.AppSettings
import com.example.data.repository.ApparelRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class ApparelViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ApparelRepository.getInstance(application)
    val appSettings = AppSettings.getInstance(application)

    val pendingScans: StateFlow<List<ScanEntity>> = repository.pendingScansFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeLedger: StateFlow<List<DailyLedgerEntity>> = repository.activeLedgerFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLedger: StateFlow<List<DailyLedgerEntity>> = repository.allLedgerFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Capture Session State
    val capturedPhotos = mutableStateListOf<File>()
    var activeBarcode by mutableStateOf<String?>(null)
    var isTorchEnabled by mutableStateOf(false)
    var selectedScanForReview by mutableStateOf<ScanEntity?>(null)
    var toastMessage by mutableStateOf<String?>(null)

    // Floating banner for first-run / connection failure without demo mode
    var showConnectionAlertBanner by mutableStateOf(false)

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _serverStatusMessage = MutableStateFlow<String?>(null)
    val serverStatusMessage: StateFlow<String?> = _serverStatusMessage.asStateFlow()

    init {
        checkInitialConnectionStatus()
    }

    fun checkInitialConnectionStatus() {
        viewModelScope.launch {
            // Test server connection quietly on startup
            val isSuccess = withContext(Dispatchers.IO) {
                try {
                    val visionService = com.example.data.remote.VisionExtractionService(getApplication(), appSettings)
                    val result = visionService.authenticateDevice(appSettings.devicePassword, appSettings.userId)
                    result.isSuccess
                } catch (e: Exception) {
                    false
                }
            }

            if (isSuccess) {
                _serverStatusMessage.value = "Connected to Middleware Server"
                showConnectionAlertBanner = false
            } else {
                // If demo mode is NOT enabled, alert user with floating notification
                if (!appSettings.demoModeEnabled) {
                    showConnectionAlertBanner = true
                    _serverStatusMessage.value = "Server connection failed (Offline mode)"
                } else {
                    _serverStatusMessage.value = "Demo Mode Active"
                }
            }
        }
    }

    fun dismissConnectionAlert() {
        showConnectionAlertBanner = false
    }

    fun enableDemoModeFromBanner() {
        appSettings.demoModeEnabled = true
        appSettings.isDemoModeConfigured = true
        showConnectionAlertBanner = false
        toastMessage = "Demo Mode activated. Records will use demo_0001 format."
        // If there were pending items, process them now with demo mode
        launchAiVisionBatch()
    }

    fun setDemoMode(enabled: Boolean) {
        appSettings.demoModeEnabled = enabled
        appSettings.isDemoModeConfigured = true
        if (enabled) {
            showConnectionAlertBanner = false
            toastMessage = "Demo Mode enabled. Unverified AI extractions will use sample heuristics."
        } else {
            toastMessage = "Demo Mode disabled. Captures will remain cached until server is reached."
            // Test connection again
            checkInitialConnectionStatus()
        }
    }

    fun setScannedBarcode(barcode: String) {
        val trimmed = barcode.trim()
        if (trimmed.isNotBlank()) {
            activeBarcode = trimmed
            appSettings.lastScannedBarcode = trimmed
            toastMessage = "Barcode locked: $trimmed. Ready to capture photos."
        }
    }

    fun resetBarcodePhase() {
        clearCurrentPhotos()
        activeBarcode = null
    }

    fun addCapturedPhoto(photoFile: File) {
        if (capturedPhotos.size < 8) {
            capturedPhotos.add(photoFile)
        }
    }

    fun removeCapturedPhoto(index: Int) {
        if (index in capturedPhotos.indices) {
            val file = capturedPhotos.removeAt(index)
            try {
                file.delete()
            } catch (ignored: Exception) {}
        }
    }

    fun clearCurrentPhotos() {
        for (f in capturedPhotos) {
            try { f.delete() } catch (ignored: Exception) {}
        }
        capturedPhotos.clear()
    }

    fun queueCurrentItemBatch(onComplete: (ScanEntity) -> Unit = {}) {
        val barcode = activeBarcode
        if (barcode.isNullOrBlank()) {
            toastMessage = "Please scan or enter an inventory barcode first."
            return
        }

        if (capturedPhotos.isEmpty()) {
            toastMessage = "Please capture at least 1 image before queueing."
            return
        }

        viewModelScope.launch {
            _isProcessing.value = true
            try {
                val filenames = capturedPhotos.map { it.name }
                val newScan = repository.createNewScanBatch(
                    apparelId = barcode,
                    imageFiles = filenames
                )
                capturedPhotos.clear()
                activeBarcode = null
                toastMessage = "Item #$barcode queued for AI vision extraction."
                onComplete(newScan)
            } catch (e: Exception) {
                toastMessage = "Error saving scan: ${e.message}"
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun duplicateLedgerItem(
        parent: DailyLedgerEntity,
        newBarcode: String,
        onSuccess: () -> Unit = {}
    ) {
        val cleanBarcode = newBarcode.trim()
        if (cleanBarcode.isBlank()) {
            toastMessage = "Barcode cannot be blank"
            return
        }

        viewModelScope.launch {
            _isProcessing.value = true
            try {
                val res = repository.duplicateLedgerEntry(parent, cleanBarcode)
                if (res.isSuccess) {
                    toastMessage = "Item duplicated to #$cleanBarcode (Parent: #${parent.apparelId})"
                    onSuccess()
                } else {
                    toastMessage = "Duplication error: ${res.exceptionOrNull()?.message}"
                }
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun launchAiVisionBatch() {
        viewModelScope.launch {
            _isProcessing.value = true
            try {
                val count = repository.launchAiVisionForPending()
                toastMessage = if (count > 0) "Processed $count pending scans." else "No pending items to process."
            } catch (e: Exception) {
                toastMessage = "AI extraction error: ${e.message}"
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun processSingleScan(scanId: Int) {
        viewModelScope.launch {
            _isProcessing.value = true
            try {
                val res = repository.processScanWithAI(scanId)
                if (res.isSuccess) {
                    toastMessage = "Extraction completed for Item #${res.getOrNull()?.apparelId}"
                } else {
                    toastMessage = "Extraction failed: ${res.exceptionOrNull()?.message}"
                }
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun confirmAndSaveVerifiedScan(
        scanId: Int,
        category: String,
        subCategory: String,
        gender: String,
        season: String,
        brandName: String,
        countryOfOrigin: String,
        size: String,
        color: String,
        material: String,
        originalPrice: String,
        netto: String,
        brutto: String,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            _isProcessing.value = true
            try {
                val result = repository.confirmAndSaveLedger(
                    scanId = scanId,
                    category = category,
                    subCategory = subCategory,
                    gender = gender,
                    season = season,
                    brandName = brandName,
                    countryOfOrigin = countryOfOrigin,
                    size = size,
                    color = color,
                    material = material,
                    originalPrice = originalPrice,
                    netto = netto,
                    brutto = brutto
                )

                if (result.isSuccess) {
                    selectedScanForReview = null
                    toastMessage = "Item #${result.getOrNull()?.apparelId} verified & saved to Daily Ledger."
                    onSuccess()
                } else {
                    toastMessage = "Error saving: ${result.exceptionOrNull()?.message}"
                }
            } catch (e: Exception) {
                toastMessage = "Failed: ${e.message}"
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun deleteScan(scanId: Int) {
        viewModelScope.launch {
            repository.deleteScanItem(scanId)
            if (selectedScanForReview?.id == scanId) {
                selectedScanForReview = null
            }
            toastMessage = "Scan removed."
        }
    }

    fun clearActiveDailyLedger() {
        viewModelScope.launch {
            repository.clearActiveDailyLedger()
            toastMessage = "Daily active view cleared. Records preserved in SQLite database."
        }
    }

    fun restoreActiveDailyLedger() {
        viewModelScope.launch {
            repository.restoreActiveDailyLedger()
            toastMessage = "Active daily view restored."
        }
    }

    fun shareCsvExport(context: Context) {
        viewModelScope.launch {
            _isProcessing.value = true
            try {
                val result = repository.generateCsvFile()
                if (result.isSuccess) {
                    val csvFile = result.getOrNull()!!
                    val authority = "${context.packageName}.fileprovider"
                    val uri: Uri = FileProvider.getUriForFile(context, authority, csvFile)

                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/csv"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, "Apparel Daily Ledger Export - ${appSettings.userId}")
                        putExtra(Intent.EXTRA_TEXT, "Attached is the Apparel Daily Ledger export containing verified apparel label records.")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }

                    context.startActivity(Intent.createChooser(shareIntent, "Share Ledger CSV"))
                } else {
                    toastMessage = "Failed to create CSV: ${result.exceptionOrNull()?.message}"
                }
            } catch (e: Exception) {
                toastMessage = "Error exporting CSV: ${e.message}"
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun emailDatabaseDump(context: Context) {
        viewModelScope.launch {
            _isProcessing.value = true
            try {
                val result = repository.exportDatabaseFile()
                if (result.isSuccess) {
                    val dbFile = result.getOrNull()!!
                    val authority = "${context.packageName}.fileprovider"
                    val uri: Uri = FileProvider.getUriForFile(context, authority, dbFile)

                    val emailIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "application/octet-stream"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, "Apparel Vision SQLite DB Dump - ${appSettings.userId}")
                        putExtra(Intent.EXTRA_TEXT, "Room SQLite database binary dump attached from device of user ${appSettings.userId}.\nGenerated on: ${java.util.Date()}")
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }

                    context.startActivity(Intent.createChooser(emailIntent, "Send SQLite Database Dump"))
                } else {
                    toastMessage = "Database dump failed: ${result.exceptionOrNull()?.message}"
                }
            } catch (e: Exception) {
                toastMessage = "Failed exporting SQLite DB: ${e.message}"
            } finally {
                _isProcessing.value = false
            }
        }
    }

    fun testServerConnection() {
        viewModelScope.launch {
            _serverStatusMessage.value = "Connecting to ${appSettings.serverUrl}..."
            try {
                val service = repository
                val result = withContext(Dispatchers.IO) {
                    val visionService = com.example.data.remote.VisionExtractionService(getApplication(), appSettings)
                    visionService.authenticateDevice(appSettings.devicePassword, appSettings.userId)
                }

                if (result.isSuccess) {
                    _serverStatusMessage.value = "Success: Device authenticated with Middleware Server!"
                    toastMessage = "Connected to Middleware Server."
                } else {
                    _serverStatusMessage.value = "Offline / Simulation Mode: ${result.exceptionOrNull()?.message}"
                    toastMessage = "Server unreachable. Running smart on-device AI simulation mode."
                }
            } catch (e: Exception) {
                _serverStatusMessage.value = "Connection error: ${e.message}"
            }
        }
    }

    fun purgeDatabaseHistory(password: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val result = repository.purgeScanHistoryAndImages(password)
            if (result.isSuccess) {
                toastMessage = "All scan history and local images have been permanently purged."
                onSuccess()
            } else {
                toastMessage = "Purge failed: ${result.exceptionOrNull()?.message}"
            }
        }
    }

    /**
     * Creates a high-fidelity synthetic label photo for fast testing / emulator demonstration.
     */
    fun createSampleLabelPhoto(context: Context, labelText: String = "SAMPLE LABEL"): File {
        if (activeBarcode.isNullOrBlank()) {
            val randomBarcode = "BAR-${(100000..999999).random()}"
            setScannedBarcode(randomBarcode)
        }
        val barcode = activeBarcode ?: "BAR-10001"
        val index = capturedPhotos.size + 1
        val file = File(context.filesDir, "IMG_${barcode}_$index.jpg")

        val bitmap = Bitmap.createBitmap(800, 1000, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Background tag texture
        val bgPaint = Paint().apply { color = Color.parseColor("#FAF7EE") }
        canvas.drawRect(Rect(0, 0, 800, 1000), bgPaint)

        // Tag border
        val borderPaint = Paint().apply {
            color = Color.parseColor("#4A5568")
            style = Paint.Style.STROKE
            strokeWidth = 6f
        }
        canvas.drawRect(Rect(30, 30, 770, 970), borderPaint)

        // Label details text
        val titlePaint = Paint().apply {
            color = Color.parseColor("#1A202C")
            textSize = 52f
            isFakeBoldText = true
        }
        val subPaint = Paint().apply {
            color = Color.parseColor("#2D3748")
            textSize = 34f
        }

        canvas.drawText("PATAGONIA", 80f, 150f, titlePaint)
        canvas.drawText("STYLE: 25528 M's Better Sweater", 80f, 230f, subPaint)
        canvas.drawText("SIZE: L / G (LARGE)", 80f, 310f, subPaint)
        canvas.drawText("COLOR: NAVY BLUE", 80f, 380f, subPaint)
        canvas.drawText("100% RECYCLED POLYESTER", 80f, 460f, subPaint)
        canvas.drawText("MADE IN VIETNAM / FABRIQUE AU VIETNAM", 80f, 540f, subPaint)
        canvas.drawText("RN 51884 - CA 30200", 80f, 620f, subPaint)
        canvas.drawText("MSRP: $179.00 USD", 80f, 700f, subPaint)
        canvas.drawText("WEIGHT: NET 420G / GROSS 460G", 80f, 780f, subPaint)

        val fos = FileOutputStream(file)
        bitmap.compress(Bitmap.CompressFormat.JPEG, 90, fos)
        fos.flush()
        fos.close()

        addCapturedPhoto(file)
        return file
    }
}
