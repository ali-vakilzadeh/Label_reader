package com.example.data.repository

import android.content.Context
import android.util.Log
import androidx.sqlite.db.SimpleSQLiteQuery
import com.example.data.local.db.AppDatabase
import com.example.data.local.entity.DailyLedgerEntity
import com.example.data.local.entity.ScanEntity
import com.example.data.preferences.AppSettings
import com.example.data.remote.VisionExtractionService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ApparelRepository(
    private val context: Context,
    private val database: AppDatabase,
    private val appSettings: AppSettings,
    private val visionService: VisionExtractionService
) {
    private val scanDao = database.scanDao()
    private val ledgerDao = database.ledgerDao()

    val pendingScansFlow: Flow<List<ScanEntity>> = scanDao.getActivePendingScansFlow()
    val allScansFlow: Flow<List<ScanEntity>> = scanDao.getAllScansFlow()
    val activeLedgerFlow: Flow<List<DailyLedgerEntity>> = ledgerDao.getActiveLedgerFlow()
    val allLedgerFlow: Flow<List<DailyLedgerEntity>> = ledgerDao.getAllLedgerFlow()

    suspend fun createNewScanBatch(
        apparelId: String,
        imageFiles: List<String>,
        parentItemId: String? = null
    ): ScanEntity = withContext(Dispatchers.IO) {
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        val imageFilesString = imageFiles.joinToString(";")

        val isDemo = appSettings.demoModeEnabled
        val finalApparelId = if (isDemo && (apparelId.startsWith("BAR-") || !apparelId.startsWith("demo_"))) {
            appSettings.getNextDemoId()
        } else {
            apparelId
        }

        val newScan = ScanEntity(
            apparelId = finalApparelId,
            parentItemId = parentItemId,
            username = appSettings.userId,
            timestamp = timestamp,
            imageFiles = imageFilesString,
            isDemoRecord = isDemo,
            status = ScanEntity.STATUS_PENDING_VISION
        )

        val insertedId = scanDao.insertScan(newScan)
        val created = newScan.copy(id = insertedId.toInt())

        // If Auto-Sync is enabled, trigger extraction immediately in background
        if (appSettings.autoSyncAiVision) {
            processScanWithAI(created.id)
        }

        created
    }

    suspend fun duplicateLedgerEntry(
        parent: DailyLedgerEntity,
        newBarcode: String
    ): Result<DailyLedgerEntity> = withContext(Dispatchers.IO) {
        try {
            val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val isDemo = appSettings.demoModeEnabled || parent.isDemoRecord
            val finalBarcode = if (isDemo && (newBarcode.startsWith("BAR-") || !newBarcode.startsWith("demo_"))) {
                appSettings.getNextDemoId()
            } else {
                newBarcode
            }

            val cloned = DailyLedgerEntity(
                apparelId = finalBarcode,
                parentItemId = parent.apparelId,
                username = appSettings.userId,
                timestamp = timestamp,
                category = parent.category,
                subCategory = parent.subCategory,
                gender = parent.gender,
                season = parent.season,
                netto = parent.netto,
                brutto = parent.brutto,
                brandName = parent.brandName,
                countryOfOrigin = parent.countryOfOrigin,
                size = parent.size,
                color = parent.color,
                material = parent.material,
                originalPrice = parent.originalPrice,
                imageFiles = parent.imageFiles,
                isDemoRecord = isDemo,
                isClearedFromActiveView = false
            )

            val insertedId = ledgerDao.insertLedger(cloned)
            Result.success(cloned.copy(id = insertedId.toInt()))
        } catch (e: Exception) {
            Log.e(TAG, "Duplication failed: ${e.message}", e)
            Result.failure(e)
        }
    }

    suspend fun processScanWithAI(scanId: Int): Result<ScanEntity> = withContext(Dispatchers.IO) {
        val scan = scanDao.getScanById(scanId) ?: return@withContext Result.failure(Exception("Scan not found"))

        // Set status to extracting
        scanDao.updateScan(scan.copy(status = ScanEntity.STATUS_EXTRACTING))

        val result = visionService.extractVision(scan)
        if (result.isSuccess) {
            val extraction = result.getOrNull()!!
            val updatedScan = scan.copy(
                status = ScanEntity.STATUS_READY_FOR_REVIEW,
                category = extraction.category.value,
                subCategory = extraction.subCategory.value,
                gender = extraction.gender.value,
                season = extraction.season.value,
                brandName = extraction.brandName.value,
                countryOfOrigin = extraction.countryOfOrigin.value,
                size = extraction.size.value,
                color = extraction.color.value,
                material = extraction.material.value,
                originalPrice = extraction.originalPrice.value,
                netto = extraction.netto.value,
                brutto = extraction.brutto.value,
                categoryConf = extraction.category.confidence,
                subCategoryConf = extraction.subCategory.confidence,
                genderConf = extraction.gender.confidence,
                seasonConf = extraction.season.confidence,
                brandConf = extraction.brandName.confidence,
                countryConf = extraction.countryOfOrigin.confidence,
                sizeConf = extraction.size.confidence,
                colorConf = extraction.color.confidence,
                materialConf = extraction.material.confidence,
                priceConf = extraction.originalPrice.confidence,
                nettoConf = extraction.netto.confidence,
                bruttoConf = extraction.brutto.confidence,
                errorMessage = null
            )
            scanDao.updateScan(updatedScan)
            Result.success(updatedScan)
        } else {
            val errorMsg = result.exceptionOrNull()?.message ?: "Extraction failed"
            val failedScan = scan.copy(
                status = ScanEntity.STATUS_FAILED,
                errorMessage = errorMsg
            )
            scanDao.updateScan(failedScan)
            Result.failure(Exception(errorMsg))
        }
    }

    suspend fun launchAiVisionForPending(): Int = withContext(Dispatchers.IO) {
        val pendingList = scanDao.getPendingVisionScans()
        var processedCount = 0
        for (scan in pendingList) {
            val res = processScanWithAI(scan.id)
            if (res.isSuccess) {
                processedCount++
            }
        }
        processedCount
    }

    suspend fun confirmAndSaveLedger(
        scanId: Int,
        category: String,
        subCategory: String,
        gender: String,
        season: String,
        brandName: String,
        countryOfOrigin: String,
        size: String,
        color: String,
        material: String,
        originalPrice: String,
        netto: String,
        brutto: String
    ): Result<DailyLedgerEntity> = withContext(Dispatchers.IO) {
        val scan = scanDao.getScanById(scanId) ?: return@withContext Result.failure(Exception("Scan not found"))

        val ledgerEntry = DailyLedgerEntity(
            apparelId = scan.apparelId,
            parentItemId = scan.parentItemId,
            username = scan.username.ifBlank { appSettings.userId },
            timestamp = scan.timestamp,
            category = category,
            subCategory = subCategory,
            gender = gender,
            season = season,
            netto = netto,
            brutto = brutto,
            brandName = brandName,
            countryOfOrigin = countryOfOrigin,
            size = size,
            color = color,
            material = material,
            originalPrice = originalPrice,
            imageFiles = scan.imageFiles,
            isDemoRecord = scan.isDemoRecord,
            isClearedFromActiveView = false
        )

        val ledgerId = ledgerDao.insertLedger(ledgerEntry)

        // Mark scan as COMPLETED so it is removed from the Review screen
        val completedScan = scan.copy(
            status = ScanEntity.STATUS_COMPLETED,
            category = category,
            subCategory = subCategory,
            gender = gender,
            season = season,
            brandName = brandName,
            countryOfOrigin = countryOfOrigin,
            size = size,
            color = color,
            material = material,
            originalPrice = originalPrice,
            netto = netto,
            brutto = brutto
        )
        scanDao.updateScan(completedScan)

        Result.success(ledgerEntry.copy(id = ledgerId.toInt()))
    }

    suspend fun deleteScanItem(scanId: Int) = withContext(Dispatchers.IO) {
        val scan = scanDao.getScanById(scanId)
        if (scan != null) {
            deleteScanImages(scan)
            scanDao.deleteScanById(scanId)
        }
    }

    suspend fun clearActiveDailyLedger() = withContext(Dispatchers.IO) {
        ledgerDao.clearActiveView()
    }

    suspend fun restoreActiveDailyLedger() = withContext(Dispatchers.IO) {
        ledgerDao.restoreActiveView()
    }

    suspend fun generateCsvFile(): Result<File> = withContext(Dispatchers.IO) {
        try {
            val records = ledgerDao.getActiveLedgerList()
            val dateStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val csvFile = File(exportDir, "apparel_ledger_$dateStr.csv")

            val writer = csvFile.bufferedWriter()
            writer.write(DailyLedgerEntity.CSV_HEADER)
            writer.newLine()

            for (record in records) {
                writer.write(record.toCsvRow())
                writer.newLine()
            }
            writer.flush()
            writer.close()

            Result.success(csvFile)
        } catch (e: Exception) {
            Log.e(TAG, "CSV generation failed", e)
            Result.failure(e)
        }
    }

    /**
     * Dumps the Room SQLite database file for sharing / emailing.
     * Checkpoints WAL first to ensure complete data integrity.
     */
    suspend fun exportDatabaseFile(): Result<File> = withContext(Dispatchers.IO) {
        try {
            // Checkpoint SQLite WAL
            try {
                database.openHelper.writableDatabase.query(SimpleSQLiteQuery("PRAGMA wal_checkpoint(FULL);")).use { cursor ->
                    cursor.moveToFirst()
                }
            } catch (cpEx: Exception) {
                Log.w(TAG, "WAL checkpoint warning: ${cpEx.message}")
            }

            val dbPath = context.getDatabasePath(AppDatabase.DATABASE_NAME)
            if (!dbPath.exists()) {
                return@withContext Result.failure(Exception("Database file does not exist yet"))
            }

            val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
            val dateStr = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val targetFile = File(exportDir, "apparel_vision_dump_$dateStr.db")

            FileInputStream(dbPath).use { input ->
                FileOutputStream(targetFile).use { output ->
                    input.copyTo(output)
                }
            }

            Result.success(targetFile)
        } catch (e: Exception) {
            Log.e(TAG, "Database export failed", e)
            Result.failure(e)
        }
    }

    /**
     * Danger zone: Purges all scan history, daily ledgers, and local photo files.
     */
    suspend fun purgeScanHistoryAndImages(password: String): Result<Unit> = withContext(Dispatchers.IO) {
        if (password != appSettings.devicePassword) {
            return@withContext Result.failure(Exception("Incorrect device password"))
        }

        try {
            // Purge tables
            scanDao.deleteAllScans()
            ledgerDao.deleteAllLedger()

            // Delete local photos
            val files = context.filesDir.listFiles { file ->
                file.name.startsWith("IMG_") && file.name.endsWith(".jpg")
            } ?: emptyArray()

            for (f in files) {
                try {
                    f.delete()
                } catch (ignored: Exception) {}
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun deleteScanImages(scan: ScanEntity) {
        val filesDir = context.filesDir
        for (name in scan.getImageList()) {
            val f = if (File(name).isAbsolute) File(name) else File(filesDir, name)
            if (f.exists()) {
                try {
                    f.delete()
                } catch (ignored: Exception) {}
            }
        }
    }

    companion object {
        private const val TAG = "ApparelRepository"

        @Volatile
        private var INSTANCE: ApparelRepository? = null

        fun getInstance(context: Context): ApparelRepository {
            return INSTANCE ?: synchronized(this) {
                val db = AppDatabase.getInstance(context)
                val settings = AppSettings.getInstance(context)
                val visionService = VisionExtractionService(context, settings)
                val instance = ApparelRepository(context.applicationContext, db, settings, visionService)
                INSTANCE = instance
                instance
            }
        }
    }
}
