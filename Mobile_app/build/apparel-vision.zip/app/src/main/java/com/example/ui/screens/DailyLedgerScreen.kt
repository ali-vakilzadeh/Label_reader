package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.local.entity.DailyLedgerEntity
import com.example.ui.theme.BlueAccent
import com.example.ui.theme.NavyPrimary
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateCard
import com.example.ui.theme.SlateSurface
import com.example.ui.theme.SlateTextSecondary
import com.example.ui.viewmodel.ApparelViewModel

@Composable
fun DailyLedgerScreen(
    viewModel: ApparelViewModel
) {
    val context = LocalContext.current
    val activeLedger by viewModel.activeLedger.collectAsStateWithLifecycle()
    val allLedger by viewModel.allLedger.collectAsStateWithLifecycle()

    var showHistoricalView by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var showClearConfirmationDialog by remember { mutableStateOf(false) }
    var selectedLedgerItem by remember { mutableStateOf<DailyLedgerEntity?>(null) }
    var itemToDuplicate by remember { mutableStateOf<DailyLedgerEntity?>(null) }

    val currentList = if (showHistoricalView) allLedger else activeLedger
    val filteredList = currentList.filter { entry ->
        if (searchQuery.isBlank()) true
        else {
            entry.brandName.contains(searchQuery, ignoreCase = true) ||
            entry.category.contains(searchQuery, ignoreCase = true) ||
            entry.subCategory.contains(searchQuery, ignoreCase = true) ||
            entry.apparelId.contains(searchQuery, ignoreCase = true) ||
            (entry.parentItemId ?: "").contains(searchQuery, ignoreCase = true) ||
            entry.material.contains(searchQuery, ignoreCase = true) ||
            entry.countryOfOrigin.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SlateSurface)
            .testTag("screen_daily_ledger")
    ) {
        // Top Header
        Surface(
            color = NavyPrimary,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (showHistoricalView) "All Ledger Records" else "Daily Active Ledger",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Text(
                            text = "${currentList.size} verified items recorded",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFCBD5E1))
                        )
                    }

                    // Share CSV Button
                    Button(
                        onClick = { viewModel.shareCsvExport(context) },
                        enabled = currentList.isNotEmpty(),
                        colors = ButtonDefaults.buttonColors(containerColor = BlueAccent),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("button_share_csv")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Share CSV", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Stats Chips Bar
                val clothingCount = currentList.count { it.category.equals("clothing", ignoreCase = true) }
                val shoeCount = currentList.count { it.category.equals("shoe", ignoreCase = true) }
                val accCount = currentList.count { it.category.equals("accessories", ignoreCase = true) }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatPill("Clothing: $clothingCount", Color(0xFF38BDF8))
                    StatPill("Shoes: $shoeCount", Color(0xFF4ADE80))
                    StatPill("Accessories: $accCount", Color(0xFFFBBF24))
                }
            }
        }

        // Action Toolbar (Search + Clear Daily View + Archive Toggle)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("input_ledger_search"),
                placeholder = { Text("Search brand, barcode, parent...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear search", modifier = Modifier.size(16.dp))
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    unfocusedBorderColor = SlateBorder
                )
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Clear Active View Button
            if (!showHistoricalView && activeLedger.isNotEmpty()) {
                IconButton(
                    onClick = { showClearConfirmationDialog = true },
                    modifier = Modifier
                        .size(44.dp)
                        .background(Color(0xFFFEE2E2), RoundedCornerShape(8.dp))
                        .testTag("button_clear_active_ledger")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear Active Daily View",
                        tint = Color(0xFFDC2626)
                    )
                }
            } else if (showHistoricalView) {
                IconButton(
                    onClick = { viewModel.restoreActiveDailyLedger() },
                    modifier = Modifier
                        .size(44.dp)
                        .background(Color(0xFFE0E7FF), RoundedCornerShape(8.dp))
                ) {
                    Icon(
                        imageVector = Icons.Default.Restore,
                        contentDescription = "Restore Active View",
                        tint = Color(0xFF4338CA)
                    )
                }
            }

            Spacer(modifier = Modifier.width(4.dp))

            // Toggle Historical View
            IconButton(
                onClick = { showHistoricalView = !showHistoricalView },
                modifier = Modifier
                    .size(44.dp)
                    .background(if (showHistoricalView) NavyPrimary else Color.White, RoundedCornerShape(8.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.History,
                    contentDescription = "Toggle History View",
                    tint = if (showHistoricalView) Color.White else NavyPrimary
                )
            }
        }

        // Ledger List
        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) "No records match search" else if (showHistoricalView) "Historical database is empty" else "Active daily ledger is clear",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (!showHistoricalView && allLedger.isNotEmpty())
                            "You have ${allLedger.size} historical records in SQLite. Tap the History icon to view them."
                        else
                            "Completed and verified apparel labels will appear here.",
                        color = SlateTextSecondary,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(horizontal = 32.dp)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredList, key = { it.id }) { item ->
                    LedgerItemCard(
                        item = item,
                        onClick = { selectedLedgerItem = item },
                        onDuplicate = { itemToDuplicate = item }
                    )
                }
            }
        }
    }

    // Confirmation Dialog for Clearing Active Daily View
    if (showClearConfirmationDialog) {
        AlertDialog(
            onDismissRequest = { showClearConfirmationDialog = false },
            title = { Text("Clear Active Daily Ledger?") },
            text = {
                Text("This will remove items from the active daily screen. Records remain safely stored in the Room SQLite database and can be exported or viewed anytime.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearActiveDailyLedger()
                        showClearConfirmationDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("Clear Active View")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showClearConfirmationDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Duplicate to New Barcode Dialog
    if (itemToDuplicate != null) {
        DuplicateBarcodeDialog(
            parentItem = itemToDuplicate!!,
            onDismiss = { itemToDuplicate = null },
            onConfirmDuplicate = { newBarcode ->
                viewModel.duplicateLedgerItem(
                    parent = itemToDuplicate!!,
                    newBarcode = newBarcode,
                    onSuccess = {
                        itemToDuplicate = null
                    }
                )
            }
        )
    }

    // Detail Item Inspector Dialog
    if (selectedLedgerItem != null) {
        LedgerDetailInspectorDialog(
            item = selectedLedgerItem!!,
            onDismiss = { selectedLedgerItem = null },
            onDuplicate = {
                val target = selectedLedgerItem
                selectedLedgerItem = null
                itemToDuplicate = target
            }
        )
    }
}

@Composable
fun StatPill(text: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = color.copy(alpha = 0.2f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.5f))
    ) {
        Text(
            text = text,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun LedgerItemCard(
    item: DailyLedgerEntity,
    onClick: () -> Unit,
    onDuplicate: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() }
            .testTag("ledger_card_${item.apparelId}"),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = SlateCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (item.isDemoRecord || item.apparelId.startsWith("demo_")) Color(0xFFD97706) else NavyPrimary
                    ) {
                        Text(
                            text = "#${item.apparelId}",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    if (item.isDemoRecord || item.apparelId.startsWith("demo_")) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFFEF3C7),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFDE68A))
                        ) {
                            Text(
                                text = "DEMO",
                                color = Color(0xFFB45309),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                    if (!item.parentItemId.isNullOrBlank()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFEFF6FF),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBFDBFE))
                        ) {
                            Text(
                                text = "Child of #${item.parentItemId}",
                                color = Color(0xFF1D4ED8),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = item.brandName.ifBlank { "Unbranded" },
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.originalPrice.ifBlank { "$0.00" },
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = BlueAccent
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = onDuplicate,
                        modifier = Modifier
                            .size(32.dp)
                            .background(Color(0xFFF1F5F9), CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Duplicate Record",
                            tint = NavyPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${item.category.uppercase()} • ${item.subCategory} • Size: ${item.size.ifBlank { "N/A" }}",
                    style = MaterialTheme.typography.bodySmall,
                    color = SlateTextSecondary
                )
                Text(
                    text = "Color: ${item.color}",
                    style = MaterialTheme.typography.bodySmall,
                    color = SlateTextSecondary
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Material: ${item.material.ifBlank { "N/A" }}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF64748B)
                )
                Text(
                    text = "Net: ${item.netto.ifBlank { "-" }} / Gross: ${item.brutto.ifBlank { "-" }}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF64748B)
                )
            }
        }
    }
}

@Composable
fun DuplicateBarcodeDialog(
    parentItem: DailyLedgerEntity,
    onDismiss: () -> Unit,
    onConfirmDuplicate: (String) -> Unit
) {
    var newBarcodeInput by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Duplicate to New Barcode", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(
                    text = "Create a child record cloning all extracted data from Parent #${parentItem.apparelId} (${parentItem.brandName} ${parentItem.category}) without re-running AI vision.",
                    fontSize = 13.sp,
                    color = SlateTextSecondary
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = newBarcodeInput,
                    onValueChange = { newBarcodeInput = it },
                    singleLine = true,
                    placeholder = { Text("Scan or enter new barcode") },
                    label = { Text("New Barcode (apparel_id)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        newBarcodeInput = "BAR-${(100000..999999).random()}"
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Generate Sample Barcode")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (newBarcodeInput.isNotBlank()) {
                        onConfirmDuplicate(newBarcodeInput.trim())
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = BlueAccent)
            ) {
                Text("Clone Record")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun LedgerDetailInspectorDialog(
    item: DailyLedgerEntity,
    onDismiss: () -> Unit,
    onDuplicate: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Item #${item.apparelId} - ${item.brandName}", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                InspectorRow("Operator", item.username)
                if (!item.parentItemId.isNullOrBlank()) {
                    InspectorRow("Parent Item ID", item.parentItemId)
                }
                InspectorRow("Timestamp", item.timestamp)
                InspectorRow("Category", item.category)
                InspectorRow("Sub-Category", item.subCategory)
                InspectorRow("Gender", item.gender)
                InspectorRow("Season", item.season)
                InspectorRow("Brand", item.brandName)
                InspectorRow("Country of Origin", item.countryOfOrigin)
                InspectorRow("Size", item.size)
                InspectorRow("Color", item.color)
                InspectorRow("Material", item.material)
                InspectorRow("Price", item.originalPrice)
                InspectorRow("Netto", item.netto)
                InspectorRow("Brutto", item.brutto)
                InspectorRow("Image Files", item.imageFiles)
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onDuplicate) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Duplicate")
                }
                Button(onClick = onDismiss) {
                    Text("Close")
                }
            }
        }
    )
}

@Composable
fun InspectorRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontWeight = FontWeight.Medium, fontSize = 12.sp, color = Color.Gray)
        Text(text = value.ifBlank { "—" }, fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.SemiBold)
    }
}
