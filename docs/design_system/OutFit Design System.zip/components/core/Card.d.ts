import type { ReactNode, CSSProperties } from 'react';

/** Cream panel with a cocoa hairline, 10px radius and a faint shadow. The only container. */
export interface CardProps {
  title?: ReactNode;
  /** Right-aligned control in the header row. */
  action?: ReactNode;
  /** Cap width at 420px — login, single-field forms. @default false */
  narrow?: boolean;
  /** Set false when a full-bleed table fills the card. @default true */
  padded?: boolean;
  children?: ReactNode;
  style?: CSSProperties;
}
export function Card(props: CardProps): JSX.Element;
