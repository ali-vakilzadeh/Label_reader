/** Single-figure counter. Rows of tiles head the Analytics and Import screens. */
export interface TileProps {
  label: string;
  value: string | number;
  /** Sub-line, e.g. a basis or sample size. */
  note?: string;
  /** Gold-outlined emphasis for the one figure that matters. @default "default" */
  tone?: 'default' | 'accent';
}
export function Tile(props: TileProps): JSX.Element;
