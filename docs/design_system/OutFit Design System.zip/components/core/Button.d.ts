import type { ReactNode, CSSProperties } from 'react';

/**
 * Action control. Primary is navy (gold in dark mode); one primary per view.
 * @startingPoint section="Core" subtitle="Buttons, chips, tags, cards, tiles, meters" viewport="700x320"
 */
export interface ButtonProps {
  /** Visual weight. @default "secondary" */
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  /** @default "md" */
  size?: 'sm' | 'md' | 'lg';
  disabled?: boolean;
  /** Leading glyph, usually a Lucide 14px icon. */
  icon?: ReactNode;
  /** Render as an anchor when the action is navigation. @default "button" */
  as?: 'button' | 'a';
  href?: string;
  type?: 'button' | 'submit';
  onClick?: () => void;
  children?: ReactNode;
  style?: CSSProperties;
}
export function Button(props: ButtonProps): JSX.Element;
