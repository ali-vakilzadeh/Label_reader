import type { ReactNode } from 'react';

/** Pill-shaped status or filter token. Colour carries meaning through the text and dot, not a wash. */
export interface ChipProps {
  /** @default "neutral" */
  tone?: 'neutral' | 'gold' | 'critical' | 'warning' | 'good' | 'info';
  /** Show a leading severity dot. @default false */
  dot?: boolean;
  children?: ReactNode;
}
export function Chip(props: ChipProps): JSX.Element;
