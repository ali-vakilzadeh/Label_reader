import type { ReactNode } from 'react';

/** Inline provenance marker set beside a value — FUZZY:0.88, AM, locked, suggested. */
export interface TagProps {
  /** @default "neutral" */
  tone?: 'neutral' | 'warning' | 'good' | 'critical';
  /** Monospace for codes and confidence numbers. @default false */
  mono?: boolean;
  children?: ReactNode;
}
export function Tag(props: TagProps): JSX.Element;
