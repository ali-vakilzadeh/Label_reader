The only container in the system. Do not nest cards; use a heading and a rule instead.

```jsx
<Card title="Today's import" action={<Button size="sm">Re-run</Button>}>…</Card>
```

`padded={false}` when a `DataGrid` should meet the card edge.
