import React from 'react';

export function Card({ title, action, narrow = false, padded = true, children, style, ...rest }) {
  return (
    <section {...rest} style={{
      background: 'var(--surface-card)', border: 'var(--border-width) solid var(--border-default)',
      borderRadius: 'var(--radius-md)', boxShadow: 'var(--shadow-card)',
      padding: padded ? 'var(--pad-card)' : 0, marginBottom: 'var(--space-2xl)',
      maxWidth: narrow ? 'var(--page-narrow)' : undefined, ...style
    }}>
      {title || action ? (
        <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 'var(--space-2xl)', marginBottom: 'var(--space-lg)', flexWrap: 'wrap' }}>
          <h2 style={{ margin: 0, fontSize: 'var(--text-lg)', color: 'var(--text-title)' }}>{title}</h2>
          {action}
        </header>
      ) : null}
      {children}
    </section>
  );
}
