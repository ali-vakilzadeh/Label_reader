import React from 'react';

const chipTones = {
  neutral: { background: 'var(--surface-card)', color: 'var(--text-body)', borderColor: 'var(--border-default)' },
  gold: { background: 'var(--surface-accent)', color: 'var(--text-accent)', borderColor: 'var(--gold-300)' },
  critical: { background: 'var(--surface-card)', color: 'var(--status-critical)', borderColor: 'var(--border-default)' },
  warning: { background: 'var(--surface-card)', color: 'var(--status-warning)', borderColor: 'var(--border-default)' },
  good: { background: 'var(--surface-card)', color: 'var(--status-good)', borderColor: 'var(--border-default)' },
  info: { background: 'var(--surface-card)', color: 'var(--status-info)', borderColor: 'var(--border-default)' }
};

export function Chip({ tone = 'neutral', dot = false, children, ...rest }) {
  const t = chipTones[tone] || chipTones.neutral;
  return (
    <span {...rest} style={{
      display: 'inline-flex', alignItems: 'center', gap: 'var(--space-xs)',
      padding: 'var(--space-hair) var(--space-lg)', fontSize: 'var(--text-sm)',
      borderRadius: 'var(--radius-pill)', border: 'var(--border-width) solid ' + t.borderColor,
      background: t.background, color: t.color
    }}>
      {dot ? <i aria-hidden="true" style={{ width: 6, height: 6, borderRadius: '50%', background: 'currentColor' }} /> : null}
      {children}
    </span>
  );
}
