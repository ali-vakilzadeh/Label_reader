Small inline marker that annotates the value it follows. Never interactive.

```jsx
Trousers <Tag tone="warning" mono>FUZZY:0.88</Tag>
```

Use for field provenance, locale fallback and lock state. For counts or filters use `Chip`.
