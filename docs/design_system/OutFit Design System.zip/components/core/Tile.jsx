import React from 'react';

export function Tile({ label, value, note, tone = 'default', ...rest }) {
  const accent = tone === 'accent';
  return (
    <div {...rest} style={{
      minWidth: 110, padding: 'var(--space-md) var(--space-xl)',
      border: 'var(--border-width) solid ' + (accent ? 'var(--border-accent)' : 'var(--border-default)'),
      borderRadius: 'var(--radius-sm)', background: accent ? 'var(--surface-accent)' : 'var(--surface-card)',
      boxShadow: 'var(--shadow-card)'
    }}>
      <span style={{ display: 'block', fontSize: 'var(--text-2xl)', fontWeight: 'var(--weight-semibold)', color: 'var(--text-title)', fontVariantNumeric: 'var(--numeric-table)', lineHeight: 'var(--leading-tight)' }}>{value}</span>
      <span style={{ display: 'block', fontSize: 'var(--text-sm)', color: 'var(--text-muted)' }}>{label}</span>
      {note ? <span style={{ display: 'block', fontSize: 'var(--text-xs)', color: 'var(--text-faint)', marginTop: 'var(--space-hair)' }}>{note}</span> : null}
    </div>
  );
}
