/** Horizontal proportion bar — resolution coverage, training-buffer fill, disk use. */
export interface MeterProps {
  value: number;
  /** @default 100 */
  max?: number;
  label?: string;
  /** @default "default" */
  tone?: 'default' | 'accent';
}
export function Meter(props: MeterProps): JSX.Element;
