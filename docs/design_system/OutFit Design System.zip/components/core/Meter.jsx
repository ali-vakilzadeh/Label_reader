import React from 'react';

export function Meter({ value, max = 100, label, tone = 'default', ...rest }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const fill = tone === 'accent' ? 'var(--chart-highlight)' : 'var(--chart-bar)';
  return (
    <div {...rest}>
      {label ? (
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 'var(--text-sm)', color: 'var(--text-muted)' }}>
          <span>{label}</span><span style={{ fontVariantNumeric: 'var(--numeric-table)' }}>{Math.round(pct)}%</span>
        </div>
      ) : null}
      <div role="meter" aria-valuenow={value} aria-valuemax={max} style={{
        height: 14, background: 'var(--chart-track)', borderRadius: 'var(--radius-pill)',
        overflow: 'hidden', margin: 'var(--space-xs) 0', boxShadow: 'var(--shadow-inset-track)'
      }}>
        <div style={{ height: '100%', width: pct + '%', background: fill, transition: 'width var(--duration-medium) var(--ease-out)' }} />
      </div>
    </div>
  );
}
