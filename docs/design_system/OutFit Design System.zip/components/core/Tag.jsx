import React from 'react';

const tagTones = {
  neutral: { color: 'var(--text-muted)', borderColor: 'var(--border-hairline)' },
  warning: { color: 'var(--status-warning)', borderColor: 'var(--gold-300)' },
  good: { color: 'var(--status-good)', borderColor: 'var(--cocoa-200)' },
  critical: { color: 'var(--status-critical)', borderColor: 'var(--cocoa-200)' }
};

export function Tag({ tone = 'neutral', mono = false, children, ...rest }) {
  const t = tagTones[tone] || tagTones.neutral;
  return (
    <span {...rest} style={{
      display: 'inline-block', padding: '0 var(--space-xs)', marginLeft: 'var(--space-hair)',
      fontSize: 'var(--text-xs)', fontFamily: mono ? 'var(--font-mono)' : 'inherit',
      borderRadius: 'var(--radius-xs)', border: 'var(--border-width) solid ' + t.borderColor,
      background: 'var(--surface-sunken)', color: t.color, verticalAlign: 'middle'
    }}>{children}</span>
  );
}
