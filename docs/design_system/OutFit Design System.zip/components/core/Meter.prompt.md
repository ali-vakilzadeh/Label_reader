Proportion bar on a sunken cream track.

```jsx
<Meter label="Taxonomy resolved" value={91} />
<Meter label="Training buffer" value={7.4} max={10} tone="accent" />
```
