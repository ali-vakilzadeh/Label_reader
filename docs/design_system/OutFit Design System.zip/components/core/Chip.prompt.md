Pill token for alert severity, applied filters and row flags.

```jsx
<Chip tone="critical" dot>2 critical</Chip>
<Chip tone="good" dot>Heartbeat OK</Chip>
<Chip>Brand: Zara ×</Chip>
```

Only `gold` gets a filled background — reserve it for the count that matters on the screen.
