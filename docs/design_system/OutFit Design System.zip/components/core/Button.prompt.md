Action control — navy primary, cocoa-bordered secondary, ghost for row actions, danger for destructive text buttons.

```jsx
<Button variant="primary">Apply</Button>
<Button size="sm" icon={<Lock size={13} />}>Lock</Button>
<Button variant="danger" size="sm">Delete</Button>
```

Sizes: `sm` for anything inside a grid row or bulk-action bar, `md` for forms, `lg` only on the login card. Never two primaries in one card.
