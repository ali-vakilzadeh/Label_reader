Counter tile. Figure first at 1.5rem tabular navy, label beneath.

```jsx
<Tile value="1,284" label="Items imported" note="since 04.09" />
<Tile value="37" label="Needs review" tone="accent" />
```
