import React from 'react';

const buttonBase = {
  display: 'inline-flex', alignItems: 'center', gap: 'var(--space-xs)',
  font: 'inherit', fontWeight: 'var(--weight-medium)', lineHeight: 'var(--leading-body)',
  padding: 'var(--pad-button)', borderRadius: 'var(--radius-sm)',
  border: 'var(--border-width) solid var(--border-default)',
  background: 'var(--surface-card)', color: 'var(--text-body)',
  textDecoration: 'none', cursor: 'pointer', boxShadow: 'var(--shadow-card)',
  transition: 'var(--transition-control)', whiteSpace: 'nowrap'
};

const buttonVariants = {
  primary: { background: 'var(--action-primary)', color: 'var(--text-inverse)', borderColor: 'var(--action-primary)' },
  secondary: {},
  ghost: { background: 'transparent', boxShadow: 'none', borderColor: 'transparent' },
  danger: { color: 'var(--action-danger)', borderColor: 'var(--cocoa-200)' }
};

const buttonSizes = {
  sm: { padding: '.15rem .45rem', fontSize: 'var(--text-sm)', borderRadius: 'var(--radius-xs)' },
  md: {},
  lg: { padding: '.5rem 1rem', fontSize: 'var(--text-base)' }
};

export function Button({ variant = 'secondary', size = 'md', disabled = false, icon, children, as = 'button', style, ...rest }) {
  const Tag = as;
  return (
    <Tag
      {...rest}
      disabled={Tag === 'button' ? disabled : undefined}
      aria-disabled={disabled || undefined}
      style={{ ...buttonBase, ...buttonVariants[variant], ...buttonSizes[size], ...(disabled ? { opacity: .5, cursor: 'not-allowed', boxShadow: 'none' } : null), ...style }}
    >
      {icon ? <span aria-hidden="true" style={{ display: 'inline-flex' }}>{icon}</span> : null}
      {children}
    </Tag>
  );
}
