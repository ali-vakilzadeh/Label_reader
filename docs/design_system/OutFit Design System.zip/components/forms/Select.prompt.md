Dropdown for taxonomy values and filters.

```jsx
<Select label="Category" options={['Trousers', 'Jacket', 'Knitwear']} />
<Select options={['Lock', 'Unlock', 'Delete']} aria-label="Bulk action" />
```

Values come from the client's reference tables; never hand-author a taxonomy list in a screen.
