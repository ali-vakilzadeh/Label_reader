import React from 'react';
import { controlStyle } from './Field.jsx';

export function Select({ label, options = [], hint, disabled = false, id, style, children, ...rest }) {
  const control = (
    <select id={id} disabled={disabled} {...rest} style={{
      ...controlStyle, appearance: 'none', paddingRight: '1.6rem', cursor: disabled ? 'not-allowed' : 'pointer',
      backgroundImage: 'linear-gradient(45deg, transparent 50%, var(--cocoa-500) 50%), linear-gradient(135deg, var(--cocoa-500) 50%, transparent 50%)',
      backgroundPosition: 'calc(100% - 14px) 52%, calc(100% - 9px) 52%',
      backgroundSize: '5px 5px, 5px 5px', backgroundRepeat: 'no-repeat',
      ...(disabled ? { background: 'var(--surface-sunken)', color: 'var(--text-faint)' } : null), ...style
    }}>
      {children || options.map(o => typeof o === 'string'
        ? <option key={o} value={o}>{o}</option>
        : <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
  if (!label) return control;
  return (
    <label htmlFor={id} style={{ display: 'block', margin: 'var(--space-md) 0', fontSize: 'var(--text-cell)', color: 'var(--text-muted)' }}>
      {label}
      <span style={{ display: 'block', marginTop: 'var(--space-2xs)' }}>{control}</span>
      {hint ? <span style={{ display: 'block', marginTop: 'var(--space-hair)', fontSize: 'var(--text-sm)', color: 'var(--text-faint)' }}>{hint}</span> : null}
    </label>
  );
}
