Labelled input for the item editor, filters and settings forms.

```jsx
<Field label="Original price" suffix="AMD" defaultValue="12900" hint="Suggested 12 900 · n=41" />
<Field label="Barcode" disabled value="8690000000001" />
```

Locked rows render fields `disabled`, not hidden. Errors replace the hint.
