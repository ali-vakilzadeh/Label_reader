import type { ReactNode } from 'react';

/**
 * Labelled text input. The label sits above in cocoa at .88rem — never a placeholder as label.
 * @startingPoint section="Forms" subtitle="Field, Select, filter and field grids" viewport="700x300"
 */
export interface FieldProps {
  label: ReactNode;
  id?: string;
  name?: string;
  value?: string | number;
  defaultValue?: string | number;
  placeholder?: string;
  hint?: string;
  /** Replaces the hint and reddens the border. */
  error?: string;
  /** Unit or currency shown outside the control, e.g. "AMD". */
  suffix?: ReactNode;
  disabled?: boolean;
  /** @default false */
  textarea?: boolean;
  onChange?: (e: any) => void;
}
export function Field(props: FieldProps): JSX.Element;
