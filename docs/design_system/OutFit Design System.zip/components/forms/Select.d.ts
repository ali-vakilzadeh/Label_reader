import type { ReactNode } from 'react';

/** Dropdown over the client's reference tables. Omit the label inside a bulk-action bar. */
export interface SelectProps {
  label?: ReactNode;
  id?: string;
  name?: string;
  /** Strings, or {value,label} for id-backed taxonomy rows. */
  options?: Array<string | { value: string; label: string }>;
  value?: string;
  defaultValue?: string;
  hint?: string;
  disabled?: boolean;
  onChange?: (e: any) => void;
  children?: ReactNode;
}
export function Select(props: SelectProps): JSX.Element;
