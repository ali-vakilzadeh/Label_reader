import React from 'react';

export const controlStyle = {
  font: 'inherit', width: '100%', padding: 'var(--pad-control)',
  border: 'var(--border-width) solid var(--border-default)', borderRadius: 'var(--radius-sm)',
  background: 'var(--surface-raised)', color: 'var(--text-body)',
  boxShadow: 'var(--shadow-card)', transition: 'var(--transition-control)'
};

export function Field({ label, hint, error, suffix, disabled = false, textarea = false, id, style, ...rest }) {
  const Control = textarea ? 'textarea' : 'input';
  return (
    <label htmlFor={id} style={{ display: 'block', margin: 'var(--space-md) 0', fontSize: 'var(--text-cell)', color: 'var(--text-muted)' }}>
      {label}
      <span style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-xs)', marginTop: 'var(--space-2xs)' }}>
        <Control id={id} disabled={disabled} {...rest} style={{
          ...controlStyle,
          ...(disabled ? { background: 'var(--surface-sunken)', color: 'var(--text-faint)' } : null),
          ...(error ? { borderColor: 'var(--status-critical)' } : null), ...style
        }} />
        {suffix ? <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>{suffix}</span> : null}
      </span>
      {error ? <span style={{ display: 'block', marginTop: 'var(--space-hair)', fontSize: 'var(--text-sm)', color: 'var(--status-critical)' }}>{error}</span>
        : hint ? <span style={{ display: 'block', marginTop: 'var(--space-hair)', fontSize: 'var(--text-sm)', color: 'var(--text-faint)' }}>{hint}</span> : null}
    </label>
  );
}
