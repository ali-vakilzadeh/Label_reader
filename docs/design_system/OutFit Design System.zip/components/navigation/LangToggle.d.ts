/** EN / ՀԱՅ switch. Lives in the navy brand row, so its idle state is cream on navy. */
export interface LangToggleProps {
  /** @default "en" */
  locale?: 'en' | 'hy';
  onChange?: (locale: 'en' | 'hy') => void;
}
export function LangToggle(props: LangToggleProps): JSX.Element;
