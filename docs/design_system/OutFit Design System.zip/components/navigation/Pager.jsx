import React from 'react';
import { Button } from '../core/Button.jsx';

export function Pager({ page = 1, pages = 1, total, onPage, ...rest }) {
  return (
    <div {...rest} style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-lg)', marginTop: 'var(--space-lg)' }}>
      <Button size="sm" disabled={page <= 1} onClick={() => onPage && onPage(page - 1)}>← Previous</Button>
      <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', fontVariantNumeric: 'var(--numeric-table)' }}>
        Page {page} of {pages}{total != null ? ' · ' + total + ' rows' : ''}
      </span>
      <Button size="sm" disabled={page >= pages} onClick={() => onPage && onPage(page + 1)}>Next →</Button>
    </div>
  );
}
