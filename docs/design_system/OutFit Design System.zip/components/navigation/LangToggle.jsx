import React from 'react';

export function LangToggle({ locale = 'en', onChange, ...rest }) {
  const opts = [{ id: 'en', label: 'EN' }, { id: 'hy', label: 'ՀԱՅ', lang: 'hy' }];
  return (
    <span {...rest} role="group" aria-label="Language" style={{
      display: 'inline-flex', border: 'var(--border-width) solid var(--cocoa-500)',
      borderRadius: 'var(--radius-sm)', overflow: 'hidden'
    }}>
      {opts.map(o => {
        const on = o.id === locale;
        return (
          <button key={o.id} type="button" lang={o.lang} onClick={() => onChange && onChange(o.id)} style={{
            font: 'inherit', fontSize: 'var(--text-sm)', fontWeight: 'var(--weight-medium)',
            padding: 'var(--space-2xs) var(--space-lg)', border: 0, cursor: 'pointer',
            background: on ? 'var(--gold-500)' : 'transparent',
            color: on ? 'var(--navy-950)' : 'var(--cream-200)', transition: 'var(--transition-control)'
          }}>{o.label}</button>
        );
      })}
    </span>
  );
}
