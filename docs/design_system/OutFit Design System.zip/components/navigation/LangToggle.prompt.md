Locale switch for the bilingual chrome.

```jsx
<LangToggle locale={locale} onChange={setLocale} />
```

Switching changes interface chrome only. Data values are looked up in the client's tables; brand and country are always English.
