import type { ReactNode } from 'react';

/**
 * Two-tier chrome: navy brand row (wordmark, operator, language) over a cream tab row with a gold underline on the active screen.
 * @startingPoint section="Navigation" subtitle="Two-tier top bar, language toggle, pager" viewport="700x220"
 */
export interface TopBarProps {
  items?: Array<{ key: string; label: string; href?: string; lang?: string; onClick?: () => void }>;
  /** Key of the current screen. */
  active?: string;
  /** Signed-in operator, e.g. "admin". */
  user?: string;
  /** Controls in the brand row — LangToggle, sign out. */
  right?: ReactNode;
  /** Second half of the wordmark. @default "Label Reader" */
  title?: string;
}
export function TopBar(props: TopBarProps): JSX.Element;
