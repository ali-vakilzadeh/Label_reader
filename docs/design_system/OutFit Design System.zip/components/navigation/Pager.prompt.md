Pagination under a DataGrid.

```jsx
<Pager page={3} pages={26} total={1284} onPage={setPage} />
```
