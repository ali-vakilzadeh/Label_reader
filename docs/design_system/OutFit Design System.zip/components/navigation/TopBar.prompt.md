Page chrome. OutFit has no logo file in the repo, so the wordmark is set in type — uppercase Noto Sans bold cream, with the product name in gold beside it.

```jsx
<TopBar active="items" user="admin" right={<LangToggle locale="en" />}
  items={[{key:'items',label:'Items'},{key:'import',label:'Import'}]} />
```

Nav labels come from `src/i18n` — pass `lang="hy"` on Armenian labels so the Armenian face is used.
