/** Grid pagination. Server-rendered pages, so it reads as two links plus a count. */
export interface PagerProps {
  /** @default 1 */
  page?: number;
  /** @default 1 */
  pages?: number;
  /** Total matching rows, shown after the page count. */
  total?: number;
  onPage?: (page: number) => void;
}
export function Pager(props: PagerProps): JSX.Element;
