import React from 'react';

export function TopBar({ items = [], active, user, right, title = 'Label Reader', ...rest }) {
  return (
    <header {...rest} style={{ background: 'var(--surface-chrome)', borderBottom: 'var(--border-width) solid var(--border-default)' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-2xl)', padding: 'var(--space-lg) var(--space-2xl)', background: 'var(--surface-brandbar)' }}>
        <span style={{ display: 'flex', alignItems: 'baseline', gap: '.4rem' }}>
          <b style={{ color: 'var(--cream-50)', fontSize: 'var(--text-base)', fontWeight: 'var(--weight-bold)', letterSpacing: 'var(--tracking-caps)', textTransform: 'uppercase' }}>OutFit</b>
          <span style={{ color: 'var(--gold-300)', fontSize: 'var(--text-cell)' }}>{title}</span>
        </span>
        <span style={{ flex: 1 }} />
        {user ? <span style={{ color: 'var(--navy-200)', fontSize: 'var(--text-sm)' }}>{user}</span> : null}
        {right}
      </div>
      <nav style={{ display: 'flex', gap: 'var(--space-hair)', padding: '0 var(--space-2xl)', flexWrap: 'wrap' }}>
        {items.map(it => {
          const on = it.key === active;
          return (
            <a key={it.key} href={it.href || '#'} onClick={it.onClick} lang={it.lang} style={{
              padding: 'var(--space-md) var(--space-lg)', fontSize: 'var(--text-cell)', textDecoration: 'none',
              color: on ? 'var(--text-title)' : 'var(--text-muted)',
              fontWeight: on ? 'var(--weight-semibold)' : 'var(--weight-regular)',
              borderBottom: '2px solid ' + (on ? 'var(--border-accent)' : 'transparent'),
              marginBottom: -1, transition: 'var(--transition-control)'
            }}>{it.label}</a>
          );
        })}
      </nav>
    </header>
  );
}
