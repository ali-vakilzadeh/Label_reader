import React from 'react';

export function BarChart({ data = [], height = 180, barHeight = 18, gap = 8, highlightIndex = -1, unit = '', ...rest }) {
  const max = Math.max(1, ...data.map(d => d.value));
  const labelW = 116;
  const rows = data.length;
  const h = Math.max(height, rows * (barHeight + gap));
  return (
    <svg {...rest} viewBox={'0 0 480 ' + h} width="100%" height="auto" role="img" style={{ display: 'block' }}>
      {data.map((d, i) => {
        const y = i * (barHeight + gap);
        const w = (d.value / max) * (480 - labelW - 46);
        const fill = i === highlightIndex ? 'var(--chart-highlight)' : 'var(--chart-bar)';
        return (
          <g key={d.label}>
            <text x="0" y={y + barHeight * 0.75} style={{ fontSize: 11, fill: 'var(--text-muted)', fontFamily: 'var(--font-sans)' }}>{d.label}</text>
            <rect x={labelW} y={y} width={Math.max(w, 1)} height={barHeight} rx="4" fill={fill} />
            <text x={labelW + Math.max(w, 1) + 6} y={y + barHeight * 0.75} style={{ fontSize: 11, fill: 'var(--text-title)', fontFamily: 'var(--font-sans)', fontVariantNumeric: 'tabular-nums' }}>{d.value}{unit}</text>
          </g>
        );
      })}
    </svg>
  );
}
