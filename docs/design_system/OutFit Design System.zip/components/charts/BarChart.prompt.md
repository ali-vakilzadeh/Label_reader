Analytics bars. Navy bars on cream, one optional gold bar for the figure under discussion; the value is always printed at the bar end so nobody has to read a gridline.

```jsx
<BarChart data={[{label:'Trousers',value:412},{label:'Jacket',value:288}]} highlightIndex={0} />
```

Categorical series use `--chart-cat-1…6`. No pies, no stacked bars, no legends where a label fits beside the bar.
