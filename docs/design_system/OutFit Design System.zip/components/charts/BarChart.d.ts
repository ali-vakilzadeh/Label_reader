/**
 * Horizontal bars, inline SVG, no chart library — the box has no CDN access.
 * @startingPoint section="Charts" subtitle="Inline SVG bars for the Analytics screen" viewport="700x260"
 */
export interface BarChartProps {
  data?: Array<{ label: string; value: number }>;
  /** Minimum SVG height. @default 180 */
  height?: number;
  /** @default 18 */
  barHeight?: number;
  /** @default 8 */
  gap?: number;
  /** Paint one bar gold. @default -1 */
  highlightIndex?: number;
  /** Suffix on the value label, e.g. " kg". */
  unit?: string;
}
export function BarChart(props: BarChartProps): JSX.Element;
