import type { ReactNode } from 'react';

/** Read-only field pairs — item provenance, import digest, engine basis. */
export interface KeyValueProps {
  items?: Array<{ label: string; value: ReactNode; mono?: boolean }>;
  /** Pair columns. @default 1 */
  columns?: number;
}
export function KeyValue(props: KeyValueProps): JSX.Element;
