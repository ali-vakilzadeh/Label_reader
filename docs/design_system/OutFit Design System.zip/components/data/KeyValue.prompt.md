Definition list for facts the operator cannot edit.

```jsx
<KeyValue columns={2} items={[{label:'Digest',value:'a91f…4c',mono:true},{label:'Operator',value:'anna'}]} />
```
