import React from 'react';
import { controlStyle } from '../forms/Field.jsx';

export function HsCodePicker({ value = '', results = [], open = false, onQuery, onPick, name, ...rest }) {
  return (
    <div {...rest} style={{ position: 'relative', maxWidth: 360 }}>
      <input value={value} name={name} onChange={e => onQuery && onQuery(e.target.value)}
        placeholder="Search the CN nomenclature…" aria-label="HS code"
        style={{ ...controlStyle, fontFamily: 'var(--font-mono)' }} />
      {open && results.length ? (
        <div role="listbox" style={{
          position: 'absolute', top: 'calc(100% + 3px)', left: 0, minWidth: 340, maxHeight: 260, overflowY: 'auto',
          background: 'var(--surface-raised)', border: 'var(--border-width) solid var(--border-strong)',
          borderRadius: 'var(--radius-sm)', boxShadow: 'var(--shadow-overlay)', zIndex: 20
        }}>
          {results.map(r => (
            <div key={r.code} role="option" tabIndex={0} onMouseDown={e => { e.preventDefault(); onPick && onPick(r); }}
              style={{ padding: 'var(--space-xs) var(--space-lg)', fontSize: 'var(--text-sm)', cursor: 'pointer', display: 'flex', gap: 'var(--space-lg)' }}>
              <code style={{ fontWeight: 'var(--weight-semibold)', color: 'var(--text-title)' }}>{r.code}</code>
              <span style={{ color: 'var(--text-muted)' }}>{r.name}</span>
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}
