/** Typeahead over the 951 CN headings. A person picks the code; the suggestion engine never text-searches this list. */
export interface HsCodePickerProps {
  value?: string;
  /** Rows from /api/hs-codes?q= — debounced 200 ms upstream. */
  results?: Array<{ code: string; name: string }>;
  open?: boolean;
  name?: string;
  onQuery?: (q: string) => void;
  onPick?: (row: { code: string; name: string }) => void;
}
export function HsCodePicker(props: HsCodePickerProps): JSX.Element;
