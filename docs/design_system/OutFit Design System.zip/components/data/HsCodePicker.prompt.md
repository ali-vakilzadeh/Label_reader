HS code typeahead. Overlay is the one place the system uses a real shadow and a strong cocoa border.

```jsx
<HsCodePicker value={q} open results={rows} onQuery={setQ} onPick={r => setCode(r.code)} />
```

Minimum two characters before querying; picking sets the code and shows its legal name beneath.
