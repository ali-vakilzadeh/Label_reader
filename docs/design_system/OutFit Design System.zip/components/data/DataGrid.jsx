import React from 'react';
import { StatusDot } from '../feedback/StatusDot.jsx';

const gridCell = {
  padding: 'var(--pad-cell)', borderBottom: 'var(--border-width) solid var(--border-hairline)',
  textAlign: 'left', verticalAlign: 'top'
};

const rowSurfaces = {
  default: null,
  locked: { background: 'var(--surface-locked)', color: 'var(--text-muted)' },
  review: null,
  duplicate: null
};

const rowMarkers = { review: 'warning', duplicate: 'info', locked: 'neutral' };

export function DataGrid({ columns = [], rows = [], selectable = false, selected = [], onSelect, onSelectAll, empty = 'No items match these filters.', ...rest }) {
  return (
    <div {...rest} style={{ overflowX: 'auto', border: 'var(--border-width) solid var(--border-default)', borderRadius: 'var(--radius-md)', background: 'var(--surface-card)', boxShadow: 'var(--shadow-card)' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 'var(--text-cell)' }}>
        <thead>
          <tr>
            {selectable ? (
              <th style={{ ...gridCell, background: 'var(--surface-head)', width: 28, position: 'sticky', top: 0, zIndex: 1 }}>
                <input type="checkbox" aria-label="Select all" onChange={e => onSelectAll && onSelectAll(e.target.checked)} />
              </th>
            ) : null}
            <th style={{ ...gridCell, background: 'var(--surface-head)', width: 16, position: 'sticky', top: 0, zIndex: 1 }} />
            {columns.map(c => (
              <th key={c.key} style={{
                ...gridCell, background: 'var(--surface-head)', position: 'sticky', top: 0, zIndex: 1,
                fontWeight: 'var(--weight-semibold)', color: 'var(--text-title)',
                textAlign: c.numeric ? 'right' : 'left', whiteSpace: 'nowrap',
                borderBottom: 'var(--border-width) solid var(--border-default)'
              }}>{c.label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.length === 0 ? (
            <tr><td colSpan={columns.length + (selectable ? 2 : 1)} style={{ ...gridCell, padding: 'var(--space-2xl)', textAlign: 'center', color: 'var(--text-muted)' }}>{empty}</td></tr>
          ) : rows.map((r, i) => {
            const state = r.state || 'default';
            return (
              <tr key={r.id || i} style={{
                background: (rowSurfaces[state] && rowSurfaces[state].background) || (i % 2 ? 'var(--surface-row-alt)' : 'transparent'),
                color: (rowSurfaces[state] && rowSurfaces[state].color) || undefined
              }}>
                {selectable ? (
                  <td style={gridCell}>
                    <input type="checkbox" name="ids" value={r.id} checked={selected.includes(r.id)} disabled={state === 'locked'}
                      onChange={e => onSelect && onSelect(r.id, e.target.checked)} aria-label={'Select ' + (r.id || i)} />
                  </td>
                ) : null}
                <td style={{ ...gridCell, paddingRight: 0 }}>
                  {rowMarkers[state] ? <StatusDot level={rowMarkers[state]} size={6} /> : null}
                </td>
                {columns.map(c => (
                  <td key={c.key} style={{
                    ...gridCell, textAlign: c.numeric ? 'right' : 'left',
                    fontVariantNumeric: c.numeric ? 'var(--numeric-table)' : undefined,
                    fontFamily: c.mono ? 'var(--font-mono)' : undefined,
                    whiteSpace: c.wrap ? 'normal' : 'nowrap'
                  }}>{c.render ? c.render(r) : r[c.key]}</td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
