import type { ReactNode } from 'react';

/**
 * The item ledger. Zebra rows on cream, sticky cocoa-ruled header, a 6px dot column carrying row state.
 * @startingPoint section="Data" subtitle="Item grid, key–value pairs, HS code picker" viewport="700x360"
 */
export interface DataGridColumn {
  key: string;
  label: string;
  /** Right-align and use tabular figures. */
  numeric?: boolean;
  /** Monospace — barcodes, HS codes, digests. */
  mono?: boolean;
  /** Allow wrapping; cells are nowrap by default. */
  wrap?: boolean;
  render?: (row: any) => ReactNode;
}
export interface DataGridProps {
  columns?: DataGridColumn[];
  rows?: Array<{ id?: string | number; state?: 'default' | 'locked' | 'review' | 'duplicate'; [k: string]: any }>;
  /** Show the checkbox column for bulk actions. @default false */
  selectable?: boolean;
  selected?: Array<string | number>;
  onSelect?: (id: string | number, checked: boolean) => void;
  onSelectAll?: (checked: boolean) => void;
  /** @default "No items match these filters." */
  empty?: ReactNode;
}
export function DataGrid(props: DataGridProps): JSX.Element;
