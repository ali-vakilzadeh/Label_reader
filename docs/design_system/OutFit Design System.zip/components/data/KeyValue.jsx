import React from 'react';

export function KeyValue({ items = [], columns = 1, ...rest }) {
  return (
    <dl {...rest} style={{
      display: 'grid', gridTemplateColumns: 'repeat(' + columns + ', max-content 1fr)',
      gap: 'var(--space-hair) var(--space-lg)', margin: 'var(--space-xs) 0', fontSize: 'var(--text-cell)'
    }}>
      {items.map(it => [
        <dt key={it.label + '-k'} style={{ color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>{it.label}</dt>,
        <dd key={it.label + '-v'} style={{ margin: 0, color: 'var(--text-body)', fontFamily: it.mono ? 'var(--font-mono)' : undefined }}>{it.value}</dd>
      ])}
    </dl>
  );
}
