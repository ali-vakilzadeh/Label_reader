The Items ledger and every other tabular view. Row state shows as a dot, not a tinted row — except `locked`, which sinks to cream-300 and greys its text because the row is genuinely inert.

```jsx
<DataGrid selectable columns={[{key:'barcode',label:'Barcode',mono:true},{key:'pieces',label:'Pieces',numeric:true}]}
  rows={[{id:1,barcode:'8690000000001',pieces:12,state:'review'}]} />
```

Locked rows keep their checkbox disabled. Put the grid in a `Card padded={false}` when it is the whole card.
