import React from 'react';
import { StatusDot } from './StatusDot.jsx';

export function Alert({ level = 'info', message, at, acknowledged = false, action, ...rest }) {
  return (
    <article {...rest} style={{
      display: 'flex', alignItems: 'center', gap: 'var(--space-lg)', flexWrap: 'wrap',
      background: 'var(--surface-card)', border: 'var(--border-width) solid var(--border-default)',
      borderLeft: 'var(--rule-accent) solid var(--status-' + level + ')',
      borderRadius: 'var(--radius-sm)', padding: 'var(--space-md) var(--space-xl)',
      margin: 'var(--space-sm) 0', opacity: acknowledged ? .55 : 1, boxShadow: 'var(--shadow-card)'
    }}>
      <StatusDot level={level} />
      <span style={{ flex: 1, fontSize: 'var(--text-cell)', color: 'var(--text-body)' }}>{message}</span>
      {at ? <time style={{ fontSize: 'var(--text-sm)', color: 'var(--text-faint)', fontVariantNumeric: 'var(--numeric-table)' }}>{at}</time> : null}
      {action}
    </article>
  );
}
