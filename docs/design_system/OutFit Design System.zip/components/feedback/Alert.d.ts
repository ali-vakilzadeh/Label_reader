import type { ReactNode } from 'react';

/** One row in the Server screen's alert list. Acknowledged alerts stay, at 55% opacity. */
export interface AlertProps {
  /** @default "info" */
  level?: 'critical' | 'warning' | 'good' | 'info' | 'neutral';
  message: ReactNode;
  /** Timestamp text, tabular. */
  at?: string;
  /** @default false */
  acknowledged?: boolean;
  action?: ReactNode;
}
export function Alert(props: AlertProps): JSX.Element;
