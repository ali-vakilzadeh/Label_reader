Alert list row on the Server screen.

```jsx
<Alert level="critical" message="Vision credential rejected (401)" at="09:14"
  action={<Button size="sm">Acknowledge</Button>} />
```

Acknowledging dims the row; it is never removed from the list.
