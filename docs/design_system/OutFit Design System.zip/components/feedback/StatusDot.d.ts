/**
 * The system's severity carrier. Colour lives in an 8px dot on a neutral surface — no tinted blocks.
 * @startingPoint section="Feedback" subtitle="Status banner, notices, alerts, severity dots" viewport="700x340"
 */
export interface StatusDotProps {
  /** @default "neutral" */
  level?: 'critical' | 'warning' | 'good' | 'info' | 'neutral';
  /** Text set beside the dot — always state the condition in words. */
  label?: string;
  /** @default 8 */
  size?: number;
}
export function StatusDot(props: StatusDotProps): JSX.Element;
