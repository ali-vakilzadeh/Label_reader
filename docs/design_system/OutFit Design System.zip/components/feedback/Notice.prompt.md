Explanatory block inside a card. Cream surface, 3px severity rule on the left edge.

```jsx
<Notice level="warning" title="hs_map.csv is empty">
  The rule tier stays dormant until Outfit fills it. The history tier still works.
</Notice>
```
