import React from 'react';

export function Notice({ level = 'info', title, children, action, ...rest }) {
  return (
    <div {...rest} style={{
      display: 'flex', gap: 'var(--space-lg)', alignItems: 'flex-start',
      background: 'var(--surface-card)', border: 'var(--border-width) solid var(--border-default)',
      borderLeft: 'var(--rule-accent) solid var(--status-' + level + ')',
      borderRadius: 'var(--radius-sm)', boxShadow: 'var(--shadow-card)',
      padding: 'var(--space-lg) var(--space-xl)', margin: 'var(--space-lg) 0'
    }}>
      <div style={{ flex: 1, fontSize: 'var(--text-cell)' }}>
        {title ? <strong style={{ display: 'block', color: 'var(--text-title)', fontWeight: 'var(--weight-semibold)' }}>{title}</strong> : null}
        <span style={{ color: 'var(--text-muted)' }}>{children}</span>
      </div>
      {action}
    </div>
  );
}
