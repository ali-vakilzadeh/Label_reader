import type { ReactNode } from 'react';

/** Inline explanation inside a card — what happened, what the operator should do. */
export interface NoticeProps {
  /** @default "info" */
  level?: 'critical' | 'warning' | 'good' | 'info' | 'neutral';
  title?: ReactNode;
  action?: ReactNode;
  children?: ReactNode;
}
export function Notice(props: NoticeProps): JSX.Element;
