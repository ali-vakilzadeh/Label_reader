import type { ReactNode } from 'react';

/** Full-width middleware state strip under the nav. One per page, always the first thing below the chrome. */
export interface StatusBannerProps {
  /** @default "neutral" */
  level?: 'critical' | 'warning' | 'good' | 'info' | 'neutral';
  /** Condition in words, e.g. "Middleware OK · heartbeat 22 s ago". */
  headline: string;
  /** Second clause — what it means or what to do. */
  detail?: string;
  /** Counter row: queue, alerts, last import. */
  tiles?: Array<{ label: string; value: string | number; level?: 'critical' | 'warning' | 'good' | 'info' | 'neutral' }>;
  action?: ReactNode;
}
export function StatusBanner(props: StatusBannerProps): JSX.Element;
