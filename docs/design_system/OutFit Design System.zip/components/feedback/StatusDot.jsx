import React from 'react';

const dotColors = {
  critical: 'var(--dot-critical)', warning: 'var(--dot-warning)',
  good: 'var(--dot-good)', info: 'var(--dot-info)', neutral: 'var(--dot-neutral)'
};

export function StatusDot({ level = 'neutral', label, size = 8, ...rest }) {
  return (
    <span {...rest} style={{ display: 'inline-flex', alignItems: 'center', gap: 'var(--space-md)', whiteSpace: 'nowrap' }}>
      <i aria-hidden="true" style={{
        width: size, height: size, borderRadius: '50%', flex: 'none',
        background: dotColors[level] || dotColors.neutral,
        boxShadow: '0 0 0 3px color-mix(in oklab, ' + (dotColors[level] || dotColors.neutral) + ' 16%, transparent)'
      }} />
      {label ? <span style={{ fontWeight: 'var(--weight-medium)', color: 'var(--text-title)' }}>{label}</span> : null}
    </span>
  );
}
