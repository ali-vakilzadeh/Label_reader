Middleware status strip. Neutral cream surface; only `critical` earns a 2px red top rule.

```jsx
<StatusBanner level="good" headline="Middleware OK · heartbeat 22 s ago"
  detail="Status is up to 30 s stale." tiles={[{label:'Queue',value:214,level:'info'}]} />
```

Never render OK from a stale heartbeat — pass `level="warning"` with the age instead.
