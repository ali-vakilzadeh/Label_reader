Severity in a dot plus a word. Used by StatusBanner, Alert and grid rows.

```jsx
<StatusDot level="good" label="Middleware OK" />
<StatusDot level="info" label="Queue 214 pending" />
```

Never a dot alone: colour-blind operators read the label. `queue_pending > 0` is `info`, never `critical`.
