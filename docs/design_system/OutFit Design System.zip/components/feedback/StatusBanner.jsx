import React from 'react';
import { StatusDot } from './StatusDot.jsx';

export function StatusBanner({ level = 'neutral', headline, detail, tiles = [], action, ...rest }) {
  return (
    <div {...rest} role="status" style={{
      background: 'var(--surface-chrome)', borderBottom: 'var(--border-width) solid var(--border-default)',
      borderTop: level === 'critical' ? 'var(--border-width-strong) solid var(--status-critical)' : 'none',
      padding: 'var(--space-lg) var(--space-2xl)', boxShadow: 'var(--shadow-card)'
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-xl)', flexWrap: 'wrap' }}>
        <StatusDot level={level} label={headline} />
        {detail ? <span style={{ color: 'var(--text-muted)', fontSize: 'var(--text-cell)' }}>{detail}</span> : null}
        <span style={{ flex: 1 }} />
        {action}
      </div>
      {tiles.length ? (
        <div style={{ display: 'flex', gap: 'var(--space-2xl)', marginTop: 'var(--space-xs)', fontSize: 'var(--text-sm)', color: 'var(--text-muted)', flexWrap: 'wrap' }}>
          {tiles.map(t => (
            <span key={t.label}>{t.label}{' '}
              <b style={{ color: t.level && t.level !== 'neutral' ? 'var(--status-' + t.level + ')' : 'var(--text-title)', fontVariantNumeric: 'var(--numeric-table)' }}>{t.value}</b>
            </span>
          ))}
        </div>
      ) : null}
    </div>
  );
}
