# OutFit Design System

A design language for **OutFit** (OutFit.AM co.) and its Label Reader product line. It is built to be
applied to an existing codebase: the structure, screens, density and copy come from the client's own
dashboard; the colour, type and surface treatment are new.

## Sources

- GitHub: <https://github.com/ali-vakilzadeh/Label_reader> — branch `main`, subtree `Dashboard/`.
  Read for this system: `Dashboard/README.md`, `Dashboard/src/public/app.css`, `Dashboard/src/public/app.js`,
  `Dashboard/src/i18n/index.ts`, plus the route/service file list. Explore that repository further —
  `Dashboard_plan_final.md` (55 KB) and `setup.md` carry the reasoning behind every screen, and
  `src/services/` and `src/suggest/` explain what each number on a screen is allowed to mean.
- Repo-level context read from the root `README.md`: the project is an Android scanning app, a
  middleware server, and this analytical dashboard.
- No Figma file, brand book, logo file, font binary or icon asset was provided. Where those are
  missing, this readme says so.

## The product

An operator in a warehouse scans an apparel barcode on an Android phone, photographs the garment,
its labels and the scale display, and AI vision extracts the label data. The middleware unifies the
vision requests. The **analytical dashboard** — the surface this system dresses — imports the app's
daily CSV ledger, de-duplicates apparel ids, snaps free text onto the client's reference tables,
suggests price / weight / HS code from its own history, groups article families and clones, and
exports OutFit's invoice and inspection paperwork in English or Armenian for customs.

Three products exist; **only the dashboard is covered here**. The Android app and middleware were
not in the attached subtree, so this system makes no claim about them.

Its users are a very small number of named operators plus one admin, on modest laptops in a
warehouse office, often in poor light and sometimes offline. Nothing loads from a CDN in production.

## Content fundamentals

The repo's own prose is the model: exact, unhedged, willing to be blunt about limits. Copy in this
design system follows it.

- **Voice.** Third person about the system, second person only in instructions. "It never invents a
  value." "The dashboard refuses to go any further until the password is changed."
- **State facts, then the consequence.** "Digest already seen: ledger-2026-09-03.csv skipped." Then,
  if useful, what to do.
- **Name the limit rather than hiding it.** The repo ships a section titled *Things that look like
  bugs and are not*. UI copy inherits that: "hs_map.csv is empty — the rule tier stays dormant."
- **Numbers carry a basis.** Never a bare suggestion: "Suggested 12 900 · history · n=41". A number
  without a defensible basis has no business on an invoice.
- **Casing.** Sentence case for everything — headings, buttons, labels, table headers. Uppercase is
  reserved for the OUTFIT wordmark and .72rem eyebrow labels. Buttons are plain verbs: Apply, Reset,
  Save, Cancel, Lock, Purge.
- **Bilingual.** Interface chrome is EN/AM (`src/i18n`); a missing Armenian key renders English, never
  a blank. Data values are looked up in the client's tables, never machine-translated. Brand and
  country are always English, including on paperwork (client instruction, 2026-08-30).
- **Spelling.** British-leaning, as upstream: "Colour", "normalise", "centre".
- **Dates and figures.** `04.09` / `04.09.2026`, 24-hour times, thin-space thousands (12 900),
  tabular figures, units spelled beside the field (kg, AMD).
- **No emoji, anywhere.** Not in UI, not in docs. No exclamation marks. No "Oops".
- **Vibe.** Customs paperwork, not a SaaS dashboard. Quiet, dense, legible, accountable.

## Visual foundations

- **Colour.** Four families. **Navy** is every word and the primary action (`--navy-900` titles,
  `--navy-800` body). **Cream** is every surface (`--cream-100` page, `--cream-50` cards,
  `--cream-200` table headers, `--cream-300` locked rows). **Cocoa** is every border, rule and muted
  label. **Gold** is the accent: active nav underline, focus ring, the one figure that matters, one
  chart bar. Four status hues — critical, warning, good, info — plus neutral.
- **Status.** Colour arrives as an 8px dot plus a word on a neutral surface. The upstream tinted
  banner washes are gone; only a critical banner earns a 2px top rule, and only alerts and notices
  carry a 3px severity rule on the left edge. `queue_pending > 0` is info, never critical.
- **Type.** Noto Sans with Noto Sans Armenian for the Armenian script, Noto Sans Mono for barcodes,
  HS codes and digests. 14px base. 400 body, 500 emphasis, 600 headings and table headers, 700 the
  wordmark only. Cells .88rem, meta .82rem, tags .75rem, h1 1.35rem.
- **Spacing and density.** Compact, kept at the repo's own values rather than snapped to a 4px grid:
  cells `.3rem .45rem`, controls `.35rem .45rem`, buttons `.35rem .7rem`, cards `1rem`, grid gap
  `1rem`, page max 1600px, narrow forms 420px.
- **Backgrounds.** Flat cream. No imagery, no gradients, no textures, no illustration — the sources
  contain none, and nothing may compete with a table. Photographs appear only as item evidence
  (garment, label, scale), shown in 3:4 slots.
- **Borders and shadows.** Every raised thing has a 1px cocoa border; shadows are faint and warm
  (`0 1px 2px rgba(77,58,42,.06)`). Never a shadow without a border. Overlays — the HS picker,
  dialogs — get `0 6px 18px` and a stronger border. No inner shadows except the meter track.
- **Corner radii.** 4px tags, 8px controls, 10px containers, 14px modals, full pill for chips.
- **Cards.** Cream-50, 1px `--border-default`, 10px radius, faint shadow, 1rem padding, 1rem bottom
  margin. Never nested; a heading and a hairline divide a card instead.
- **Tables.** Zebra rows (`--surface-row-alt`), sticky cream-200 header with a cocoa bottom rule,
  hairline row rules, right-aligned tabular numerics, monospace codes, nowrap by default. Row state
  lives in a 6px dot column; only `locked` changes the row surface, because that row is genuinely inert.
- **Transparency and blur.** Only one use: the item editor's scrim, `rgba(8,24,44,.35)`. No blur
  anywhere — it costs frames on the machines this runs on.
- **Animation.** Almost none. 120ms colour and shadow transitions on controls, 200ms meter fills,
  `cubic-bezier(.2,0,.2,1)`. No entrance animations, no bounce, no spinners on server-rendered pages.
  `prefers-reduced-motion` zeroes all durations.
- **Hover / press / focus.** Hover darkens a surface by one cream step, or brightens navy by one step
  for the primary action; rows go `--surface-row-hover` (gold-100). Press uses the next darker navy,
  no scale change beyond an optional .99. Focus is a 2px gold outline with a 3px gold-200 ring —
  never removed.
- **Fixed elements.** The two-tier top bar and the status banner sit at the top of the page and do not
  float; the grid header is the only sticky element. No fixed sidebars, no floating action buttons.
- **Imagery temperature.** Item photos are warehouse phone photos: warm, uneven, unretouched. Do not
  filter or grade them; they are evidence.
- **Print.** Paperwork drops every cream tint and gold accent for black ink and hairline rules on A4.
  See `tokens/print.css`.
- **Dark mode.** Navy becomes the surface, cream the ink, gold the primary action. `[data-theme="dark"]`.

## Iconography

The repo ships **no icon assets** — no sprite, no icon font, no SVG directory. `app.css` styles an
`.icon` class for text glyphs in row actions, and the committed code contains no glyph set.

**Substitution, flagged:** the UI kit uses **Lucide** (`lucide@0.427.0`, 1.6 stroke width) from CDN,
because its hairline stroke matches the cocoa rules. Icons are used sparingly and only where a label
would be redundant: row actions (pencil, lock, image), file upload, download, print, refresh, add
operator, close. Every icon-only button carries an accessible label. Emoji are never used; the one
unicode glyph in the system is the checkbox `☐` on the printed inspection sheet.

For production on the offline VPS, self-host `lucide.min.js` (or inline the ~12 icons actually used)
rather than loading from unpkg. **If OutFit has an icon set, send it and this substitution goes away.**

## Fonts and logo — what is missing

- **Fonts.** No binaries were provided. Noto Sans / Noto Sans Armenian is loaded from Google Fonts in
  `tokens/fonts.css`; the upstream stylesheet used the system stack with Noto Sans Armenian as a
  fallback, so this is a close-but-not-identical substitution. **Send the licensed font files** (or
  confirm Noto) and swap the `@import` for local `@font-face` rules.
- **Logo.** No mark exists in the sources, so none was drawn. The wordmark is set in type: OUTFIT in
  uppercase Noto Sans 700, cream on navy in chrome and navy on cream on paperwork, with the product
  name beside it in gold. `assets/` is therefore empty. **Send the real mark.**

## Index

| Path | What it is |
|---|---|
| `styles.css` | Global entry — `@import` list only |
| `tokens/` | `fonts`, `colors`, `typography`, `spacing`, `shape`, `motion`, `dark`, `base`, `print` |
| `guidelines/` | 20 specimen cards: colour ramps, semantic aliases, dark mode, type, Armenian, spacing, radii, elevation, borders, wordmark, status pattern, print ink |
| `components/core/` | `Button`, `Chip`, `Tag`, `Card`, `Tile`, `Meter` |
| `components/forms/` | `Field`, `Select` |
| `components/feedback/` | `StatusDot`, `StatusBanner`, `Notice`, `Alert` |
| `components/navigation/` | `TopBar`, `LangToggle`, `Pager` |
| `components/data/` | `DataGrid`, `KeyValue`, `HsCodePicker` |
| `components/charts/` | `BarChart` |
| `ui_kits/dashboard/` | Click-through recreation of all seven dashboard screens + login |
| `github.md` | Source repo association and screen map |
| `SKILL.md` | Agent-skill wrapper |

### Component inventory and its source

The repo has no component library; its inventory is the class list in `src/public/app.css`. Each
component above corresponds to one of those classes — `.btn`, `.chip`, `.tag`, `.card`, `.tile`,
`.meter`, `label/input`, `select`, `.banner`, `.notice`, `.alert`, `.topbar`, `.lang`, `.pager`,
`table.grid`, `.kv`, `.picker`, `.chart`. Nothing was invented beyond that list.

**Intentional additions:** `StatusDot` (extracted from the banner and alert markup, because the new
status pattern needs it as a primitive) and `Icon` in the UI kit (a Lucide wrapper, since no glyph set
exists upstream).

### Not built

`table.mini`, `.commercial` fieldset and `.steps` are handled inline inside UI kit screens rather than
as primitives. There are no slides in this system — no deck or template was provided.
