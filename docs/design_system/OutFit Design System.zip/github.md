repo: ali-vakilzadeh/Label_reader
branch: main
path: Dashboard

## Last sync

date: 2026-09-04T07:02:00Z

### Updated in this project
- Read the dashboard's structure, stylesheet and bilingual chrome; no code was copied.
- Built OutFit tokens (navy ink, cream surfaces, cocoa borders, gold accents) over the repo's own spacing and density values.
- Recreated the dashboard's seven screens as a UI kit on those tokens.
- Design system is intended as input for a later Claude Code pass on the repo itself.

## Screen map

| Project surface | Repo files |
|---|---|
| `ui_kits/dashboard/Chrome.jsx` | `Dashboard/src/public/app.css`, `Dashboard/src/i18n/index.ts` |
| `ui_kits/dashboard/LoginScreen.jsx` | `Dashboard/src/routes/auth.ts`, `Dashboard/README.md` |
| `ui_kits/dashboard/ItemsScreen.jsx` | `Dashboard/src/routes/items.ts`, `Dashboard/src/public/app.js` |
| `ui_kits/dashboard/ImportScreen.jsx` | `Dashboard/src/routes/imports.ts` |
| `ui_kits/dashboard/AnalyticsScreen.jsx` | `Dashboard/src/routes/analytics.ts`, `Dashboard/src/suggest/` |
| `ui_kits/dashboard/ExportsScreen.jsx` | `Dashboard/src/routes/exports.ts` |
| `ui_kits/dashboard/ServerScreen.jsx` | `Dashboard/src/routes/settings.ts` |
| `tokens/*.css` | `Dashboard/src/public/app.css` (values, density, semantics) |

Note: `Dashboard/src/views/` (EJS templates) is not committed upstream, so screen markup was
inferred from `app.css` class names plus the route and service code.
