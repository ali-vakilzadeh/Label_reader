const { Card, Button, Select, DataGrid, Notice, Chip, KeyValue } = window.OutFitDesignSystem_1696e2;

function ExportsScreen({ locale }) {
  const hy = locale === 'hy';
  const [preset, setPreset] = React.useState('Invoice');
  const [lang, setLang] = React.useState('English');
  return (
    <Page>
      <SectionHead title={hy ? 'Արտահանում' : 'Exports'} right={<Chip tone="neutral">Column for column, Outfit’s own layouts</Chip>} />
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1fr) minmax(0,2fr)', gap: 'var(--gap-grid)', alignItems: 'start' }}>
        <Card title={hy ? 'Ձևանմուշ' : 'Preset'}>
          <Select label="Layout" value={preset} onChange={e => setPreset(e.target.value)} options={['Invoice', 'Inspection']} />
          <Select label={hy ? 'Լեզու' : 'Language'} value={lang} onChange={e => setLang(e.target.value)} options={['English', 'Armenian']} />
          <Select label="Scope" options={['Reviewed rows only', 'All rows in view', 'Selected article groups']} />
          <KeyValue items={[
            { label: 'Grouping', value: 'article group + device clone' },
            { label: 'Pieces', value: 'summed over the family' },
            { label: 'Encoding', value: 'UTF-8 with BOM' }
          ]} />
          <div style={{ display: 'flex', gap: 'var(--space-lg)', marginTop: 'var(--space-2xl)' }}>
            <Button variant="primary" icon={<Icon name="download" />}>{hy ? 'Ներբեռնել' : 'Download'}</Button>
            <Button icon={<Icon name="printer" />} onClick={() => window.print()}>{hy ? 'Տպել' : 'Print'}</Button>
          </div>
          <Notice level="info" title="Brand and country stay English">Client instruction, 2026-08-30 — including on paperwork.</Notice>
        </Card>
        <Card title={(hy ? 'Նախադիտում' : 'Preview') + ' — ' + preset + ' · ' + lang} padded={false}>
          <div className="doc" style={{ background: 'var(--surface-raised)', margin: 'var(--pad-card)', padding: 'var(--space-2xl)', border: '1px solid var(--border-hairline)', borderRadius: 'var(--radius-sm)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', borderBottom: '1px solid var(--border-strong)', paddingBottom: 'var(--space-lg)', marginBottom: 'var(--space-lg)' }}>
              <b style={{ textTransform: 'uppercase', letterSpacing: 'var(--tracking-caps)', color: 'var(--text-title)' }}>OutFit</b>
              <span style={{ fontSize: 'var(--text-cell)', color: 'var(--text-muted)' }}>{preset === 'Invoice' ? 'Commercial invoice' : 'Inspection sheet'} · 04.09.2026</span>
            </div>
            <DataGrid columns={preset === 'Invoice' ? [
              { key: 'article', label: lang === 'Armenian' ? 'Հոդված' : 'Article', mono: true },
              { key: 'desc', label: lang === 'Armenian' ? 'Անվանում' : 'Description', wrap: true },
              { key: 'hs', label: 'HS', mono: true },
              { key: 'pieces', label: lang === 'Armenian' ? 'Քանակ' : 'Pieces', numeric: true },
              { key: 'netto', label: lang === 'Armenian' ? 'Նետտո' : 'Netto', numeric: true },
              { key: 'value', label: 'AMD', numeric: true }
            ] : [
              { key: 'article', label: 'Article', mono: true },
              { key: 'desc', label: 'Description', wrap: true },
              { key: 'colour', label: 'Colour' },
              { key: 'size', label: 'Size' },
              { key: 'pieces', label: 'Pieces', numeric: true },
              { key: 'check', label: 'Checked' }
            ]} rows={[
              { id: 1, article: 'ART-4471', desc: lang === 'Armenian' ? 'Անդրավարտիք, բամբակ, Zara, Türkiye' : 'Trousers, cotton, Zara, Türkiye', hs: '6203 42', pieces: 12, netto: '4.944', value: '154 800', colour: 'Navy', size: '32', check: '☐' },
              { id: 2, article: 'ART-4472', desc: lang === 'Armenian' ? 'Բաճկոն, պոլիեսթեր, Mango, Türkiye' : 'Jacket, polyester, Mango, Türkiye', hs: '6202 93', pieces: 4, netto: '3.120', value: '98 000', colour: 'Camel', size: 'M', check: '☐' },
              { id: 3, article: 'ART-4480', desc: lang === 'Armenian' ? 'Գործվածք, բամբակ, H&M, Bangladesh' : 'Knitwear, cotton, H&M, Bangladesh', hs: '6110 20', pieces: 8, netto: '2.840', value: '73 600', colour: 'Ecru', size: 'L', check: '☐' }
            ]} />
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 'var(--space-2xl)', padding: 'var(--space-lg) var(--pad-card) 0', fontSize: 'var(--text-cell)' }}>
              <span style={{ color: 'var(--text-muted)' }}>{lang === 'Armenian' ? 'Ընդամենը' : 'Total'}</span>
              <b style={{ color: 'var(--text-title)', fontVariantNumeric: 'var(--numeric-table)' }}>24 pcs · 10.904 kg · 326 400 AMD</b>
            </div>
          </div>
        </Card>
      </div>
    </Page>
  );
}
Object.assign(window, { ExportsScreen });
