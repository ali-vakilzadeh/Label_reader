# UI kit — Label Reader dashboard

Recreation of the analytical dashboard in `Dashboard/` of `ali-vakilzadeh/Label_reader`, restyled onto
the OutFit tokens (navy ink, cream surfaces, cocoa rules, gold accents). Layout, screen list, columns and
copy come from the repo; the visual language is the new one.

Open `index.html`. It starts at the login screen (`admin` / any password), then behaves as a
click-through: nav switches screens, EN/ՀԱՅ switches chrome language, Night flips the dark theme,
row filters and bulk selection work, the pencil icon opens the item editor with the HS code picker,
Import fakes a digest-guard collision on the second click, Exports previews both paperwork layouts
in either language and prints with the print tokens applied.

| File | Surface | Source read |
|---|---|---|
| `Chrome.jsx` | Two-tier top bar, page shell | `src/public/app.css` (.topbar), `src/i18n/index.ts` |
| `LoginScreen.jsx` | Sign in + first-login warning | `src/routes/auth.ts`, `README.md` |
| `ItemsScreen.jsx` | Item ledger, filters, bulk bar, item editor, HS picker | `src/routes/items.ts`, `src/services/items.ts`, `src/public/app.js` |
| `ImportScreen.jsx` | CSV import, digest guard, recent imports | `src/routes/imports.ts`, `src/services/import.ts` |
| `AnalyticsScreen.jsx` | Tiles, bars, resolution coverage, suggestion basis | `src/routes/analytics.ts`, `src/suggest/*` |
| `ExportsScreen.jsx` | Invoice / inspection preview, EN+AM | `src/services/exportPresets.ts`, `src/routes/exports.ts` |
| `ServerScreen.jsx` | Status, alerts, credentials, training purge, users | `src/routes/settings.ts`, `src/services/control.ts` |

Fixture data is in `data.js`. All values are invented; only the field names and the rules
(fuzzy stamp, digest guard, clone collapsing, basis + n) come from the repo.

Not recreated, because the repo does not contain it: the `src/views/` EJS templates are not
committed, so exact markup could not be read — screens follow the class names in `app.css` and the
route/service code instead. The Android app and middleware surfaces are out of scope for this kit.
