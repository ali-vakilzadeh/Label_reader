const { Card, Button, Tile, Notice, KeyValue, DataGrid, Meter, Chip } = window.OutFitDesignSystem_1696e2;

function ImportScreen({ locale }) {
  const hy = locale === 'hy';
  const [state, setState] = React.useState('idle');
  return (
    <Page>
      <SectionHead title={hy ? 'Ներմուծում' : 'Import'} right={<Chip tone="neutral" dot>Digest guard on</Chip>} />
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,2fr) minmax(0,1fr)', gap: 'var(--gap-grid)', alignItems: 'start' }}>
        <div>
          <Card title={hy ? 'Օրվա ֆայլ' : 'Daily ledger'}>
            <div style={{ border: '1px dashed var(--border-strong)', borderRadius: 'var(--radius-md)', background: 'var(--surface-sunken)', padding: 'var(--space-4xl) var(--space-2xl)', textAlign: 'center' }}>
              <Icon name="file-up" size={22} />
              <p style={{ margin: 'var(--space-lg) 0 var(--space-lg)', color: 'var(--text-muted)', fontSize: 'var(--text-cell)' }}>
                Drop the Android app’s CSV ledger, or choose a file.
              </p>
              <Button variant="primary" onClick={() => setState(state === 'idle' ? 'done' : 'dupe')}>{hy ? 'Ընտրել ֆայլ' : 'Choose file'}</Button>
            </div>
            {state === 'done' ? (
              <Notice level="good" title="ledger-2026-09-04.csv imported">
                214 rows read · 6 new items · 208 already present. Enriched from server_scans.db for confidences, clone links and photo paths.
              </Notice>
            ) : null}
            {state === 'dupe' ? (
              <Notice level="warning" title="Digest already seen">
                Byte-level digest a91f0c7d…4c matches an import from 08:58. The same file can never be loaded twice.
              </Notice>
            ) : null}
          </Card>
          <Card title={hy ? 'Վերջին ներմուծումներ' : 'Recent imports'} padded={false}>
            <div style={{ padding: 'var(--pad-card)' }}>
              <DataGrid columns={[
                { key: 'file', label: 'File', mono: true }, { key: 'at', label: 'Imported' },
                { key: 'rows', label: 'Rows', numeric: true }, { key: 'added', label: 'New', numeric: true },
                { key: 'digest', label: 'Digest', mono: true },
                { key: 'result', label: 'Result', render: r => <span style={{ color: r.result === 'Skipped' ? 'var(--status-warning)' : 'var(--text-body)' }}>{r.result}</span> }
              ]} rows={[
                { id: 1, file: 'ledger-2026-09-04.csv', at: '09:04', rows: 214, added: 6, digest: 'a91f0c…4c', result: 'Imported' },
                { id: 2, file: 'ledger-2026-09-03.csv', at: '08:58', rows: 198, added: 0, digest: '77be21…09', result: 'Skipped', state: 'review' },
                { id: 3, file: 'ledger-2026-09-02.csv', at: '03.09 18:22', rows: 176, added: 176, digest: '0cc3ff…b1', result: 'Imported' }
              ]} />
            </div>
          </Card>
        </div>
        <div>
          <Card title={hy ? 'Այսօր' : 'Today'}>
            <div style={{ display: 'flex', gap: 'var(--space-2xl)', flexWrap: 'wrap' }}>
              <Tile value="214" label={hy ? 'Տողեր' : 'Rows read'} />
              <Tile value="6" label={hy ? 'Նոր' : 'New items'} tone="accent" />
            </div>
            <Meter label="Taxonomy resolved" value={91} />
            <Meter label="Clone links matched" value={64} />
          </Card>
          <Card title={hy ? 'Աղբյուրներ' : 'Sources'}>
            <KeyValue items={[
              { label: 'control.db', value: 'shared, WAL' },
              { label: 'server_scans.db', value: 'read · middleware' },
              { label: 'reference_data/', value: '951 CN headings', mono: false },
              { label: 'hs_map.csv', value: 'empty — awaiting Outfit' }
            ]} />
          </Card>
        </div>
      </div>
    </Page>
  );
}
Object.assign(window, { ImportScreen });
