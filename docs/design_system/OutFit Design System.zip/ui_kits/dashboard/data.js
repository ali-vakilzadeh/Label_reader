/* Fixture data. Shapes follow Dashboard/src/types/item.ts and the i18n key list; values are invented. */
window.KIT = {
  nav: [
    { key: 'items', label: 'Items', hy: 'Ապրանքներ' },
    { key: 'import', label: 'Import', hy: 'Ներմուծում' },
    { key: 'analytics', label: 'Analytics', hy: 'Վերլուծություն' },
    { key: 'exports', label: 'Exports', hy: 'Արտահանում' },
    { key: 'server', label: 'Server', hy: 'Սերվեր' },
    { key: 'training', label: 'Training data', hy: 'Ուսուցման տվյալներ' },
    { key: 'users', label: 'Users', hy: 'Օգտատերեր' }
  ],
  items: [
    { id: 1, barcode: '8690000000001', brand: 'Zara', category: 'Trousers', hyCategory: 'Անդրավարտիք', gender: 'Men', size: '32', colour: 'Navy', country: 'Türkiye', pieces: 12, netto: '0.412', brutto: '0.470', price: '12 900', hs: '6203 42', operator: 'anna', at: '04.09 08:41', state: 'review', fuzzy: '0.88', suggested: '12 900', basis: 'history · n=41' },
    { id: 2, barcode: '8690000000047', brand: 'Mango', category: 'Jacket', hyCategory: 'Բաճկոն', gender: 'Women', size: 'M', colour: 'Camel', country: 'Türkiye', pieces: 4, netto: '0.780', brutto: '0.860', price: '24 500', hs: '6202 93', operator: 'anna', at: '04.09 08:47', state: 'default' },
    { id: 3, barcode: '8690000000112', brand: 'H&M', category: 'Knitwear', hyCategory: 'Գործվածք', gender: 'Unisex', size: 'L', colour: 'Ecru', country: 'Bangladesh', pieces: 8, netto: '0.355', brutto: '0.400', price: '9 200', hs: '6110 20', operator: 'davit', at: '04.09 09:02', state: 'duplicate' },
    { id: 4, barcode: '8690000000205', brand: 'LC Waikiki', category: 'Shirt', hyCategory: 'Վերնաշապիկ', gender: 'Men', size: '41', colour: 'White', country: 'Türkiye', pieces: 20, netto: '0.210', brutto: '0.245', price: '7 400', hs: '6205 20', operator: 'davit', at: '04.09 09:08', state: 'locked' },
    { id: 5, barcode: '8690000000318', brand: 'Koton', category: 'trowsers', hyCategory: '', gender: 'Women', size: '38', colour: 'Black', country: 'Türkiye', pieces: 6, netto: '0.390', brutto: '0.430', price: '', hs: '', operator: 'anna', at: '04.09 09:15', state: 'review', unresolved: true },
    { id: 6, barcode: '8690000000402', brand: 'Defacto', category: 'Dress', hyCategory: 'Զգեստ', gender: 'Women', size: 'S', colour: 'Olive', country: 'Türkiye', pieces: 9, netto: '0.298', brutto: '0.340', price: '14 100', hs: '6204 42', operator: 'anna', at: '04.09 09:21', state: 'default' }
  ],
  alerts: [
    { id: 'a1', level: 'critical', message: 'Vision credential rejected (401) — extraction paused', at: '09:14' },
    { id: 'a2', level: 'warning', message: 'Import digest already seen: ledger-2026-09-03.csv skipped', at: '08:58' },
    { id: 'a3', level: 'info', message: 'Catalog renders scheduled for tonight, 20:00', at: '08:52', acknowledged: true }
  ],
  categories: [
    { label: 'Trousers', value: 412 }, { label: 'Jacket', value: 288 }, { label: 'Knitwear', value: 196 },
    { label: 'Shirt', value: 143 }, { label: 'Dress', value: 88 }, { label: 'Unresolved', value: 24 }
  ],
  operators: [ { label: 'anna', value: 684 }, { label: 'davit', value: 431 }, { label: 'gor', value: 169 } ],
  hs: [
    { code: '6203 42', name: 'Men’s or boys’ trousers, of cotton' },
    { code: '6204 62', name: 'Women’s or girls’ trousers, of cotton' },
    { code: '6103 42', name: 'Trousers, knitted or crocheted, of cotton' }
  ],
  users: [
    { id: 'u1', name: 'admin', role: 'Owner', last: '04.09 09:22', state: 'default' },
    { id: 'u2', name: 'anna', role: 'Operator', last: '04.09 09:21', state: 'default' },
    { id: 'u3', name: 'davit', role: 'Operator', last: '04.09 09:08', state: 'default' },
    { id: 'u4', name: 'gor', role: 'Operator', last: '28.08 17:40', state: 'locked' }
  ]
};
