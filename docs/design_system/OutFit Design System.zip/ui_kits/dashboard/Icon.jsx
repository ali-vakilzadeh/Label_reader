/* Lucide, loaded from CDN. SUBSTITUTION: the repo ships no icon assets — the dashboard
   used bare text glyphs in .icon spans. Lucide's 1.5px stroke is the closest match to the
   hairline cocoa rules; self-host lucide.min.js before deploying to the offline VPS. */
function Icon({ name, size = 14, style }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (window.lucide && ref.current) {
      ref.current.innerHTML = '';
      const i = document.createElement('i');
      i.setAttribute('data-lucide', name);
      ref.current.appendChild(i);
      window.lucide.createIcons({ nameAttr: 'data-lucide', attrs: { width: size, height: size, 'stroke-width': 1.6 }, root: ref.current });
    }
  }, [name, size]);
  return <span ref={ref} aria-hidden="true" style={{ display: 'inline-flex', color: 'currentColor', ...style }} />;
}
Object.assign(window, { Icon });
