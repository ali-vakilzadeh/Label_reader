const { Card, Field, Button, Notice } = window.OutFitDesignSystem_1696e2;

function LoginScreen({ onSignIn, locale }) {
  const [user, setUser] = React.useState('admin');
  const [pass, setPass] = React.useState('');
  const [err, setErr] = React.useState('');
  const hy = locale === 'hy';
  const submit = e => {
    e.preventDefault();
    if (!pass) { setErr(hy ? 'Գաղտնաբառը պարտադիր է։' : 'Password is required.'); return; }
    onSignIn();
  };
  return (
    <main style={{ maxWidth: 'var(--page-narrow)', margin: '8vh auto', padding: 'var(--space-2xl)' }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: '.4rem', marginBottom: 'var(--space-2xl)' }}>
        <b style={{ color: 'var(--text-title)', fontWeight: 'var(--weight-bold)', textTransform: 'uppercase', letterSpacing: 'var(--tracking-caps)' }}>OutFit</b>
        <span style={{ color: 'var(--gold-700)', fontSize: 'var(--text-cell)' }} lang={hy ? 'hy' : undefined}>{hy ? 'Պիտակ ընթերցող' : 'Label Reader'}</span>
      </div>
      <Card>
        <h1 style={{ marginTop: 0 }} lang={hy ? 'hy' : undefined}>{hy ? 'Մուտք' : 'Sign in'}</h1>
        <form onSubmit={submit}>
          <Field label={hy ? 'Օգտանուն' : 'Username'} value={user} onChange={e => setUser(e.target.value)} />
          <Field label={hy ? 'Գաղտնաբառ' : 'Password'} type="password" value={pass} onChange={e => setPass(e.target.value)} error={err} />
          <Button variant="primary" size="lg" type="submit" style={{ marginTop: 'var(--space-lg)', width: '100%', justifyContent: 'center' }}>{hy ? 'Մուտք' : 'Sign in'}</Button>
        </form>
        <Notice level="warning" title="First login is admin / admin">
          The dashboard refuses to go any further until the password is changed.
        </Notice>
      </Card>
      <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-faint)', textAlign: 'center' }}>Single-user dashboard · no authorisation beyond sign-in</p>
    </main>
  );
}
Object.assign(window, { LoginScreen });
