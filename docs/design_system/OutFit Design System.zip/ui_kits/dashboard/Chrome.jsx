const { TopBar, LangToggle, Button } = window.OutFitDesignSystem_1696e2;

function Chrome({ screen, setScreen, locale, setLocale, theme, setTheme, children }) {
  return (
    <div data-theme={theme} style={{ minHeight: '100%', background: 'var(--surface-page)', color: 'var(--text-body)' }}>
      <TopBar
        active={screen}
        user="admin"
        items={window.KIT.nav.map(n => ({ key: n.key, label: locale === 'hy' ? n.hy : n.label, lang: locale === 'hy' ? 'hy' : undefined, onClick: () => setScreen(n.key) }))}
        right={<span style={{ display: 'inline-flex', gap: 'var(--space-lg)', alignItems: 'center' }}>
          <LangToggle locale={locale} onChange={setLocale} />
          <button type="button" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} style={{ font: 'inherit', fontSize: 'var(--text-sm)', background: 'transparent', border: '1px solid var(--cocoa-500)', color: 'var(--cream-200)', borderRadius: 'var(--radius-sm)', padding: '.2rem .5rem', cursor: 'pointer' }}>{theme === 'dark' ? 'Day' : 'Night'}</button>
          <a href="#" style={{ fontSize: 'var(--text-sm)', color: 'var(--navy-200)' }}>{locale === 'hy' ? 'Դուրս գալ' : 'Sign out'}</a>
        </span>}
      />
      {children}
    </div>
  );
}

function Page({ children, wide = true }) {
  return <main style={{ padding: 'var(--space-2xl)', maxWidth: wide ? 'var(--page-max)' : 'var(--page-narrow)', margin: '0 auto' }}>{children}</main>;
}

function SectionHead({ title, right }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 'var(--space-2xl)', flexWrap: 'wrap', marginBottom: 'var(--space-lg)' }}>
      <h1 style={{ margin: 0 }}>{title}</h1>
      <span style={{ display: 'flex', gap: 'var(--space-lg)', alignItems: 'center', flexWrap: 'wrap' }}>{right}</span>
    </div>
  );
}

Object.assign(window, { Chrome, Page, SectionHead });
