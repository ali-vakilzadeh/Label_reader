const { Card, Alert, Button, Field, KeyValue, Meter, Notice, Chip, DataGrid, StatusDot, Select } = window.OutFitDesignSystem_1696e2;

function ServerScreen({ locale }) {
  const hy = locale === 'hy';
  const [alerts, setAlerts] = React.useState(window.KIT.alerts);
  return (
    <Page>
      <SectionHead title={hy ? 'Սերվեր' : 'Server'} right={<Button size="sm" icon={<Icon name="refresh-cw" />}>Refresh</Button>} />
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,2fr) minmax(0,1fr)', gap: 'var(--gap-grid)', alignItems: 'start' }}>
        <div>
          <Card title={hy ? 'Ազդանշաններ' : 'Alerts'}>
            {alerts.map(a => (
              <Alert key={a.id} level={a.level} message={a.message} at={a.at} acknowledged={a.acknowledged}
                action={a.acknowledged ? null : <Button size="sm" onClick={() => setAlerts(l => l.map(x => x.id === a.id ? { ...x, acknowledged: true } : x))}>Acknowledge</Button>} />
            ))}
          </Card>
          <Card title={hy ? 'Տեսողական հավաստագրեր' : 'Vision credentials'}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 var(--space-xl)' }}>
              <Field label="Provider" value="Vision API" disabled />
              <Field label="Key" type="password" defaultValue="sk-live-000000" hint="Stored in control.db, never in the repo" />
            </div>
            <Notice level="critical" title="Rejected at 09:14 (401)">Extraction is paused. Replace the key and the middleware picks it up on its next poll.</Notice>
            <Button variant="primary">{hy ? 'Պահպանել' : 'Save'}</Button>
          </Card>
          <Card title={hy ? 'Ուսուցման տվյալներ' : 'Training buffer'}>
            <Meter label="Buffer" value={7.4} max={10} tone="accent" />
            <p style={{ fontSize: 'var(--text-cell)', color: 'var(--text-muted)', margin: '0 0 var(--space-lg)' }}>7.4 GB of 10 GB retained for future reference. Purging is irreversible.</p>
            <div style={{ display: 'flex', gap: 'var(--space-lg)', alignItems: 'center' }}>
              <Select options={['Older than 30 days', 'Older than 90 days', 'Everything']} aria-label="Purge scope" />
              <Button variant="danger">{hy ? 'Ջնջել' : 'Purge'}</Button>
            </div>
          </Card>
        </div>
        <div>
          <Card title={hy ? 'Վիճակ' : 'Status'}>
            <div style={{ display: 'grid', gap: 'var(--space-lg)' }}>
              <StatusDot level="good" label="Middleware heartbeat · 22 s ago" />
              <StatusDot level="info" label="Extraction queue · 214 pending" />
              <StatusDot level="critical" label="Vision credential · rejected" />
              <StatusDot level="good" label="control.db · read/write" />
            </div>
            <KeyValue items={[
              { label: 'Uptime', value: '19 d 04 h' },
              { label: 'dashboard.db', value: '412 MB' },
              { label: 'Last VACUUM INTO', value: '04.09 03:00' },
              { label: 'WAL siblings', value: 'group apparel-shared, 0660' }
            ]} />
          </Card>
          <Card title={hy ? 'Օգտատերեր' : 'Users'} padded={false}>
            <div style={{ padding: 'var(--pad-card)' }}>
              <DataGrid columns={[
                { key: 'name', label: 'Operator' }, { key: 'role', label: 'Role' }, { key: 'last', label: 'Last seen' }
              ]} rows={window.KIT.users} />
              <div style={{ marginTop: 'var(--space-lg)' }}><Button size="sm" icon={<Icon name="user-plus" />}>Add operator</Button></div>
            </div>
          </Card>
        </div>
      </div>
    </Page>
  );
}
Object.assign(window, { ServerScreen });
