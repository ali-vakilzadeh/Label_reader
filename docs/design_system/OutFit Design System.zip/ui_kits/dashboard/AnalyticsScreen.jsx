const { Card, Tile, BarChart, Meter, KeyValue, Select, Chip } = window.OutFitDesignSystem_1696e2;

function AnalyticsScreen({ locale }) {
  const hy = locale === 'hy';
  return (
    <Page>
      <SectionHead title={hy ? 'Վերլուծություն' : 'Analytics'} right={<Select options={['Last 7 days', 'Last 30 days', 'This season']} aria-label="Range" />} />
      <div style={{ display: 'flex', gap: 'var(--space-2xl)', flexWrap: 'wrap', marginBottom: 'var(--space-2xl)' }}>
        <Tile value="1,284" label={hy ? 'Ապրանքներ' : 'Items'} note="since 28.08" />
        <Tile value="37" label={hy ? 'Պահանջում է ստուգում' : 'Needs review'} tone="accent" />
        <Tile value="24" label={hy ? 'Չլուծված' : 'Unresolved text'} />
        <Tile value="412 kg" label={hy ? 'Նետտո' : 'Netto total'} />
        <Tile value="18.4 M" label="AMD declared" note="original price sum" />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(380px, 1fr))', gap: 'var(--gap-grid)' }}>
        <Card title={hy ? 'Կատեգորիաներ' : 'Items by category'}>
          <BarChart data={window.KIT.categories} highlightIndex={5} />
        </Card>
        <Card title={hy ? 'Օպերատորներ' : 'Items by operator'}>
          <BarChart data={window.KIT.operators} height={110} />
          <KeyValue items={[{ label: 'Rows per hour', value: '46 · median' }, { label: 'Rejected photos', value: '1.2%' }]} />
        </Card>
        <Card title={hy ? 'Լուծման ծածկույթ' : 'Resolution coverage'}>
          <Meter label="Exact match" value={78} />
          <Meter label="Fuzzy ≥ 0.85" value={13} tone="accent" />
          <Meter label="Left verbatim" value={9} />
          <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)', margin: 'var(--space-lg) 0 0' }}>
            Fuzzy snaps are stamped in <code>field_src_json</code> and shown on the row, never applied silently.
          </p>
        </Card>
        <Card title={hy ? 'Առաջարկների հիմք' : 'Suggestion basis'}>
          <KeyValue items={[
            { label: 'price', value: 'history · n=41 · v3' },
            { label: 'weight', value: 'history · n=28 · v2' },
            { label: 'hsCode', value: 'history only — rule tier dormant' }
          ]} />
          <div style={{ display: 'flex', gap: 'var(--space-lg)', marginTop: 'var(--space-lg)', flexWrap: 'wrap' }}>
            <Chip tone="good" dot>Basis present</Chip>
            <Chip tone="neutral" dot>No opinion returns null</Chip>
          </div>
        </Card>
      </div>
    </Page>
  );
}
Object.assign(window, { AnalyticsScreen });
