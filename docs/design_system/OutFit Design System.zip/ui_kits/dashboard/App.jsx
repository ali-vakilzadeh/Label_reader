const { Card, StatusBanner, Button, Notice } = window.OutFitDesignSystem_1696e2;

function App() {
  const [signedIn, setSignedIn] = React.useState(false);
  const [screen, setScreen] = React.useState('items');
  const [locale, setLocale] = React.useState('en');
  const [theme, setTheme] = React.useState('light');
  React.useEffect(() => { document.documentElement.dataset.theme = theme; }, [theme]);

  if (!signedIn) {
    return <div data-theme={theme} style={{ minHeight: '100vh', background: 'var(--surface-page)', color: 'var(--text-body)' }}>
      <LoginScreen locale={locale} onSignIn={() => setSignedIn(true)} />
    </div>;
  }

  const body = screen === 'items' ? <ItemsScreen locale={locale} />
    : screen === 'import' ? <ImportScreen locale={locale} />
    : screen === 'analytics' ? <AnalyticsScreen locale={locale} />
    : screen === 'exports' ? <ExportsScreen locale={locale} />
    : screen === 'server' || screen === 'users' || screen === 'training' ? <ServerScreen locale={locale} />
    : <ItemsScreen locale={locale} />;

  return (
    <Chrome screen={screen} setScreen={setScreen} locale={locale} setLocale={setLocale} theme={theme} setTheme={setTheme}>
      <StatusBanner level="warning"
        headline={locale === 'hy' ? 'Տեսողական հավաստագիրը մերժված է' : 'Vision credential rejected · extraction paused'}
        detail={locale === 'hy' ? 'Վիճակը կարող է մինչև 30 վրկ հետ մնալ։' : 'Status is up to 30 s stale; timestamps, not “live”.'}
        tiles={[
          { label: locale === 'hy' ? 'Հերթ' : 'Queue', value: 214, level: 'info' },
          { label: locale === 'hy' ? 'Ազդանշաններ' : 'Alerts', value: 2, level: 'critical' },
          { label: locale === 'hy' ? 'Վերջին ներմուծում' : 'Last import', value: '09:04' }
        ]}
        action={<Button size="sm" onClick={() => setScreen('server')}>{locale === 'hy' ? 'Բացել' : 'Open server'}</Button>} />
      {body}
      <footer style={{ padding: 'var(--space-2xl)', textAlign: 'center', color: 'var(--text-faint)', fontSize: 'var(--text-sm)' }}>
        OutFit Label Reader · dashboard build 04.09.2026 · <a href="#" onClick={e => { e.preventDefault(); setSignedIn(false); }}>sign out</a>
      </footer>
    </Chrome>
  );
}
Object.assign(window, { App });
