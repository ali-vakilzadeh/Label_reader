const { Card, DataGrid, Button, Chip, Tag, Select, Field, Pager, StatusDot, KeyValue, Notice, HsCodePicker } = window.OutFitDesignSystem_1696e2;

function ItemsScreen({ locale }) {
  const hy = locale === 'hy';
  const [rows, setRows] = React.useState(window.KIT.items);
  const [sel, setSel] = React.useState([]);
  const [open, setOpen] = React.useState(null);
  const [q, setQ] = React.useState('');
  const [only, setOnly] = React.useState('All rows');

  const shown = only === 'Needs review' ? rows.filter(r => r.state === 'review')
    : only === 'Possible duplicates' ? rows.filter(r => r.state === 'duplicate')
    : only === 'Locked' ? rows.filter(r => r.state === 'locked') : rows;

  const columns = [
    { key: 'barcode', label: hy ? 'Շտրիխ կոդ' : 'Barcode', mono: true },
    { key: 'brand', label: hy ? 'Բրենդ' : 'Brand' },
    { key: 'category', label: hy ? 'Կատեգորիա' : 'Category', render: r => (
      <span>
        <span lang={hy && r.hyCategory ? 'hy' : undefined}>{hy ? (r.hyCategory || r.category) : r.category}</span>
        {r.fuzzy ? <Tag tone="warning" mono>FUZZY:{r.fuzzy}</Tag> : null}
        {r.unresolved ? <Tag tone="critical">unresolved</Tag> : null}
      </span>) },
    { key: 'size', label: hy ? 'Չափս' : 'Size' },
    { key: 'colour', label: hy ? 'Գույն' : 'Colour' },
    { key: 'country', label: hy ? 'Ծագման երկիր' : 'Country' },
    { key: 'pieces', label: hy ? 'Քանակ' : 'Pieces', numeric: true },
    { key: 'netto', label: hy ? 'Նետտո' : 'Netto', numeric: true },
    { key: 'price', label: hy ? 'Գին' : 'Price', numeric: true, render: r => r.price
      ? <span>{r.price}</span>
      : <span style={{ color: 'var(--text-faint)' }}>—{r.suggested ? <Tag tone="warning">{r.suggested}</Tag> : null}</span> },
    { key: 'hs', label: hy ? 'ՀՏ ծածկագիր' : 'HS code', mono: true, render: r => r.hs || <span style={{ color: 'var(--text-faint)' }}>—</span> },
    { key: 'operator', label: hy ? 'Օպերատոր' : 'Operator' },
    { key: 'actions', label: hy ? 'Գործողություններ' : 'Actions', render: r => (
      <span style={{ display: 'flex', gap: 'var(--space-xs)' }}>
        <Button size="sm" variant="ghost" onClick={() => setOpen(r)}><Icon name="pencil" /></Button>
        <Button size="sm" variant="ghost" onClick={() => setRows(rs => rs.map(x => x.id === r.id ? { ...x, state: x.state === 'locked' ? 'default' : 'locked' } : x))}>
          <Icon name={r.state === 'locked' ? 'lock-open' : 'lock'} />
        </Button>
        <Button size="sm" variant="ghost"><Icon name="image" /></Button>
      </span>) }
  ];

  return (
    <Page>
      <SectionHead
        title={hy ? 'Ապրանքներ' : 'Items'}
        right={<>
          <Chip tone="warning" dot>{rows.filter(r => r.state === 'review').length} {hy ? 'ստուգում' : 'need review'}</Chip>
          <Chip tone="info" dot>1 {hy ? 'կրկնօրինակ' : 'possible duplicate'}</Chip>
          <Button size="sm" icon={<Icon name="download" />}>{hy ? 'Արտահանում' : 'Export view'}</Button>
        </>} />

      <Card padded={false}>
        <div style={{ padding: 'var(--space-lg) var(--pad-card)', borderBottom: '1px solid var(--border-hairline)' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: '0 var(--space-xl)' }}>
            <Field label={hy ? 'Որոնում' : 'Search'} value={q} onChange={e => setQ(e.target.value)} placeholder="barcode, article, brand" />
            <Select label={hy ? 'Զտիչներ' : 'View'} value={only} onChange={e => setOnly(e.target.value)} options={['All rows', 'Needs review', 'Possible duplicates', 'Locked']} />
            <Select label={hy ? 'Բրենդ' : 'Brand'} options={['Any', 'Zara', 'Mango', 'H&M', 'Koton']} />
            <Select label={hy ? 'Կատեգորիա' : 'Category'} options={['Any', 'Trousers', 'Jacket', 'Knitwear', 'Shirt', 'Dress']} />
            <Select label={hy ? 'Օպերատոր' : 'Operator'} options={['Any', 'anna', 'davit', 'gor']} />
          </div>
          <div style={{ display: 'flex', gap: 'var(--space-lg)', marginTop: 'var(--space-lg)', alignItems: 'center', flexWrap: 'wrap' }}>
            <Button variant="primary" size="sm">{hy ? 'Կիրառել' : 'Apply'}</Button>
            <Button size="sm" onClick={() => { setQ(''); setOnly('All rows'); }}>{hy ? 'Զրոյացնել' : 'Reset'}</Button>
            <span style={{ flex: 1 }} />
            <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-muted)' }}>{sel.length} selected</span>
            <Select options={['Lock', 'Unlock', 'Set price', 'Delete']} aria-label="Bulk action" style={{ width: 130 }} />
            <Button size="sm" disabled={!sel.length}>{hy ? 'Կիրառել' : 'Run'}</Button>
          </div>
        </div>
        <div style={{ padding: 'var(--pad-card)' }}>
          <DataGrid columns={columns} rows={shown} selectable selected={sel}
            onSelect={(id, on) => setSel(s => on ? [...s, id] : s.filter(x => x !== id))}
            onSelectAll={on => setSel(on ? shown.filter(r => r.state !== 'locked').map(r => r.id) : [])}
            empty={hy ? 'Այս զտիչներին համապատասխան ապրանք չկա։' : 'No items match these filters.'} />
          <Pager page={1} pages={26} total={1284} />
        </div>
      </Card>

      {open ? <ItemEditor item={open} locale={locale} onClose={() => setOpen(null)} /> : null}
    </Page>
  );
}

function ItemEditor({ item, locale, onClose }) {
  const hy = locale === 'hy';
  const [hsQuery, setHsQuery] = React.useState(item.hs || '');
  const [hsOpen, setHsOpen] = React.useState(false);
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(8,24,44,.35)', display: 'flex', justifyContent: 'flex-end', zIndex: 40 }} onClick={onClose}>
      <aside onClick={e => e.stopPropagation()} style={{ width: 520, maxWidth: '100%', background: 'var(--surface-page)', borderLeft: '1px solid var(--border-strong)', boxShadow: 'var(--shadow-overlay)', overflowY: 'auto', padding: 'var(--space-2xl)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 'var(--space-lg)' }}>
          <h2 style={{ margin: 0 }}>{item.brand} · {item.category}</h2>
          <Button size="sm" variant="ghost" onClick={onClose}><Icon name="x" size={16} /></Button>
        </div>
        <Card>
          <KeyValue columns={2} items={[
            { label: hy ? 'Շտրիխ կոդ' : 'Barcode', value: item.barcode, mono: true },
            { label: hy ? 'Օպերատոր' : 'Operator', value: item.operator },
            { label: hy ? 'Սկանավորված' : 'Scanned', value: item.at },
            { label: hy ? 'Ծագման երկիր' : 'Country', value: item.country }
          ]} />
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 var(--space-xl)' }}>
            <Field label={hy ? 'Կատեգորիա' : 'Category'} defaultValue={item.category} hint={item.fuzzy ? 'Fuzzy snap ' + item.fuzzy + ' — confirm or retype' : undefined} />
            <Field label={hy ? 'Չափս' : 'Size'} defaultValue={item.size} />
            <Field label={hy ? 'Քանակ' : 'Pieces'} defaultValue={item.pieces} />
            <Field label={hy ? 'Նետտո' : 'Netto'} suffix="kg" defaultValue={item.netto} />
            <Field label={hy ? 'Բրուտտո' : 'Brutto'} suffix="kg" defaultValue={item.brutto} />
            <Field label={hy ? 'Գին' : 'Price'} suffix="AMD" defaultValue={item.price} hint={item.basis ? 'Suggested ' + item.suggested + ' · ' + item.basis : undefined} />
          </div>
          <label style={{ display: 'block', margin: 'var(--space-md) 0', fontSize: 'var(--text-cell)', color: 'var(--text-muted)' }}>
            {hy ? 'ՀՏ ծածկագիր' : 'HS code'}
            <span style={{ display: 'block', marginTop: 'var(--space-2xs)' }}>
              <HsCodePicker value={hsQuery} open={hsOpen} results={window.KIT.hs}
                onQuery={v => { setHsQuery(v); setHsOpen(v.trim().length >= 2); }}
                onPick={r => { setHsQuery(r.code); setHsOpen(false); }} />
            </span>
          </label>
          {item.unresolved ? <Notice level="warning" title="Left verbatim">Similarity below 0.85, so the operator’s text survives untouched and this row waits for review.</Notice> : null}
          <div style={{ display: 'flex', gap: 'var(--space-lg)', marginTop: 'var(--space-2xl)' }}>
            <Button variant="primary">{hy ? 'Պահպանել' : 'Save'}</Button>
            <Button onClick={onClose}>{hy ? 'Չեղարկել' : 'Cancel'}</Button>
            <span style={{ flex: 1 }} />
            <Button variant="danger" size="sm">{hy ? 'Ջնջել' : 'Delete'}</Button>
          </div>
        </Card>
        <Card title={hy ? 'Բնօրինակ լուսանկարներ' : 'Original photos'}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 'var(--space-lg)' }}>
            {['Front', 'Label', 'Scale'].map(l => (
              <div key={l} style={{ aspectRatio: '3 / 4', border: '1px dashed var(--border-strong)', borderRadius: 'var(--radius-sm)', display: 'grid', placeItems: 'center', color: 'var(--text-faint)', fontSize: 'var(--text-sm)', background: 'var(--surface-sunken)' }}>{l}</div>
            ))}
          </div>
          <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-faint)', margin: 'var(--space-lg) 0 0' }}>Catalog image scheduled for tonight, 20:00.</p>
        </Card>
      </aside>
    </div>
  );
}
Object.assign(window, { ItemsScreen });
