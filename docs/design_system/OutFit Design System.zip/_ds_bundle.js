/* @ds-bundle: {"format":4,"namespace":"OutFitDesignSystem_1696e2","components":[{"name":"BarChart","sourcePath":"components/charts/BarChart.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Chip","sourcePath":"components/core/Chip.jsx"},{"name":"Meter","sourcePath":"components/core/Meter.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Tile","sourcePath":"components/core/Tile.jsx"},{"name":"DataGrid","sourcePath":"components/data/DataGrid.jsx"},{"name":"HsCodePicker","sourcePath":"components/data/HsCodePicker.jsx"},{"name":"KeyValue","sourcePath":"components/data/KeyValue.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Notice","sourcePath":"components/feedback/Notice.jsx"},{"name":"StatusBanner","sourcePath":"components/feedback/StatusBanner.jsx"},{"name":"StatusDot","sourcePath":"components/feedback/StatusDot.jsx"},{"name":"Field","sourcePath":"components/forms/Field.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"LangToggle","sourcePath":"components/navigation/LangToggle.jsx"},{"name":"Pager","sourcePath":"components/navigation/Pager.jsx"},{"name":"TopBar","sourcePath":"components/navigation/TopBar.jsx"}],"sourceHashes":{"components/charts/BarChart.jsx":"986864fcdbb9","components/core/Button.jsx":"08dca5e14ce7","components/core/Card.jsx":"c09934d7e10f","components/core/Chip.jsx":"0dcbdae93cf5","components/core/Meter.jsx":"4068c5a889f1","components/core/Tag.jsx":"0ea3a43e110b","components/core/Tile.jsx":"efdf90bb7df2","components/data/DataGrid.jsx":"57e8609012f9","components/data/HsCodePicker.jsx":"5a0e81a6db9b","components/data/KeyValue.jsx":"a9ce46dcbd4c","components/feedback/Alert.jsx":"a6e01eefcb8d","components/feedback/Notice.jsx":"c977a019151e","components/feedback/StatusBanner.jsx":"f7e11cb08b4a","components/feedback/StatusDot.jsx":"6637a9c1c75c","components/forms/Field.jsx":"657a06524928","components/forms/Select.jsx":"ab3f1ffa0467","components/navigation/LangToggle.jsx":"7cb4f9543da7","components/navigation/Pager.jsx":"e7645976ce1f","components/navigation/TopBar.jsx":"d5d166f21059","ui_kits/dashboard/AnalyticsScreen.jsx":"3cd0bc93e4a1","ui_kits/dashboard/App.jsx":"55b1bb808281","ui_kits/dashboard/Chrome.jsx":"6ce4fd0ff744","ui_kits/dashboard/ExportsScreen.jsx":"4e8e5260b897","ui_kits/dashboard/Icon.jsx":"40913f762e23","ui_kits/dashboard/ImportScreen.jsx":"09d595fee2ba","ui_kits/dashboard/ItemsScreen.jsx":"8d7ca292fa3a","ui_kits/dashboard/LoginScreen.jsx":"4343417c2ad8","ui_kits/dashboard/ServerScreen.jsx":"5832c6cc41bc","ui_kits/dashboard/data.js":"581530ba13fe"},"inlinedExternals":[],"unexposedExports":[{"name":"controlStyle","sourcePath":"components/forms/Field.jsx"}]} */

(() => {

const __ds_ns = (window.OutFitDesignSystem_1696e2 = window.OutFitDesignSystem_1696e2 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/charts/BarChart.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function BarChart({
  data = [],
  height = 180,
  barHeight = 18,
  gap = 8,
  highlightIndex = -1,
  unit = '',
  ...rest
}) {
  const max = Math.max(1, ...data.map(d => d.value));
  const labelW = 116;
  const rows = data.length;
  const h = Math.max(height, rows * (barHeight + gap));
  return /*#__PURE__*/React.createElement("svg", _extends({}, rest, {
    viewBox: '0 0 480 ' + h,
    width: "100%",
    height: "auto",
    role: "img",
    style: {
      display: 'block'
    }
  }), data.map((d, i) => {
    const y = i * (barHeight + gap);
    const w = d.value / max * (480 - labelW - 46);
    const fill = i === highlightIndex ? 'var(--chart-highlight)' : 'var(--chart-bar)';
    return /*#__PURE__*/React.createElement("g", {
      key: d.label
    }, /*#__PURE__*/React.createElement("text", {
      x: "0",
      y: y + barHeight * 0.75,
      style: {
        fontSize: 11,
        fill: 'var(--text-muted)',
        fontFamily: 'var(--font-sans)'
      }
    }, d.label), /*#__PURE__*/React.createElement("rect", {
      x: labelW,
      y: y,
      width: Math.max(w, 1),
      height: barHeight,
      rx: "4",
      fill: fill
    }), /*#__PURE__*/React.createElement("text", {
      x: labelW + Math.max(w, 1) + 6,
      y: y + barHeight * 0.75,
      style: {
        fontSize: 11,
        fill: 'var(--text-title)',
        fontFamily: 'var(--font-sans)',
        fontVariantNumeric: 'tabular-nums'
      }
    }, d.value, unit));
  }));
}
Object.assign(__ds_scope, { BarChart });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/charts/BarChart.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const buttonBase = {
  display: 'inline-flex',
  alignItems: 'center',
  gap: 'var(--space-xs)',
  font: 'inherit',
  fontWeight: 'var(--weight-medium)',
  lineHeight: 'var(--leading-body)',
  padding: 'var(--pad-button)',
  borderRadius: 'var(--radius-sm)',
  border: 'var(--border-width) solid var(--border-default)',
  background: 'var(--surface-card)',
  color: 'var(--text-body)',
  textDecoration: 'none',
  cursor: 'pointer',
  boxShadow: 'var(--shadow-card)',
  transition: 'var(--transition-control)',
  whiteSpace: 'nowrap'
};
const buttonVariants = {
  primary: {
    background: 'var(--action-primary)',
    color: 'var(--text-inverse)',
    borderColor: 'var(--action-primary)'
  },
  secondary: {},
  ghost: {
    background: 'transparent',
    boxShadow: 'none',
    borderColor: 'transparent'
  },
  danger: {
    color: 'var(--action-danger)',
    borderColor: 'var(--cocoa-200)'
  }
};
const buttonSizes = {
  sm: {
    padding: '.15rem .45rem',
    fontSize: 'var(--text-sm)',
    borderRadius: 'var(--radius-xs)'
  },
  md: {},
  lg: {
    padding: '.5rem 1rem',
    fontSize: 'var(--text-base)'
  }
};
function Button({
  variant = 'secondary',
  size = 'md',
  disabled = false,
  icon,
  children,
  as = 'button',
  style,
  ...rest
}) {
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({}, rest, {
    disabled: Tag === 'button' ? disabled : undefined,
    "aria-disabled": disabled || undefined,
    style: {
      ...buttonBase,
      ...buttonVariants[variant],
      ...buttonSizes[size],
      ...(disabled ? {
        opacity: .5,
        cursor: 'not-allowed',
        boxShadow: 'none'
      } : null),
      ...style
    }
  }), icon ? /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      display: 'inline-flex'
    }
  }, icon) : null, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Card({
  title,
  action,
  narrow = false,
  padded = true,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("section", _extends({}, rest, {
    style: {
      background: 'var(--surface-card)',
      border: 'var(--border-width) solid var(--border-default)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-card)',
      padding: padded ? 'var(--pad-card)' : 0,
      marginBottom: 'var(--space-2xl)',
      maxWidth: narrow ? 'var(--page-narrow)' : undefined,
      ...style
    }
  }), title || action ? /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 'var(--space-2xl)',
      marginBottom: 'var(--space-lg)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontSize: 'var(--text-lg)',
      color: 'var(--text-title)'
    }
  }, title), action) : null, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const chipTones = {
  neutral: {
    background: 'var(--surface-card)',
    color: 'var(--text-body)',
    borderColor: 'var(--border-default)'
  },
  gold: {
    background: 'var(--surface-accent)',
    color: 'var(--text-accent)',
    borderColor: 'var(--gold-300)'
  },
  critical: {
    background: 'var(--surface-card)',
    color: 'var(--status-critical)',
    borderColor: 'var(--border-default)'
  },
  warning: {
    background: 'var(--surface-card)',
    color: 'var(--status-warning)',
    borderColor: 'var(--border-default)'
  },
  good: {
    background: 'var(--surface-card)',
    color: 'var(--status-good)',
    borderColor: 'var(--border-default)'
  },
  info: {
    background: 'var(--surface-card)',
    color: 'var(--status-info)',
    borderColor: 'var(--border-default)'
  }
};
function Chip({
  tone = 'neutral',
  dot = false,
  children,
  ...rest
}) {
  const t = chipTones[tone] || chipTones.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-xs)',
      padding: 'var(--space-hair) var(--space-lg)',
      fontSize: 'var(--text-sm)',
      borderRadius: 'var(--radius-pill)',
      border: 'var(--border-width) solid ' + t.borderColor,
      background: t.background,
      color: t.color
    }
  }), dot ? /*#__PURE__*/React.createElement("i", {
    "aria-hidden": "true",
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: 'currentColor'
    }
  }) : null, children);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Chip.jsx", error: String((e && e.message) || e) }); }

// components/core/Meter.jsx
try { (() => {
function Meter({
  value,
  max = 100,
  label,
  tone = 'default',
  ...rest
}) {
  const pct = Math.max(0, Math.min(100, value / max * 100));
  const fill = tone === 'accent' ? 'var(--chart-highlight)' : 'var(--chart-bar)';
  return /*#__PURE__*/React.createElement("div", rest, label ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", null, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontVariantNumeric: 'var(--numeric-table)'
    }
  }, Math.round(pct), "%")) : null, /*#__PURE__*/React.createElement("div", {
    role: "meter",
    "aria-valuenow": value,
    "aria-valuemax": max,
    style: {
      height: 14,
      background: 'var(--chart-track)',
      borderRadius: 'var(--radius-pill)',
      overflow: 'hidden',
      margin: 'var(--space-xs) 0',
      boxShadow: 'var(--shadow-inset-track)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      width: pct + '%',
      background: fill,
      transition: 'width var(--duration-medium) var(--ease-out)'
    }
  })));
}
Object.assign(__ds_scope, { Meter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Meter.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const tagTones = {
  neutral: {
    color: 'var(--text-muted)',
    borderColor: 'var(--border-hairline)'
  },
  warning: {
    color: 'var(--status-warning)',
    borderColor: 'var(--gold-300)'
  },
  good: {
    color: 'var(--status-good)',
    borderColor: 'var(--cocoa-200)'
  },
  critical: {
    color: 'var(--status-critical)',
    borderColor: 'var(--cocoa-200)'
  }
};
function Tag({
  tone = 'neutral',
  mono = false,
  children,
  ...rest
}) {
  const t = tagTones[tone] || tagTones.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: 'inline-block',
      padding: '0 var(--space-xs)',
      marginLeft: 'var(--space-hair)',
      fontSize: 'var(--text-xs)',
      fontFamily: mono ? 'var(--font-mono)' : 'inherit',
      borderRadius: 'var(--radius-xs)',
      border: 'var(--border-width) solid ' + t.borderColor,
      background: 'var(--surface-sunken)',
      color: t.color,
      verticalAlign: 'middle'
    }
  }), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/core/Tile.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Tile({
  label,
  value,
  note,
  tone = 'default',
  ...rest
}) {
  const accent = tone === 'accent';
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      minWidth: 110,
      padding: 'var(--space-md) var(--space-xl)',
      border: 'var(--border-width) solid ' + (accent ? 'var(--border-accent)' : 'var(--border-default)'),
      borderRadius: 'var(--radius-sm)',
      background: accent ? 'var(--surface-accent)' : 'var(--surface-card)',
      boxShadow: 'var(--shadow-card)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: 'var(--text-2xl)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-title)',
      fontVariantNumeric: 'var(--numeric-table)',
      lineHeight: 'var(--leading-tight)'
    }
  }, value), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)'
    }
  }, label), note ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: 'var(--text-xs)',
      color: 'var(--text-faint)',
      marginTop: 'var(--space-hair)'
    }
  }, note) : null);
}
Object.assign(__ds_scope, { Tile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tile.jsx", error: String((e && e.message) || e) }); }

// components/data/KeyValue.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function KeyValue({
  items = [],
  columns = 1,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("dl", _extends({}, rest, {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(' + columns + ', max-content 1fr)',
      gap: 'var(--space-hair) var(--space-lg)',
      margin: 'var(--space-xs) 0',
      fontSize: 'var(--text-cell)'
    }
  }), items.map(it => [/*#__PURE__*/React.createElement("dt", {
    key: it.label + '-k',
    style: {
      color: 'var(--text-muted)',
      whiteSpace: 'nowrap'
    }
  }, it.label), /*#__PURE__*/React.createElement("dd", {
    key: it.label + '-v',
    style: {
      margin: 0,
      color: 'var(--text-body)',
      fontFamily: it.mono ? 'var(--font-mono)' : undefined
    }
  }, it.value)]));
}
Object.assign(__ds_scope, { KeyValue });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/KeyValue.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Notice.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Notice({
  level = 'info',
  title,
  children,
  action,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      gap: 'var(--space-lg)',
      alignItems: 'flex-start',
      background: 'var(--surface-card)',
      border: 'var(--border-width) solid var(--border-default)',
      borderLeft: 'var(--rule-accent) solid var(--status-' + level + ')',
      borderRadius: 'var(--radius-sm)',
      boxShadow: 'var(--shadow-card)',
      padding: 'var(--space-lg) var(--space-xl)',
      margin: 'var(--space-lg) 0'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      fontSize: 'var(--text-cell)'
    }
  }, title ? /*#__PURE__*/React.createElement("strong", {
    style: {
      display: 'block',
      color: 'var(--text-title)',
      fontWeight: 'var(--weight-semibold)'
    }
  }, title) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, children)), action);
}
Object.assign(__ds_scope, { Notice });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Notice.jsx", error: String((e && e.message) || e) }); }

// components/feedback/StatusDot.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const dotColors = {
  critical: 'var(--dot-critical)',
  warning: 'var(--dot-warning)',
  good: 'var(--dot-good)',
  info: 'var(--dot-info)',
  neutral: 'var(--dot-neutral)'
};
function StatusDot({
  level = 'neutral',
  label,
  size = 8,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-md)',
      whiteSpace: 'nowrap'
    }
  }), /*#__PURE__*/React.createElement("i", {
    "aria-hidden": "true",
    style: {
      width: size,
      height: size,
      borderRadius: '50%',
      flex: 'none',
      background: dotColors[level] || dotColors.neutral,
      boxShadow: '0 0 0 3px color-mix(in oklab, ' + (dotColors[level] || dotColors.neutral) + ' 16%, transparent)'
    }
  }), label ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-title)'
    }
  }, label) : null);
}
Object.assign(__ds_scope, { StatusDot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/StatusDot.jsx", error: String((e && e.message) || e) }); }

// components/data/DataGrid.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const gridCell = {
  padding: 'var(--pad-cell)',
  borderBottom: 'var(--border-width) solid var(--border-hairline)',
  textAlign: 'left',
  verticalAlign: 'top'
};
const rowSurfaces = {
  default: null,
  locked: {
    background: 'var(--surface-locked)',
    color: 'var(--text-muted)'
  },
  review: null,
  duplicate: null
};
const rowMarkers = {
  review: 'warning',
  duplicate: 'info',
  locked: 'neutral'
};
function DataGrid({
  columns = [],
  rows = [],
  selectable = false,
  selected = [],
  onSelect,
  onSelectAll,
  empty = 'No items match these filters.',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      overflowX: 'auto',
      border: 'var(--border-width) solid var(--border-default)',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-card)',
      boxShadow: 'var(--shadow-card)'
    }
  }), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 'var(--text-cell)'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, selectable ? /*#__PURE__*/React.createElement("th", {
    style: {
      ...gridCell,
      background: 'var(--surface-head)',
      width: 28,
      position: 'sticky',
      top: 0,
      zIndex: 1
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    "aria-label": "Select all",
    onChange: e => onSelectAll && onSelectAll(e.target.checked)
  })) : null, /*#__PURE__*/React.createElement("th", {
    style: {
      ...gridCell,
      background: 'var(--surface-head)',
      width: 16,
      position: 'sticky',
      top: 0,
      zIndex: 1
    }
  }), columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    style: {
      ...gridCell,
      background: 'var(--surface-head)',
      position: 'sticky',
      top: 0,
      zIndex: 1,
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-title)',
      textAlign: c.numeric ? 'right' : 'left',
      whiteSpace: 'nowrap',
      borderBottom: 'var(--border-width) solid var(--border-default)'
    }
  }, c.label)))), /*#__PURE__*/React.createElement("tbody", null, rows.length === 0 ? /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    colSpan: columns.length + (selectable ? 2 : 1),
    style: {
      ...gridCell,
      padding: 'var(--space-2xl)',
      textAlign: 'center',
      color: 'var(--text-muted)'
    }
  }, empty)) : rows.map((r, i) => {
    const state = r.state || 'default';
    return /*#__PURE__*/React.createElement("tr", {
      key: r.id || i,
      style: {
        background: rowSurfaces[state] && rowSurfaces[state].background || (i % 2 ? 'var(--surface-row-alt)' : 'transparent'),
        color: rowSurfaces[state] && rowSurfaces[state].color || undefined
      }
    }, selectable ? /*#__PURE__*/React.createElement("td", {
      style: gridCell
    }, /*#__PURE__*/React.createElement("input", {
      type: "checkbox",
      name: "ids",
      value: r.id,
      checked: selected.includes(r.id),
      disabled: state === 'locked',
      onChange: e => onSelect && onSelect(r.id, e.target.checked),
      "aria-label": 'Select ' + (r.id || i)
    })) : null, /*#__PURE__*/React.createElement("td", {
      style: {
        ...gridCell,
        paddingRight: 0
      }
    }, rowMarkers[state] ? /*#__PURE__*/React.createElement(__ds_scope.StatusDot, {
      level: rowMarkers[state],
      size: 6
    }) : null), columns.map(c => /*#__PURE__*/React.createElement("td", {
      key: c.key,
      style: {
        ...gridCell,
        textAlign: c.numeric ? 'right' : 'left',
        fontVariantNumeric: c.numeric ? 'var(--numeric-table)' : undefined,
        fontFamily: c.mono ? 'var(--font-mono)' : undefined,
        whiteSpace: c.wrap ? 'normal' : 'nowrap'
      }
    }, c.render ? c.render(r) : r[c.key])));
  }))));
}
Object.assign(__ds_scope, { DataGrid });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataGrid.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Alert({
  level = 'info',
  message,
  at,
  acknowledged = false,
  action,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("article", _extends({}, rest, {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-lg)',
      flexWrap: 'wrap',
      background: 'var(--surface-card)',
      border: 'var(--border-width) solid var(--border-default)',
      borderLeft: 'var(--rule-accent) solid var(--status-' + level + ')',
      borderRadius: 'var(--radius-sm)',
      padding: 'var(--space-md) var(--space-xl)',
      margin: 'var(--space-sm) 0',
      opacity: acknowledged ? .55 : 1,
      boxShadow: 'var(--shadow-card)'
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.StatusDot, {
    level: level
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 'var(--text-cell)',
      color: 'var(--text-body)'
    }
  }, message), at ? /*#__PURE__*/React.createElement("time", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-faint)',
      fontVariantNumeric: 'var(--numeric-table)'
    }
  }, at) : null, action);
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/StatusBanner.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function StatusBanner({
  level = 'neutral',
  headline,
  detail,
  tiles = [],
  action,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    role: "status",
    style: {
      background: 'var(--surface-chrome)',
      borderBottom: 'var(--border-width) solid var(--border-default)',
      borderTop: level === 'critical' ? 'var(--border-width-strong) solid var(--status-critical)' : 'none',
      padding: 'var(--space-lg) var(--space-2xl)',
      boxShadow: 'var(--shadow-card)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-xl)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.StatusDot, {
    level: level,
    label: headline
  }), detail ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 'var(--text-cell)'
    }
  }, detail) : null, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), action), tiles.length ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-2xl)',
      marginTop: 'var(--space-xs)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)',
      flexWrap: 'wrap'
    }
  }, tiles.map(t => /*#__PURE__*/React.createElement("span", {
    key: t.label
  }, t.label, ' ', /*#__PURE__*/React.createElement("b", {
    style: {
      color: t.level && t.level !== 'neutral' ? 'var(--status-' + t.level + ')' : 'var(--text-title)',
      fontVariantNumeric: 'var(--numeric-table)'
    }
  }, t.value)))) : null);
}
Object.assign(__ds_scope, { StatusBanner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/StatusBanner.jsx", error: String((e && e.message) || e) }); }

// components/forms/Field.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const controlStyle = {
  font: 'inherit',
  width: '100%',
  padding: 'var(--pad-control)',
  border: 'var(--border-width) solid var(--border-default)',
  borderRadius: 'var(--radius-sm)',
  background: 'var(--surface-raised)',
  color: 'var(--text-body)',
  boxShadow: 'var(--shadow-card)',
  transition: 'var(--transition-control)'
};
function Field({
  label,
  hint,
  error,
  suffix,
  disabled = false,
  textarea = false,
  id,
  style,
  ...rest
}) {
  const Control = textarea ? 'textarea' : 'input';
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: id,
    style: {
      display: 'block',
      margin: 'var(--space-md) 0',
      fontSize: 'var(--text-cell)',
      color: 'var(--text-muted)'
    }
  }, label, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-xs)',
      marginTop: 'var(--space-2xs)'
    }
  }, /*#__PURE__*/React.createElement(Control, _extends({
    id: id,
    disabled: disabled
  }, rest, {
    style: {
      ...controlStyle,
      ...(disabled ? {
        background: 'var(--surface-sunken)',
        color: 'var(--text-faint)'
      } : null),
      ...(error ? {
        borderColor: 'var(--status-critical)'
      } : null),
      ...style
    }
  })), suffix ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)',
      whiteSpace: 'nowrap'
    }
  }, suffix) : null), error ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      marginTop: 'var(--space-hair)',
      fontSize: 'var(--text-sm)',
      color: 'var(--status-critical)'
    }
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      marginTop: 'var(--space-hair)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-faint)'
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { controlStyle, Field });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Field.jsx", error: String((e && e.message) || e) }); }

// components/data/HsCodePicker.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function HsCodePicker({
  value = '',
  results = [],
  open = false,
  onQuery,
  onPick,
  name,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      position: 'relative',
      maxWidth: 360
    }
  }), /*#__PURE__*/React.createElement("input", {
    value: value,
    name: name,
    onChange: e => onQuery && onQuery(e.target.value),
    placeholder: "Search the CN nomenclature\u2026",
    "aria-label": "HS code",
    style: {
      ...__ds_scope.controlStyle,
      fontFamily: 'var(--font-mono)'
    }
  }), open && results.length ? /*#__PURE__*/React.createElement("div", {
    role: "listbox",
    style: {
      position: 'absolute',
      top: 'calc(100% + 3px)',
      left: 0,
      minWidth: 340,
      maxHeight: 260,
      overflowY: 'auto',
      background: 'var(--surface-raised)',
      border: 'var(--border-width) solid var(--border-strong)',
      borderRadius: 'var(--radius-sm)',
      boxShadow: 'var(--shadow-overlay)',
      zIndex: 20
    }
  }, results.map(r => /*#__PURE__*/React.createElement("div", {
    key: r.code,
    role: "option",
    tabIndex: 0,
    onMouseDown: e => {
      e.preventDefault();
      onPick && onPick(r);
    },
    style: {
      padding: 'var(--space-xs) var(--space-lg)',
      fontSize: 'var(--text-sm)',
      cursor: 'pointer',
      display: 'flex',
      gap: 'var(--space-lg)'
    }
  }, /*#__PURE__*/React.createElement("code", {
    style: {
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-title)'
    }
  }, r.code), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, r.name)))) : null);
}
Object.assign(__ds_scope, { HsCodePicker });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/HsCodePicker.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Select({
  label,
  options = [],
  hint,
  disabled = false,
  id,
  style,
  children,
  ...rest
}) {
  const control = /*#__PURE__*/React.createElement("select", _extends({
    id: id,
    disabled: disabled
  }, rest, {
    style: {
      ...__ds_scope.controlStyle,
      appearance: 'none',
      paddingRight: '1.6rem',
      cursor: disabled ? 'not-allowed' : 'pointer',
      backgroundImage: 'linear-gradient(45deg, transparent 50%, var(--cocoa-500) 50%), linear-gradient(135deg, var(--cocoa-500) 50%, transparent 50%)',
      backgroundPosition: 'calc(100% - 14px) 52%, calc(100% - 9px) 52%',
      backgroundSize: '5px 5px, 5px 5px',
      backgroundRepeat: 'no-repeat',
      ...(disabled ? {
        background: 'var(--surface-sunken)',
        color: 'var(--text-faint)'
      } : null),
      ...style
    }
  }), children || options.map(o => typeof o === 'string' ? /*#__PURE__*/React.createElement("option", {
    key: o,
    value: o
  }, o) : /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label)));
  if (!label) return control;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: id,
    style: {
      display: 'block',
      margin: 'var(--space-md) 0',
      fontSize: 'var(--text-cell)',
      color: 'var(--text-muted)'
    }
  }, label, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      marginTop: 'var(--space-2xs)'
    }
  }, control), hint ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      marginTop: 'var(--space-hair)',
      fontSize: 'var(--text-sm)',
      color: 'var(--text-faint)'
    }
  }, hint) : null);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/navigation/LangToggle.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function LangToggle({
  locale = 'en',
  onChange,
  ...rest
}) {
  const opts = [{
    id: 'en',
    label: 'EN'
  }, {
    id: 'hy',
    label: 'ՀԱՅ',
    lang: 'hy'
  }];
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    role: "group",
    "aria-label": "Language",
    style: {
      display: 'inline-flex',
      border: 'var(--border-width) solid var(--cocoa-500)',
      borderRadius: 'var(--radius-sm)',
      overflow: 'hidden'
    }
  }), opts.map(o => {
    const on = o.id === locale;
    return /*#__PURE__*/React.createElement("button", {
      key: o.id,
      type: "button",
      lang: o.lang,
      onClick: () => onChange && onChange(o.id),
      style: {
        font: 'inherit',
        fontSize: 'var(--text-sm)',
        fontWeight: 'var(--weight-medium)',
        padding: 'var(--space-2xs) var(--space-lg)',
        border: 0,
        cursor: 'pointer',
        background: on ? 'var(--gold-500)' : 'transparent',
        color: on ? 'var(--navy-950)' : 'var(--cream-200)',
        transition: 'var(--transition-control)'
      }
    }, o.label);
  }));
}
Object.assign(__ds_scope, { LangToggle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/LangToggle.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Pager.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function Pager({
  page = 1,
  pages = 1,
  total,
  onPage,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-lg)',
      marginTop: 'var(--space-lg)'
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "sm",
    disabled: page <= 1,
    onClick: () => onPage && onPage(page - 1)
  }, "\u2190 Previous"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)',
      fontVariantNumeric: 'var(--numeric-table)'
    }
  }, "Page ", page, " of ", pages, total != null ? ' · ' + total + ' rows' : ''), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "sm",
    disabled: page >= pages,
    onClick: () => onPage && onPage(page + 1)
  }, "Next \u2192"));
}
Object.assign(__ds_scope, { Pager });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Pager.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TopBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function TopBar({
  items = [],
  active,
  user,
  right,
  title = 'Label Reader',
  ...rest
}) {
  return /*#__PURE__*/React.createElement("header", _extends({}, rest, {
    style: {
      background: 'var(--surface-chrome)',
      borderBottom: 'var(--border-width) solid var(--border-default)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2xl)',
      padding: 'var(--space-lg) var(--space-2xl)',
      background: 'var(--surface-brandbar)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: '.4rem'
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--cream-50)',
      fontSize: 'var(--text-base)',
      fontWeight: 'var(--weight-bold)',
      letterSpacing: 'var(--tracking-caps)',
      textTransform: 'uppercase'
    }
  }, "OutFit"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--gold-300)',
      fontSize: 'var(--text-cell)'
    }
  }, title)), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), user ? /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--navy-200)',
      fontSize: 'var(--text-sm)'
    }
  }, user) : null, right), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 'var(--space-hair)',
      padding: '0 var(--space-2xl)',
      flexWrap: 'wrap'
    }
  }, items.map(it => {
    const on = it.key === active;
    return /*#__PURE__*/React.createElement("a", {
      key: it.key,
      href: it.href || '#',
      onClick: it.onClick,
      lang: it.lang,
      style: {
        padding: 'var(--space-md) var(--space-lg)',
        fontSize: 'var(--text-cell)',
        textDecoration: 'none',
        color: on ? 'var(--text-title)' : 'var(--text-muted)',
        fontWeight: on ? 'var(--weight-semibold)' : 'var(--weight-regular)',
        borderBottom: '2px solid ' + (on ? 'var(--border-accent)' : 'transparent'),
        marginBottom: -1,
        transition: 'var(--transition-control)'
      }
    }, it.label);
  })));
}
Object.assign(__ds_scope, { TopBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TopBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/AnalyticsScreen.jsx
try { (() => {
const {
  Card,
  Tile,
  BarChart,
  Meter,
  KeyValue,
  Select,
  Chip
} = window.OutFitDesignSystem_1696e2;
function AnalyticsScreen({
  locale
}) {
  const hy = locale === 'hy';
  return /*#__PURE__*/React.createElement(Page, null, /*#__PURE__*/React.createElement(SectionHead, {
    title: hy ? 'Վերլուծություն' : 'Analytics',
    right: /*#__PURE__*/React.createElement(Select, {
      options: ['Last 7 days', 'Last 30 days', 'This season'],
      "aria-label": "Range"
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-2xl)',
      flexWrap: 'wrap',
      marginBottom: 'var(--space-2xl)'
    }
  }, /*#__PURE__*/React.createElement(Tile, {
    value: "1,284",
    label: hy ? 'Ապրանքներ' : 'Items',
    note: "since 28.08"
  }), /*#__PURE__*/React.createElement(Tile, {
    value: "37",
    label: hy ? 'Պահանջում է ստուգում' : 'Needs review',
    tone: "accent"
  }), /*#__PURE__*/React.createElement(Tile, {
    value: "24",
    label: hy ? 'Չլուծված' : 'Unresolved text'
  }), /*#__PURE__*/React.createElement(Tile, {
    value: "412 kg",
    label: hy ? 'Նետտո' : 'Netto total'
  }), /*#__PURE__*/React.createElement(Tile, {
    value: "18.4 M",
    label: "AMD declared",
    note: "original price sum"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(380px, 1fr))',
      gap: 'var(--gap-grid)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: hy ? 'Կատեգորիաներ' : 'Items by category'
  }, /*#__PURE__*/React.createElement(BarChart, {
    data: window.KIT.categories,
    highlightIndex: 5
  })), /*#__PURE__*/React.createElement(Card, {
    title: hy ? 'Օպերատորներ' : 'Items by operator'
  }, /*#__PURE__*/React.createElement(BarChart, {
    data: window.KIT.operators,
    height: 110
  }), /*#__PURE__*/React.createElement(KeyValue, {
    items: [{
      label: 'Rows per hour',
      value: '46 · median'
    }, {
      label: 'Rejected photos',
      value: '1.2%'
    }]
  })), /*#__PURE__*/React.createElement(Card, {
    title: hy ? 'Լուծման ծածկույթ' : 'Resolution coverage'
  }, /*#__PURE__*/React.createElement(Meter, {
    label: "Exact match",
    value: 78
  }), /*#__PURE__*/React.createElement(Meter, {
    label: "Fuzzy \u2265 0.85",
    value: 13,
    tone: "accent"
  }), /*#__PURE__*/React.createElement(Meter, {
    label: "Left verbatim",
    value: 9
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)',
      margin: 'var(--space-lg) 0 0'
    }
  }, "Fuzzy snaps are stamped in ", /*#__PURE__*/React.createElement("code", null, "field_src_json"), " and shown on the row, never applied silently.")), /*#__PURE__*/React.createElement(Card, {
    title: hy ? 'Առաջարկների հիմք' : 'Suggestion basis'
  }, /*#__PURE__*/React.createElement(KeyValue, {
    items: [{
      label: 'price',
      value: 'history · n=41 · v3'
    }, {
      label: 'weight',
      value: 'history · n=28 · v2'
    }, {
      label: 'hsCode',
      value: 'history only — rule tier dormant'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-lg)',
      marginTop: 'var(--space-lg)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Chip, {
    tone: "good",
    dot: true
  }, "Basis present"), /*#__PURE__*/React.createElement(Chip, {
    tone: "neutral",
    dot: true
  }, "No opinion returns null")))));
}
Object.assign(window, {
  AnalyticsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/AnalyticsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/App.jsx
try { (() => {
const {
  Card,
  StatusBanner,
  Button,
  Notice
} = window.OutFitDesignSystem_1696e2;
function App() {
  const [signedIn, setSignedIn] = React.useState(false);
  const [screen, setScreen] = React.useState('items');
  const [locale, setLocale] = React.useState('en');
  const [theme, setTheme] = React.useState('light');
  React.useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);
  if (!signedIn) {
    return /*#__PURE__*/React.createElement("div", {
      "data-theme": theme,
      style: {
        minHeight: '100vh',
        background: 'var(--surface-page)',
        color: 'var(--text-body)'
      }
    }, /*#__PURE__*/React.createElement(LoginScreen, {
      locale: locale,
      onSignIn: () => setSignedIn(true)
    }));
  }
  const body = screen === 'items' ? /*#__PURE__*/React.createElement(ItemsScreen, {
    locale: locale
  }) : screen === 'import' ? /*#__PURE__*/React.createElement(ImportScreen, {
    locale: locale
  }) : screen === 'analytics' ? /*#__PURE__*/React.createElement(AnalyticsScreen, {
    locale: locale
  }) : screen === 'exports' ? /*#__PURE__*/React.createElement(ExportsScreen, {
    locale: locale
  }) : screen === 'server' || screen === 'users' || screen === 'training' ? /*#__PURE__*/React.createElement(ServerScreen, {
    locale: locale
  }) : /*#__PURE__*/React.createElement(ItemsScreen, {
    locale: locale
  });
  return /*#__PURE__*/React.createElement(Chrome, {
    screen: screen,
    setScreen: setScreen,
    locale: locale,
    setLocale: setLocale,
    theme: theme,
    setTheme: setTheme
  }, /*#__PURE__*/React.createElement(StatusBanner, {
    level: "warning",
    headline: locale === 'hy' ? 'Տեսողական հավաստագիրը մերժված է' : 'Vision credential rejected · extraction paused',
    detail: locale === 'hy' ? 'Վիճակը կարող է մինչև 30 վրկ հետ մնալ։' : 'Status is up to 30 s stale; timestamps, not “live”.',
    tiles: [{
      label: locale === 'hy' ? 'Հերթ' : 'Queue',
      value: 214,
      level: 'info'
    }, {
      label: locale === 'hy' ? 'Ազդանշաններ' : 'Alerts',
      value: 2,
      level: 'critical'
    }, {
      label: locale === 'hy' ? 'Վերջին ներմուծում' : 'Last import',
      value: '09:04'
    }],
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      onClick: () => setScreen('server')
    }, locale === 'hy' ? 'Բացել' : 'Open server')
  }), body, /*#__PURE__*/React.createElement("footer", {
    style: {
      padding: 'var(--space-2xl)',
      textAlign: 'center',
      color: 'var(--text-faint)',
      fontSize: 'var(--text-sm)'
    }
  }, "OutFit Label Reader \xB7 dashboard build 04.09.2026 \xB7 ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      setSignedIn(false);
    }
  }, "sign out")));
}
Object.assign(window, {
  App
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/Chrome.jsx
try { (() => {
const {
  TopBar,
  LangToggle,
  Button
} = window.OutFitDesignSystem_1696e2;
function Chrome({
  screen,
  setScreen,
  locale,
  setLocale,
  theme,
  setTheme,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    "data-theme": theme,
    style: {
      minHeight: '100%',
      background: 'var(--surface-page)',
      color: 'var(--text-body)'
    }
  }, /*#__PURE__*/React.createElement(TopBar, {
    active: screen,
    user: "admin",
    items: window.KIT.nav.map(n => ({
      key: n.key,
      label: locale === 'hy' ? n.hy : n.label,
      lang: locale === 'hy' ? 'hy' : undefined,
      onClick: () => setScreen(n.key)
    })),
    right: /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        gap: 'var(--space-lg)',
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement(LangToggle, {
      locale: locale,
      onChange: setLocale
    }), /*#__PURE__*/React.createElement("button", {
      type: "button",
      onClick: () => setTheme(theme === 'dark' ? 'light' : 'dark'),
      style: {
        font: 'inherit',
        fontSize: 'var(--text-sm)',
        background: 'transparent',
        border: '1px solid var(--cocoa-500)',
        color: 'var(--cream-200)',
        borderRadius: 'var(--radius-sm)',
        padding: '.2rem .5rem',
        cursor: 'pointer'
      }
    }, theme === 'dark' ? 'Day' : 'Night'), /*#__PURE__*/React.createElement("a", {
      href: "#",
      style: {
        fontSize: 'var(--text-sm)',
        color: 'var(--navy-200)'
      }
    }, locale === 'hy' ? 'Դուրս գալ' : 'Sign out'))
  }), children);
}
function Page({
  children,
  wide = true
}) {
  return /*#__PURE__*/React.createElement("main", {
    style: {
      padding: 'var(--space-2xl)',
      maxWidth: wide ? 'var(--page-max)' : 'var(--page-narrow)',
      margin: '0 auto'
    }
  }, children);
}
function SectionHead({
  title,
  right
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 'var(--space-2xl)',
      flexWrap: 'wrap',
      marginBottom: 'var(--space-lg)'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 'var(--space-lg)',
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, right));
}
Object.assign(window, {
  Chrome,
  Page,
  SectionHead
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/Chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/ExportsScreen.jsx
try { (() => {
const {
  Card,
  Button,
  Select,
  DataGrid,
  Notice,
  Chip,
  KeyValue
} = window.OutFitDesignSystem_1696e2;
function ExportsScreen({
  locale
}) {
  const hy = locale === 'hy';
  const [preset, setPreset] = React.useState('Invoice');
  const [lang, setLang] = React.useState('English');
  return /*#__PURE__*/React.createElement(Page, null, /*#__PURE__*/React.createElement(SectionHead, {
    title: hy ? 'Արտահանում' : 'Exports',
    right: /*#__PURE__*/React.createElement(Chip, {
      tone: "neutral"
    }, "Column for column, Outfit\u2019s own layouts")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) minmax(0,2fr)',
      gap: 'var(--gap-grid)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    title: hy ? 'Ձևանմուշ' : 'Preset'
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Layout",
    value: preset,
    onChange: e => setPreset(e.target.value),
    options: ['Invoice', 'Inspection']
  }), /*#__PURE__*/React.createElement(Select, {
    label: hy ? 'Լեզու' : 'Language',
    value: lang,
    onChange: e => setLang(e.target.value),
    options: ['English', 'Armenian']
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Scope",
    options: ['Reviewed rows only', 'All rows in view', 'Selected article groups']
  }), /*#__PURE__*/React.createElement(KeyValue, {
    items: [{
      label: 'Grouping',
      value: 'article group + device clone'
    }, {
      label: 'Pieces',
      value: 'summed over the family'
    }, {
      label: 'Encoding',
      value: 'UTF-8 with BOM'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-lg)',
      marginTop: 'var(--space-2xl)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "download"
    })
  }, hy ? 'Ներբեռնել' : 'Download'), /*#__PURE__*/React.createElement(Button, {
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "printer"
    }),
    onClick: () => window.print()
  }, hy ? 'Տպել' : 'Print')), /*#__PURE__*/React.createElement(Notice, {
    level: "info",
    title: "Brand and country stay English"
  }, "Client instruction, 2026-08-30 \u2014 including on paperwork.")), /*#__PURE__*/React.createElement(Card, {
    title: (hy ? 'Նախադիտում' : 'Preview') + ' — ' + preset + ' · ' + lang,
    padded: false
  }, /*#__PURE__*/React.createElement("div", {
    className: "doc",
    style: {
      background: 'var(--surface-raised)',
      margin: 'var(--pad-card)',
      padding: 'var(--space-2xl)',
      border: '1px solid var(--border-hairline)',
      borderRadius: 'var(--radius-sm)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      borderBottom: '1px solid var(--border-strong)',
      paddingBottom: 'var(--space-lg)',
      marginBottom: 'var(--space-lg)'
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)',
      color: 'var(--text-title)'
    }
  }, "OutFit"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-cell)',
      color: 'var(--text-muted)'
    }
  }, preset === 'Invoice' ? 'Commercial invoice' : 'Inspection sheet', " \xB7 04.09.2026")), /*#__PURE__*/React.createElement(DataGrid, {
    columns: preset === 'Invoice' ? [{
      key: 'article',
      label: lang === 'Armenian' ? 'Հոդված' : 'Article',
      mono: true
    }, {
      key: 'desc',
      label: lang === 'Armenian' ? 'Անվանում' : 'Description',
      wrap: true
    }, {
      key: 'hs',
      label: 'HS',
      mono: true
    }, {
      key: 'pieces',
      label: lang === 'Armenian' ? 'Քանակ' : 'Pieces',
      numeric: true
    }, {
      key: 'netto',
      label: lang === 'Armenian' ? 'Նետտո' : 'Netto',
      numeric: true
    }, {
      key: 'value',
      label: 'AMD',
      numeric: true
    }] : [{
      key: 'article',
      label: 'Article',
      mono: true
    }, {
      key: 'desc',
      label: 'Description',
      wrap: true
    }, {
      key: 'colour',
      label: 'Colour'
    }, {
      key: 'size',
      label: 'Size'
    }, {
      key: 'pieces',
      label: 'Pieces',
      numeric: true
    }, {
      key: 'check',
      label: 'Checked'
    }],
    rows: [{
      id: 1,
      article: 'ART-4471',
      desc: lang === 'Armenian' ? 'Անդրավարտիք, բամբակ, Zara, Türkiye' : 'Trousers, cotton, Zara, Türkiye',
      hs: '6203 42',
      pieces: 12,
      netto: '4.944',
      value: '154 800',
      colour: 'Navy',
      size: '32',
      check: '☐'
    }, {
      id: 2,
      article: 'ART-4472',
      desc: lang === 'Armenian' ? 'Բաճկոն, պոլիեսթեր, Mango, Türkiye' : 'Jacket, polyester, Mango, Türkiye',
      hs: '6202 93',
      pieces: 4,
      netto: '3.120',
      value: '98 000',
      colour: 'Camel',
      size: 'M',
      check: '☐'
    }, {
      id: 3,
      article: 'ART-4480',
      desc: lang === 'Armenian' ? 'Գործվածք, բամբակ, H&M, Bangladesh' : 'Knitwear, cotton, H&M, Bangladesh',
      hs: '6110 20',
      pieces: 8,
      netto: '2.840',
      value: '73 600',
      colour: 'Ecru',
      size: 'L',
      check: '☐'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 'var(--space-2xl)',
      padding: 'var(--space-lg) var(--pad-card) 0',
      fontSize: 'var(--text-cell)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, lang === 'Armenian' ? 'Ընդամենը' : 'Total'), /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-title)',
      fontVariantNumeric: 'var(--numeric-table)'
    }
  }, "24 pcs \xB7 10.904 kg \xB7 326 400 AMD"))))));
}
Object.assign(window, {
  ExportsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/ExportsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/Icon.jsx
try { (() => {
/* Lucide, loaded from CDN. SUBSTITUTION: the repo ships no icon assets — the dashboard
   used bare text glyphs in .icon spans. Lucide's 1.5px stroke is the closest match to the
   hairline cocoa rules; self-host lucide.min.js before deploying to the offline VPS. */
function Icon({
  name,
  size = 14,
  style
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (window.lucide && ref.current) {
      ref.current.innerHTML = '';
      const i = document.createElement('i');
      i.setAttribute('data-lucide', name);
      ref.current.appendChild(i);
      window.lucide.createIcons({
        nameAttr: 'data-lucide',
        attrs: {
          width: size,
          height: size,
          'stroke-width': 1.6
        },
        root: ref.current
      });
    }
  }, [name, size]);
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    "aria-hidden": "true",
    style: {
      display: 'inline-flex',
      color: 'currentColor',
      ...style
    }
  });
}
Object.assign(window, {
  Icon
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/Icon.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/ImportScreen.jsx
try { (() => {
const {
  Card,
  Button,
  Tile,
  Notice,
  KeyValue,
  DataGrid,
  Meter,
  Chip
} = window.OutFitDesignSystem_1696e2;
function ImportScreen({
  locale
}) {
  const hy = locale === 'hy';
  const [state, setState] = React.useState('idle');
  return /*#__PURE__*/React.createElement(Page, null, /*#__PURE__*/React.createElement(SectionHead, {
    title: hy ? 'Ներմուծում' : 'Import',
    right: /*#__PURE__*/React.createElement(Chip, {
      tone: "neutral",
      dot: true
    }, "Digest guard on")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,2fr) minmax(0,1fr)',
      gap: 'var(--gap-grid)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Card, {
    title: hy ? 'Օրվա ֆայլ' : 'Daily ledger'
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px dashed var(--border-strong)',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-sunken)',
      padding: 'var(--space-4xl) var(--space-2xl)',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "file-up",
    size: 22
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 'var(--space-lg) 0 var(--space-lg)',
      color: 'var(--text-muted)',
      fontSize: 'var(--text-cell)'
    }
  }, "Drop the Android app\u2019s CSV ledger, or choose a file."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: () => setState(state === 'idle' ? 'done' : 'dupe')
  }, hy ? 'Ընտրել ֆայլ' : 'Choose file')), state === 'done' ? /*#__PURE__*/React.createElement(Notice, {
    level: "good",
    title: "ledger-2026-09-04.csv imported"
  }, "214 rows read \xB7 6 new items \xB7 208 already present. Enriched from server_scans.db for confidences, clone links and photo paths.") : null, state === 'dupe' ? /*#__PURE__*/React.createElement(Notice, {
    level: "warning",
    title: "Digest already seen"
  }, "Byte-level digest a91f0c7d\u20264c matches an import from 08:58. The same file can never be loaded twice.") : null), /*#__PURE__*/React.createElement(Card, {
    title: hy ? 'Վերջին ներմուծումներ' : 'Recent imports',
    padded: false
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--pad-card)'
    }
  }, /*#__PURE__*/React.createElement(DataGrid, {
    columns: [{
      key: 'file',
      label: 'File',
      mono: true
    }, {
      key: 'at',
      label: 'Imported'
    }, {
      key: 'rows',
      label: 'Rows',
      numeric: true
    }, {
      key: 'added',
      label: 'New',
      numeric: true
    }, {
      key: 'digest',
      label: 'Digest',
      mono: true
    }, {
      key: 'result',
      label: 'Result',
      render: r => /*#__PURE__*/React.createElement("span", {
        style: {
          color: r.result === 'Skipped' ? 'var(--status-warning)' : 'var(--text-body)'
        }
      }, r.result)
    }],
    rows: [{
      id: 1,
      file: 'ledger-2026-09-04.csv',
      at: '09:04',
      rows: 214,
      added: 6,
      digest: 'a91f0c…4c',
      result: 'Imported'
    }, {
      id: 2,
      file: 'ledger-2026-09-03.csv',
      at: '08:58',
      rows: 198,
      added: 0,
      digest: '77be21…09',
      result: 'Skipped',
      state: 'review'
    }, {
      id: 3,
      file: 'ledger-2026-09-02.csv',
      at: '03.09 18:22',
      rows: 176,
      added: 176,
      digest: '0cc3ff…b1',
      result: 'Imported'
    }]
  })))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Card, {
    title: hy ? 'Այսօր' : 'Today'
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-2xl)',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Tile, {
    value: "214",
    label: hy ? 'Տողեր' : 'Rows read'
  }), /*#__PURE__*/React.createElement(Tile, {
    value: "6",
    label: hy ? 'Նոր' : 'New items',
    tone: "accent"
  })), /*#__PURE__*/React.createElement(Meter, {
    label: "Taxonomy resolved",
    value: 91
  }), /*#__PURE__*/React.createElement(Meter, {
    label: "Clone links matched",
    value: 64
  })), /*#__PURE__*/React.createElement(Card, {
    title: hy ? 'Աղբյուրներ' : 'Sources'
  }, /*#__PURE__*/React.createElement(KeyValue, {
    items: [{
      label: 'control.db',
      value: 'shared, WAL'
    }, {
      label: 'server_scans.db',
      value: 'read · middleware'
    }, {
      label: 'reference_data/',
      value: '951 CN headings',
      mono: false
    }, {
      label: 'hs_map.csv',
      value: 'empty — awaiting Outfit'
    }]
  })))));
}
Object.assign(window, {
  ImportScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/ImportScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/ItemsScreen.jsx
try { (() => {
const {
  Card,
  DataGrid,
  Button,
  Chip,
  Tag,
  Select,
  Field,
  Pager,
  StatusDot,
  KeyValue,
  Notice,
  HsCodePicker
} = window.OutFitDesignSystem_1696e2;
function ItemsScreen({
  locale
}) {
  const hy = locale === 'hy';
  const [rows, setRows] = React.useState(window.KIT.items);
  const [sel, setSel] = React.useState([]);
  const [open, setOpen] = React.useState(null);
  const [q, setQ] = React.useState('');
  const [only, setOnly] = React.useState('All rows');
  const shown = only === 'Needs review' ? rows.filter(r => r.state === 'review') : only === 'Possible duplicates' ? rows.filter(r => r.state === 'duplicate') : only === 'Locked' ? rows.filter(r => r.state === 'locked') : rows;
  const columns = [{
    key: 'barcode',
    label: hy ? 'Շտրիխ կոդ' : 'Barcode',
    mono: true
  }, {
    key: 'brand',
    label: hy ? 'Բրենդ' : 'Brand'
  }, {
    key: 'category',
    label: hy ? 'Կատեգորիա' : 'Category',
    render: r => /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
      lang: hy && r.hyCategory ? 'hy' : undefined
    }, hy ? r.hyCategory || r.category : r.category), r.fuzzy ? /*#__PURE__*/React.createElement(Tag, {
      tone: "warning",
      mono: true
    }, "FUZZY:", r.fuzzy) : null, r.unresolved ? /*#__PURE__*/React.createElement(Tag, {
      tone: "critical"
    }, "unresolved") : null)
  }, {
    key: 'size',
    label: hy ? 'Չափս' : 'Size'
  }, {
    key: 'colour',
    label: hy ? 'Գույն' : 'Colour'
  }, {
    key: 'country',
    label: hy ? 'Ծագման երկիր' : 'Country'
  }, {
    key: 'pieces',
    label: hy ? 'Քանակ' : 'Pieces',
    numeric: true
  }, {
    key: 'netto',
    label: hy ? 'Նետտո' : 'Netto',
    numeric: true
  }, {
    key: 'price',
    label: hy ? 'Գին' : 'Price',
    numeric: true,
    render: r => r.price ? /*#__PURE__*/React.createElement("span", null, r.price) : /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--text-faint)'
      }
    }, "\u2014", r.suggested ? /*#__PURE__*/React.createElement(Tag, {
      tone: "warning"
    }, r.suggested) : null)
  }, {
    key: 'hs',
    label: hy ? 'ՀՏ ծածկագիր' : 'HS code',
    mono: true,
    render: r => r.hs || /*#__PURE__*/React.createElement("span", {
      style: {
        color: 'var(--text-faint)'
      }
    }, "\u2014")
  }, {
    key: 'operator',
    label: hy ? 'Օպերատոր' : 'Operator'
  }, {
    key: 'actions',
    label: hy ? 'Գործողություններ' : 'Actions',
    render: r => /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'flex',
        gap: 'var(--space-xs)'
      }
    }, /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost",
      onClick: () => setOpen(r)
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "pencil"
    })), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost",
      onClick: () => setRows(rs => rs.map(x => x.id === r.id ? {
        ...x,
        state: x.state === 'locked' ? 'default' : 'locked'
      } : x))
    }, /*#__PURE__*/React.createElement(Icon, {
      name: r.state === 'locked' ? 'lock-open' : 'lock'
    })), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "ghost"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "image"
    })))
  }];
  return /*#__PURE__*/React.createElement(Page, null, /*#__PURE__*/React.createElement(SectionHead, {
    title: hy ? 'Ապրանքներ' : 'Items',
    right: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Chip, {
      tone: "warning",
      dot: true
    }, rows.filter(r => r.state === 'review').length, " ", hy ? 'ստուգում' : 'need review'), /*#__PURE__*/React.createElement(Chip, {
      tone: "info",
      dot: true
    }, "1 ", hy ? 'կրկնօրինակ' : 'possible duplicate'), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "download"
      })
    }, hy ? 'Արտահանում' : 'Export view'))
  }), /*#__PURE__*/React.createElement(Card, {
    padded: false
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-lg) var(--pad-card)',
      borderBottom: '1px solid var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))',
      gap: '0 var(--space-xl)'
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: hy ? 'Որոնում' : 'Search',
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "barcode, article, brand"
  }), /*#__PURE__*/React.createElement(Select, {
    label: hy ? 'Զտիչներ' : 'View',
    value: only,
    onChange: e => setOnly(e.target.value),
    options: ['All rows', 'Needs review', 'Possible duplicates', 'Locked']
  }), /*#__PURE__*/React.createElement(Select, {
    label: hy ? 'Բրենդ' : 'Brand',
    options: ['Any', 'Zara', 'Mango', 'H&M', 'Koton']
  }), /*#__PURE__*/React.createElement(Select, {
    label: hy ? 'Կատեգորիա' : 'Category',
    options: ['Any', 'Trousers', 'Jacket', 'Knitwear', 'Shirt', 'Dress']
  }), /*#__PURE__*/React.createElement(Select, {
    label: hy ? 'Օպերատոր' : 'Operator',
    options: ['Any', 'anna', 'davit', 'gor']
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-lg)',
      marginTop: 'var(--space-lg)',
      alignItems: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm"
  }, hy ? 'Կիրառել' : 'Apply'), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    onClick: () => {
      setQ('');
      setOnly('All rows');
    }
  }, hy ? 'Զրոյացնել' : 'Reset'), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-muted)'
    }
  }, sel.length, " selected"), /*#__PURE__*/React.createElement(Select, {
    options: ['Lock', 'Unlock', 'Set price', 'Delete'],
    "aria-label": "Bulk action",
    style: {
      width: 130
    }
  }), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    disabled: !sel.length
  }, hy ? 'Կիրառել' : 'Run'))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--pad-card)'
    }
  }, /*#__PURE__*/React.createElement(DataGrid, {
    columns: columns,
    rows: shown,
    selectable: true,
    selected: sel,
    onSelect: (id, on) => setSel(s => on ? [...s, id] : s.filter(x => x !== id)),
    onSelectAll: on => setSel(on ? shown.filter(r => r.state !== 'locked').map(r => r.id) : []),
    empty: hy ? 'Այս զտիչներին համապատասխան ապրանք չկա։' : 'No items match these filters.'
  }), /*#__PURE__*/React.createElement(Pager, {
    page: 1,
    pages: 26,
    total: 1284
  }))), open ? /*#__PURE__*/React.createElement(ItemEditor, {
    item: open,
    locale: locale,
    onClose: () => setOpen(null)
  }) : null);
}
function ItemEditor({
  item,
  locale,
  onClose
}) {
  const hy = locale === 'hy';
  const [hsQuery, setHsQuery] = React.useState(item.hs || '');
  const [hsOpen, setHsOpen] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      inset: 0,
      background: 'rgba(8,24,44,.35)',
      display: 'flex',
      justifyContent: 'flex-end',
      zIndex: 40
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("aside", {
    onClick: e => e.stopPropagation(),
    style: {
      width: 520,
      maxWidth: '100%',
      background: 'var(--surface-page)',
      borderLeft: '1px solid var(--border-strong)',
      boxShadow: 'var(--shadow-overlay)',
      overflowY: 'auto',
      padding: 'var(--space-2xl)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 'var(--space-lg)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0
    }
  }, item.brand, " \xB7 ", item.category), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "ghost",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "x",
    size: 16
  }))), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(KeyValue, {
    columns: 2,
    items: [{
      label: hy ? 'Շտրիխ կոդ' : 'Barcode',
      value: item.barcode,
      mono: true
    }, {
      label: hy ? 'Օպերատոր' : 'Operator',
      value: item.operator
    }, {
      label: hy ? 'Սկանավորված' : 'Scanned',
      value: item.at
    }, {
      label: hy ? 'Ծագման երկիր' : 'Country',
      value: item.country
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '0 var(--space-xl)'
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: hy ? 'Կատեգորիա' : 'Category',
    defaultValue: item.category,
    hint: item.fuzzy ? 'Fuzzy snap ' + item.fuzzy + ' — confirm or retype' : undefined
  }), /*#__PURE__*/React.createElement(Field, {
    label: hy ? 'Չափս' : 'Size',
    defaultValue: item.size
  }), /*#__PURE__*/React.createElement(Field, {
    label: hy ? 'Քանակ' : 'Pieces',
    defaultValue: item.pieces
  }), /*#__PURE__*/React.createElement(Field, {
    label: hy ? 'Նետտո' : 'Netto',
    suffix: "kg",
    defaultValue: item.netto
  }), /*#__PURE__*/React.createElement(Field, {
    label: hy ? 'Բրուտտո' : 'Brutto',
    suffix: "kg",
    defaultValue: item.brutto
  }), /*#__PURE__*/React.createElement(Field, {
    label: hy ? 'Գին' : 'Price',
    suffix: "AMD",
    defaultValue: item.price,
    hint: item.basis ? 'Suggested ' + item.suggested + ' · ' + item.basis : undefined
  })), /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'block',
      margin: 'var(--space-md) 0',
      fontSize: 'var(--text-cell)',
      color: 'var(--text-muted)'
    }
  }, hy ? 'ՀՏ ծածկագիր' : 'HS code', /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      marginTop: 'var(--space-2xs)'
    }
  }, /*#__PURE__*/React.createElement(HsCodePicker, {
    value: hsQuery,
    open: hsOpen,
    results: window.KIT.hs,
    onQuery: v => {
      setHsQuery(v);
      setHsOpen(v.trim().length >= 2);
    },
    onPick: r => {
      setHsQuery(r.code);
      setHsOpen(false);
    }
  }))), item.unresolved ? /*#__PURE__*/React.createElement(Notice, {
    level: "warning",
    title: "Left verbatim"
  }, "Similarity below 0.85, so the operator\u2019s text survives untouched and this row waits for review.") : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-lg)',
      marginTop: 'var(--space-2xl)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary"
  }, hy ? 'Պահպանել' : 'Save'), /*#__PURE__*/React.createElement(Button, {
    onClick: onClose
  }, hy ? 'Չեղարկել' : 'Cancel'), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "danger",
    size: "sm"
  }, hy ? 'Ջնջել' : 'Delete'))), /*#__PURE__*/React.createElement(Card, {
    title: hy ? 'Բնօրինակ լուսանկարներ' : 'Original photos'
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 'var(--space-lg)'
    }
  }, ['Front', 'Label', 'Scale'].map(l => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      aspectRatio: '3 / 4',
      border: '1px dashed var(--border-strong)',
      borderRadius: 'var(--radius-sm)',
      display: 'grid',
      placeItems: 'center',
      color: 'var(--text-faint)',
      fontSize: 'var(--text-sm)',
      background: 'var(--surface-sunken)'
    }
  }, l))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-faint)',
      margin: 'var(--space-lg) 0 0'
    }
  }, "Catalog image scheduled for tonight, 20:00."))));
}
Object.assign(window, {
  ItemsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/ItemsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/LoginScreen.jsx
try { (() => {
const {
  Card,
  Field,
  Button,
  Notice
} = window.OutFitDesignSystem_1696e2;
function LoginScreen({
  onSignIn,
  locale
}) {
  const [user, setUser] = React.useState('admin');
  const [pass, setPass] = React.useState('');
  const [err, setErr] = React.useState('');
  const hy = locale === 'hy';
  const submit = e => {
    e.preventDefault();
    if (!pass) {
      setErr(hy ? 'Գաղտնաբառը պարտադիր է։' : 'Password is required.');
      return;
    }
    onSignIn();
  };
  return /*#__PURE__*/React.createElement("main", {
    style: {
      maxWidth: 'var(--page-narrow)',
      margin: '8vh auto',
      padding: 'var(--space-2xl)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: '.4rem',
      marginBottom: 'var(--space-2xl)'
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-title)',
      fontWeight: 'var(--weight-bold)',
      textTransform: 'uppercase',
      letterSpacing: 'var(--tracking-caps)'
    }
  }, "OutFit"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--gold-700)',
      fontSize: 'var(--text-cell)'
    },
    lang: hy ? 'hy' : undefined
  }, hy ? 'Պիտակ ընթերցող' : 'Label Reader')), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("h1", {
    style: {
      marginTop: 0
    },
    lang: hy ? 'hy' : undefined
  }, hy ? 'Մուտք' : 'Sign in'), /*#__PURE__*/React.createElement("form", {
    onSubmit: submit
  }, /*#__PURE__*/React.createElement(Field, {
    label: hy ? 'Օգտանուն' : 'Username',
    value: user,
    onChange: e => setUser(e.target.value)
  }), /*#__PURE__*/React.createElement(Field, {
    label: hy ? 'Գաղտնաբառ' : 'Password',
    type: "password",
    value: pass,
    onChange: e => setPass(e.target.value),
    error: err
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    type: "submit",
    style: {
      marginTop: 'var(--space-lg)',
      width: '100%',
      justifyContent: 'center'
    }
  }, hy ? 'Մուտք' : 'Sign in')), /*#__PURE__*/React.createElement(Notice, {
    level: "warning",
    title: "First login is admin / admin"
  }, "The dashboard refuses to go any further until the password is changed.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-faint)',
      textAlign: 'center'
    }
  }, "Single-user dashboard \xB7 no authorisation beyond sign-in"));
}
Object.assign(window, {
  LoginScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/LoginScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/ServerScreen.jsx
try { (() => {
const {
  Card,
  Alert,
  Button,
  Field,
  KeyValue,
  Meter,
  Notice,
  Chip,
  DataGrid,
  StatusDot,
  Select
} = window.OutFitDesignSystem_1696e2;
function ServerScreen({
  locale
}) {
  const hy = locale === 'hy';
  const [alerts, setAlerts] = React.useState(window.KIT.alerts);
  return /*#__PURE__*/React.createElement(Page, null, /*#__PURE__*/React.createElement(SectionHead, {
    title: hy ? 'Սերվեր' : 'Server',
    right: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      icon: /*#__PURE__*/React.createElement(Icon, {
        name: "refresh-cw"
      })
    }, "Refresh")
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,2fr) minmax(0,1fr)',
      gap: 'var(--gap-grid)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Card, {
    title: hy ? 'Ազդանշաններ' : 'Alerts'
  }, alerts.map(a => /*#__PURE__*/React.createElement(Alert, {
    key: a.id,
    level: a.level,
    message: a.message,
    at: a.at,
    acknowledged: a.acknowledged,
    action: a.acknowledged ? null : /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      onClick: () => setAlerts(l => l.map(x => x.id === a.id ? {
        ...x,
        acknowledged: true
      } : x))
    }, "Acknowledge")
  }))), /*#__PURE__*/React.createElement(Card, {
    title: hy ? 'Տեսողական հավաստագրեր' : 'Vision credentials'
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '0 var(--space-xl)'
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Provider",
    value: "Vision API",
    disabled: true
  }), /*#__PURE__*/React.createElement(Field, {
    label: "Key",
    type: "password",
    defaultValue: "sk-live-000000",
    hint: "Stored in control.db, never in the repo"
  })), /*#__PURE__*/React.createElement(Notice, {
    level: "critical",
    title: "Rejected at 09:14 (401)"
  }, "Extraction is paused. Replace the key and the middleware picks it up on its next poll."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary"
  }, hy ? 'Պահպանել' : 'Save')), /*#__PURE__*/React.createElement(Card, {
    title: hy ? 'Ուսուցման տվյալներ' : 'Training buffer'
  }, /*#__PURE__*/React.createElement(Meter, {
    label: "Buffer",
    value: 7.4,
    max: 10,
    tone: "accent"
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-cell)',
      color: 'var(--text-muted)',
      margin: '0 0 var(--space-lg)'
    }
  }, "7.4 GB of 10 GB retained for future reference. Purging is irreversible."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-lg)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Select, {
    options: ['Older than 30 days', 'Older than 90 days', 'Everything'],
    "aria-label": "Purge scope"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "danger"
  }, hy ? 'Ջնջել' : 'Purge')))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Card, {
    title: hy ? 'Վիճակ' : 'Status'
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gap: 'var(--space-lg)'
    }
  }, /*#__PURE__*/React.createElement(StatusDot, {
    level: "good",
    label: "Middleware heartbeat \xB7 22 s ago"
  }), /*#__PURE__*/React.createElement(StatusDot, {
    level: "info",
    label: "Extraction queue \xB7 214 pending"
  }), /*#__PURE__*/React.createElement(StatusDot, {
    level: "critical",
    label: "Vision credential \xB7 rejected"
  }), /*#__PURE__*/React.createElement(StatusDot, {
    level: "good",
    label: "control.db \xB7 read/write"
  })), /*#__PURE__*/React.createElement(KeyValue, {
    items: [{
      label: 'Uptime',
      value: '19 d 04 h'
    }, {
      label: 'dashboard.db',
      value: '412 MB'
    }, {
      label: 'Last VACUUM INTO',
      value: '04.09 03:00'
    }, {
      label: 'WAL siblings',
      value: 'group apparel-shared, 0660'
    }]
  })), /*#__PURE__*/React.createElement(Card, {
    title: hy ? 'Օգտատերեր' : 'Users',
    padded: false
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--pad-card)'
    }
  }, /*#__PURE__*/React.createElement(DataGrid, {
    columns: [{
      key: 'name',
      label: 'Operator'
    }, {
      key: 'role',
      label: 'Role'
    }, {
      key: 'last',
      label: 'Last seen'
    }],
    rows: window.KIT.users
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'var(--space-lg)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "user-plus"
    })
  }, "Add operator")))))));
}
Object.assign(window, {
  ServerScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/ServerScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/dashboard/data.js
try { (() => {
/* Fixture data. Shapes follow Dashboard/src/types/item.ts and the i18n key list; values are invented. */
window.KIT = {
  nav: [{
    key: 'items',
    label: 'Items',
    hy: 'Ապրանքներ'
  }, {
    key: 'import',
    label: 'Import',
    hy: 'Ներմուծում'
  }, {
    key: 'analytics',
    label: 'Analytics',
    hy: 'Վերլուծություն'
  }, {
    key: 'exports',
    label: 'Exports',
    hy: 'Արտահանում'
  }, {
    key: 'server',
    label: 'Server',
    hy: 'Սերվեր'
  }, {
    key: 'training',
    label: 'Training data',
    hy: 'Ուսուցման տվյալներ'
  }, {
    key: 'users',
    label: 'Users',
    hy: 'Օգտատերեր'
  }],
  items: [{
    id: 1,
    barcode: '8690000000001',
    brand: 'Zara',
    category: 'Trousers',
    hyCategory: 'Անդրավարտիք',
    gender: 'Men',
    size: '32',
    colour: 'Navy',
    country: 'Türkiye',
    pieces: 12,
    netto: '0.412',
    brutto: '0.470',
    price: '12 900',
    hs: '6203 42',
    operator: 'anna',
    at: '04.09 08:41',
    state: 'review',
    fuzzy: '0.88',
    suggested: '12 900',
    basis: 'history · n=41'
  }, {
    id: 2,
    barcode: '8690000000047',
    brand: 'Mango',
    category: 'Jacket',
    hyCategory: 'Բաճկոն',
    gender: 'Women',
    size: 'M',
    colour: 'Camel',
    country: 'Türkiye',
    pieces: 4,
    netto: '0.780',
    brutto: '0.860',
    price: '24 500',
    hs: '6202 93',
    operator: 'anna',
    at: '04.09 08:47',
    state: 'default'
  }, {
    id: 3,
    barcode: '8690000000112',
    brand: 'H&M',
    category: 'Knitwear',
    hyCategory: 'Գործվածք',
    gender: 'Unisex',
    size: 'L',
    colour: 'Ecru',
    country: 'Bangladesh',
    pieces: 8,
    netto: '0.355',
    brutto: '0.400',
    price: '9 200',
    hs: '6110 20',
    operator: 'davit',
    at: '04.09 09:02',
    state: 'duplicate'
  }, {
    id: 4,
    barcode: '8690000000205',
    brand: 'LC Waikiki',
    category: 'Shirt',
    hyCategory: 'Վերնաշապիկ',
    gender: 'Men',
    size: '41',
    colour: 'White',
    country: 'Türkiye',
    pieces: 20,
    netto: '0.210',
    brutto: '0.245',
    price: '7 400',
    hs: '6205 20',
    operator: 'davit',
    at: '04.09 09:08',
    state: 'locked'
  }, {
    id: 5,
    barcode: '8690000000318',
    brand: 'Koton',
    category: 'trowsers',
    hyCategory: '',
    gender: 'Women',
    size: '38',
    colour: 'Black',
    country: 'Türkiye',
    pieces: 6,
    netto: '0.390',
    brutto: '0.430',
    price: '',
    hs: '',
    operator: 'anna',
    at: '04.09 09:15',
    state: 'review',
    unresolved: true
  }, {
    id: 6,
    barcode: '8690000000402',
    brand: 'Defacto',
    category: 'Dress',
    hyCategory: 'Զգեստ',
    gender: 'Women',
    size: 'S',
    colour: 'Olive',
    country: 'Türkiye',
    pieces: 9,
    netto: '0.298',
    brutto: '0.340',
    price: '14 100',
    hs: '6204 42',
    operator: 'anna',
    at: '04.09 09:21',
    state: 'default'
  }],
  alerts: [{
    id: 'a1',
    level: 'critical',
    message: 'Vision credential rejected (401) — extraction paused',
    at: '09:14'
  }, {
    id: 'a2',
    level: 'warning',
    message: 'Import digest already seen: ledger-2026-09-03.csv skipped',
    at: '08:58'
  }, {
    id: 'a3',
    level: 'info',
    message: 'Catalog renders scheduled for tonight, 20:00',
    at: '08:52',
    acknowledged: true
  }],
  categories: [{
    label: 'Trousers',
    value: 412
  }, {
    label: 'Jacket',
    value: 288
  }, {
    label: 'Knitwear',
    value: 196
  }, {
    label: 'Shirt',
    value: 143
  }, {
    label: 'Dress',
    value: 88
  }, {
    label: 'Unresolved',
    value: 24
  }],
  operators: [{
    label: 'anna',
    value: 684
  }, {
    label: 'davit',
    value: 431
  }, {
    label: 'gor',
    value: 169
  }],
  hs: [{
    code: '6203 42',
    name: 'Men’s or boys’ trousers, of cotton'
  }, {
    code: '6204 62',
    name: 'Women’s or girls’ trousers, of cotton'
  }, {
    code: '6103 42',
    name: 'Trousers, knitted or crocheted, of cotton'
  }],
  users: [{
    id: 'u1',
    name: 'admin',
    role: 'Owner',
    last: '04.09 09:22',
    state: 'default'
  }, {
    id: 'u2',
    name: 'anna',
    role: 'Operator',
    last: '04.09 09:21',
    state: 'default'
  }, {
    id: 'u3',
    name: 'davit',
    role: 'Operator',
    last: '04.09 09:08',
    state: 'default'
  }, {
    id: 'u4',
    name: 'gor',
    role: 'Operator',
    last: '28.08 17:40',
    state: 'locked'
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/dashboard/data.js", error: String((e && e.message) || e) }); }

__ds_ns.BarChart = __ds_scope.BarChart;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.Meter = __ds_scope.Meter;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Tile = __ds_scope.Tile;

__ds_ns.DataGrid = __ds_scope.DataGrid;

__ds_ns.HsCodePicker = __ds_scope.HsCodePicker;

__ds_ns.KeyValue = __ds_scope.KeyValue;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Notice = __ds_scope.Notice;

__ds_ns.StatusBanner = __ds_scope.StatusBanner;

__ds_ns.StatusDot = __ds_scope.StatusDot;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.LangToggle = __ds_scope.LangToggle;

__ds_ns.Pager = __ds_scope.Pager;

__ds_ns.TopBar = __ds_scope.TopBar;

})();
